Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/OQpFQNplbn",
      "expanded_url" : "http:\/\/youtu.be\/Z51QHo2C-yo?a",
      "display_url" : "youtu.be\/Z51QHo2C-yo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340681347234410496",
  "text" : "I liked a @YouTube video from @MalachYHVH http:\/\/t.co\/OQpFQNplbn HINE BATI \/ HERE I COME (Tehillim Mem\/Psalm 40) By Micha'el Ben",
  "id" : 340681347234410496,
  "created_at" : "2013-06-01 04:08:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/nOaoe9OcqL",
      "expanded_url" : "http:\/\/youtu.be\/9hdG1aXlExI?a",
      "display_url" : "youtu.be\/9hdG1aXlExI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340680433106829312",
  "text" : "I liked a @YouTube video from @MalachYHVH http:\/\/t.co\/nOaoe9OcqL SHEMA YISRAEL by Micha'el Ben David",
  "id" : 340680433106829312,
  "created_at" : "2013-06-01 04:05:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/1FOySxKXLD",
      "expanded_url" : "http:\/\/youtu.be\/Vx9DTDDG8lc?a",
      "display_url" : "youtu.be\/Vx9DTDDG8lc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340679503074443265",
  "text" : "I liked a @YouTube video from @BetzalelDesigns http:\/\/t.co\/1FOySxKXLD Hava Nagila Medley (Danza Hebrea)",
  "id" : 340679503074443265,
  "created_at" : "2013-06-01 04:01:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 31, 39 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/3PSte4JLfc",
      "expanded_url" : "http:\/\/youtu.be\/15scPFf7A0o?a",
      "display_url" : "youtu.be\/15scPFf7A0o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340678993084817408",
  "text" : "She has egyptian blood in her (@YouTube http:\/\/t.co\/3PSte4JLfc)",
  "id" : 340678993084817408,
  "created_at" : "2013-06-01 03:59:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/3PSte4JLfc",
      "expanded_url" : "http:\/\/youtu.be\/15scPFf7A0o?a",
      "display_url" : "youtu.be\/15scPFf7A0o?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340678398059872256",
  "text" : "I liked a @YouTube video http:\/\/t.co\/3PSte4JLfc DALIDA Hava nagila 2",
  "id" : 340678398059872256,
  "created_at" : "2013-06-01 03:57:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/FpaSej2LT2",
      "expanded_url" : "http:\/\/youtu.be\/yGXcTAHCcmo?a",
      "display_url" : "youtu.be\/yGXcTAHCcmo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340677857388945408",
  "text" : "I liked a @YouTube video http:\/\/t.co\/FpaSej2LT2 BOB DYLAN Hava Nagila \u05D4\u05D1\u05D4 \u05E0\u05D2\u05D9\u05DC\u05D4",
  "id" : 340677857388945408,
  "created_at" : "2013-06-01 03:55:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/iCCOcn51b4",
      "expanded_url" : "http:\/\/youtu.be\/KTCmKmofaKA?a",
      "display_url" : "youtu.be\/KTCmKmofaKA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340677386523774976",
  "text" : "I liked a @YouTube video http:\/\/t.co\/iCCOcn51b4 Hava Nageela - Harry Belafonte.wmv",
  "id" : 340677386523774976,
  "created_at" : "2013-06-01 03:53:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/Rf4s6BPsiv",
      "expanded_url" : "http:\/\/youtu.be\/xaHyvAMLk7U?a",
      "display_url" : "youtu.be\/xaHyvAMLk7U?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340502058409013249",
  "text" : "I liked a @YouTube video http:\/\/t.co\/Rf4s6BPsiv Elliott Yamin - Wait For You",
  "id" : 340502058409013249,
  "created_at" : "2013-05-31 16:16:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 18, 26 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/fgT090gT3u",
      "expanded_url" : "http:\/\/youtu.be\/p7fB06S8Bq8?a",
      "display_url" : "youtu.be\/p7fB06S8Bq8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340335705307893760",
  "text" : "Your so mixed up (@YouTube http:\/\/t.co\/fgT090gT3u)",
  "id" : 340335705307893760,
  "created_at" : "2013-05-31 05:15:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 67, 75 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/fgT090gT3u",
      "expanded_url" : "http:\/\/youtu.be\/p7fB06S8Bq8?a",
      "display_url" : "youtu.be\/p7fB06S8Bq8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340335482984620032",
  "text" : "No, you don't insult my dear loved country with your horrid words (@YouTube http:\/\/t.co\/fgT090gT3u)",
  "id" : 340335482984620032,
  "created_at" : "2013-05-31 05:14:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 22, 30 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/KjLQPYZ7w8",
      "expanded_url" : "http:\/\/youtu.be\/8nsXrsng3c4?a",
      "display_url" : "youtu.be\/8nsXrsng3c4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340263466508107779",
  "text" : "Please like my video (@YouTube http:\/\/t.co\/KjLQPYZ7w8)",
  "id" : 340263466508107779,
  "created_at" : "2013-05-31 00:28:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/fgT090gT3u",
      "expanded_url" : "http:\/\/youtu.be\/p7fB06S8Bq8?a",
      "display_url" : "youtu.be\/p7fB06S8Bq8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "340263393959223296",
  "text" : "I liked a @YouTube video http:\/\/t.co\/fgT090gT3u ISRAEL - Hava Nagila",
  "id" : 340263393959223296,
  "created_at" : "2013-05-31 00:28:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/Mb4TQ0Bcwn",
      "expanded_url" : "http:\/\/sdrv.ms\/ZuxmtQ",
      "display_url" : "sdrv.ms\/ZuxmtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "339928153386516480",
  "text" : "Yeah http:\/\/t.co\/Mb4TQ0Bcwn",
  "id" : 339928153386516480,
  "created_at" : "2013-05-30 02:16:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339748460649664513",
  "text" : "Google is in CA, I though it was more of a NY company",
  "id" : 339748460649664513,
  "created_at" : "2013-05-29 14:21:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339747148834951168",
  "text" : "Actually it annoys me rather then amuses me",
  "id" : 339747148834951168,
  "created_at" : "2013-05-29 14:16:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339747068849573889",
  "text" : "Remotes in front of my father yet he has trouble finding it, LOL",
  "id" : 339747068849573889,
  "created_at" : "2013-05-29 14:16:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339723163682361345",
  "text" : "A road yet to come, and a path to a final victory.",
  "id" : 339723163682361345,
  "created_at" : "2013-05-29 12:41:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339723003069861888",
  "text" : "Now there are prices of my life I need to build, like a road not traveled",
  "id" : 339723003069861888,
  "created_at" : "2013-05-29 12:40:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722830155501569",
  "text" : "I really like edx, they helped me get into MIT",
  "id" : 339722830155501569,
  "created_at" : "2013-05-29 12:40:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722703768530944",
  "text" : "Like a fender vs. a Chevy is no competition",
  "id" : 339722703768530944,
  "created_at" : "2013-05-29 12:39:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722514072735744",
  "text" : "My robot would have torn the others",
  "id" : 339722514072735744,
  "created_at" : "2013-05-29 12:38:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722438046793728",
  "text" : "Oh man I miss robo wars so badly, why did they stop it, the year I am old enough to enter",
  "id" : 339722438046793728,
  "created_at" : "2013-05-29 12:38:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722169024122881",
  "text" : "Or else they aren't secrets",
  "id" : 339722169024122881,
  "created_at" : "2013-05-29 12:37:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339722089831469057",
  "text" : "Some secrets are good to keep to yourself",
  "id" : 339722089831469057,
  "created_at" : "2013-05-29 12:37:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339721989910568961",
  "text" : "kissed a girl named Ruby in kinder, told my mom 7 years later, she was pissed, oh Alabama moments",
  "id" : 339721989910568961,
  "created_at" : "2013-05-29 12:36:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/i4nZqHIjuD",
      "expanded_url" : "http:\/\/youtu.be\/fHZjZGumxgU?a",
      "display_url" : "youtu.be\/fHZjZGumxgU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339563931599269888",
  "text" : "I liked a @YouTube video http:\/\/t.co\/i4nZqHIjuD Ion Ray Gun in operation",
  "id" : 339563931599269888,
  "created_at" : "2013-05-29 02:08:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "GrantedTech",
      "screen_name" : "GrantedTech",
      "indices" : [ 30, 42 ],
      "id_str" : "1453181598",
      "id" : 1453181598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/gW5MQmDiGS",
      "expanded_url" : "http:\/\/youtu.be\/bf1rIv0r0Sc?a",
      "display_url" : "youtu.be\/bf1rIv0r0Sc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339563702040817664",
  "text" : "I liked a @YouTube video from @grantedtech http:\/\/t.co\/gW5MQmDiGS Electric Vulcan Lyre Design Concept Invented by Andrew Magdy Kamal",
  "id" : 339563702040817664,
  "created_at" : "2013-05-29 02:07:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/TMELGvdiyl",
      "expanded_url" : "http:\/\/youtu.be\/UUJ-vvEwR90?a",
      "display_url" : "youtu.be\/UUJ-vvEwR90?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339520657798881281",
  "text" : "I liked a @YouTube video http:\/\/t.co\/TMELGvdiyl Electric Vulcan Lyre Design Concept",
  "id" : 339520657798881281,
  "created_at" : "2013-05-28 23:16:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/TMELGvdiyl",
      "expanded_url" : "http:\/\/youtu.be\/UUJ-vvEwR90?a",
      "display_url" : "youtu.be\/UUJ-vvEwR90?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339520659577241600",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/TMELGvdiyl Electric Vulcan Lyre Design Concept",
  "id" : 339520659577241600,
  "created_at" : "2013-05-28 23:16:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 11, 19 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/I37m0fy6TJ",
      "expanded_url" : "http:\/\/youtu.be\/yo7_bUj5UG4?a",
      "display_url" : "youtu.be\/yo7_bUj5UG4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339466491000934400",
  "text" : "Very Cool (@YouTube http:\/\/t.co\/I37m0fy6TJ)",
  "id" : 339466491000934400,
  "created_at" : "2013-05-28 19:41:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339251625367584768",
  "text" : "The business world is a cruel world",
  "id" : 339251625367584768,
  "created_at" : "2013-05-28 05:27:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "GrantedTech",
      "screen_name" : "GrantedTech",
      "indices" : [ 30, 42 ],
      "id_str" : "1453181598",
      "id" : 1453181598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/kEGoDD8VD6",
      "expanded_url" : "http:\/\/youtu.be\/Bmi2XYtZ-qA?a",
      "display_url" : "youtu.be\/Bmi2XYtZ-qA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339077124621234176",
  "text" : "I liked a @YouTube video from @grantedtech http:\/\/t.co\/kEGoDD8VD6 My Physics Nominations",
  "id" : 339077124621234176,
  "created_at" : "2013-05-27 17:54:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "GrantedTech",
      "screen_name" : "GrantedTech",
      "indices" : [ 30, 42 ],
      "id_str" : "1453181598",
      "id" : 1453181598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/lc3LX5v6eZ",
      "expanded_url" : "http:\/\/youtu.be\/fEa697RUh0I?a",
      "display_url" : "youtu.be\/fEa697RUh0I?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339077043809550336",
  "text" : "I liked a @YouTube video from @grantedtech http:\/\/t.co\/lc3LX5v6eZ What Is Quantum Physics?",
  "id" : 339077043809550336,
  "created_at" : "2013-05-27 17:54:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "GrantedTech",
      "screen_name" : "GrantedTech",
      "indices" : [ 30, 42 ],
      "id_str" : "1453181598",
      "id" : 1453181598
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/VXNhS9eFHH",
      "expanded_url" : "http:\/\/youtu.be\/Qkp_hShYXHM?a",
      "display_url" : "youtu.be\/Qkp_hShYXHM?a"
    } ]
  },
  "geo" : { },
  "id_str" : "339076853044224000",
  "text" : "I liked a @YouTube video from @grantedtech http:\/\/t.co\/VXNhS9eFHH Channel Video Trailer",
  "id" : 339076853044224000,
  "created_at" : "2013-05-27 17:53:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338906960768425985",
  "text" : "The moment that happened",
  "id" : 338906960768425985,
  "created_at" : "2013-05-27 06:38:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338906883136032768",
  "text" : "I wish twitter could finally verify my twitter name",
  "id" : 338906883136032768,
  "created_at" : "2013-05-27 06:37:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/plxoLzTmiC",
      "expanded_url" : "http:\/\/YouTube.com\/coptictalent",
      "display_url" : "YouTube.com\/coptictalent"
    } ]
  },
  "geo" : { },
  "id_str" : "338905804579160064",
  "text" : "Also check http:\/\/t.co\/plxoLzTmiC",
  "id" : 338905804579160064,
  "created_at" : "2013-05-27 06:33:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338905395387060224",
  "text" : "Also I founded a new company called granted tech industries though it is more of a social network",
  "id" : 338905395387060224,
  "created_at" : "2013-05-27 06:31:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/nseKZbrZwY",
      "expanded_url" : "http:\/\/YouTube.com\/physicswithandrew",
      "display_url" : "YouTube.com\/physicswithand\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "338905212376985600",
  "text" : "http:\/\/t.co\/nseKZbrZwY",
  "id" : 338905212376985600,
  "created_at" : "2013-05-27 06:31:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338905112288317440",
  "text" : "Have any of you seen my new lectures on YouTube",
  "id" : 338905112288317440,
  "created_at" : "2013-05-27 06:30:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338904613564588033",
  "text" : "I hate posting stupid friends on twitter, my friends say if I do it I will get more followers but I will stop now",
  "id" : 338904613564588033,
  "created_at" : "2013-05-27 06:28:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338904372773793792",
  "text" : "Just kiddin",
  "id" : 338904372773793792,
  "created_at" : "2013-05-27 06:27:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338904319829110785",
  "text" : "Don't blame me for being a nerd blame yourselves",
  "id" : 338904319829110785,
  "created_at" : "2013-05-27 06:27:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338904213016936448",
  "text" : "Man oh man, I need a hobby",
  "id" : 338904213016936448,
  "created_at" : "2013-05-27 06:27:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338904060067471360",
  "text" : "140 characters, that is it, I need 141 :-D",
  "id" : 338904060067471360,
  "created_at" : "2013-05-27 06:26:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338903855226044418",
  "text" : "Dang autocorrect",
  "id" : 338903855226044418,
  "created_at" : "2013-05-27 06:25:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338903741329715200",
  "text" : "I like peanut butter",
  "id" : 338903741329715200,
  "created_at" : "2013-05-27 06:25:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338903659444334592",
  "text" : "Does kissing your cousin on the lips numerous times and then you know, count as kidding a girl?",
  "id" : 338903659444334592,
  "created_at" : "2013-05-27 06:25:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338902753512398848",
  "text" : "I miss tweeting already",
  "id" : 338902753512398848,
  "created_at" : "2013-05-27 06:21:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "338383856698785793",
  "text" : "Windows didn't let me fully update my phone to latest version, I want it more costumized!!",
  "id" : 338383856698785793,
  "created_at" : "2013-05-25 19:59:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 42, 50 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Jal643bakZ",
      "expanded_url" : "http:\/\/youtu.be\/UqLzoiVzEY8?a",
      "display_url" : "youtu.be\/UqLzoiVzEY8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338348391551614976",
  "text" : "He reminds me of Andrew Magdy Kamal, LOL (@YouTube http:\/\/t.co\/Jal643bakZ)",
  "id" : 338348391551614976,
  "created_at" : "2013-05-25 17:38:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 89, 97 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/x0WPBw5PtB",
      "expanded_url" : "http:\/\/youtu.be\/ggur-Ca2nzs?a",
      "display_url" : "youtu.be\/ggur-Ca2nzs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338348304117166080",
  "text" : "He isn't smart, he is just a psychotic liberal, no one can do such things and have much (@YouTube http:\/\/t.co\/x0WPBw5PtB)",
  "id" : 338348304117166080,
  "created_at" : "2013-05-25 17:38:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 57, 65 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/wQe0aKDANj",
      "expanded_url" : "http:\/\/youtu.be\/kwZlnwqo3KI?a",
      "display_url" : "youtu.be\/kwZlnwqo3KI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338347660480237569",
  "text" : "Did you use Blender 2.3 to make this, or what software? (@YouTube http:\/\/t.co\/wQe0aKDANj)",
  "id" : 338347660480237569,
  "created_at" : "2013-05-25 17:35:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 63, 71 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/JlyVwCEtEO",
      "expanded_url" : "http:\/\/youtu.be\/TPeNn-T2TFo?a",
      "display_url" : "youtu.be\/TPeNn-T2TFo?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338347448370077697",
  "text" : "Is that stop motion animation, I made a similar video before. (@YouTube http:\/\/t.co\/JlyVwCEtEO)",
  "id" : 338347448370077697,
  "created_at" : "2013-05-25 17:34:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 92, 100 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/XiJCvCGz0d",
      "expanded_url" : "http:\/\/youtu.be\/8_LvvqSij4Q?a",
      "display_url" : "youtu.be\/8_LvvqSij4Q?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338092460641226754",
  "text" : "Even if you put their logo, they still try to add a strike on your account, even if your a (@YouTube http:\/\/t.co\/XiJCvCGz0d)",
  "id" : 338092460641226754,
  "created_at" : "2013-05-25 00:41:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/qstfUkrhQH",
      "expanded_url" : "http:\/\/youtu.be\/-JWUym4FnK0?a",
      "display_url" : "youtu.be\/-JWUym4FnK0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338060942044712960",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/qstfUkrhQH Hos Erouf",
  "id" : 338060942044712960,
  "created_at" : "2013-05-24 22:36:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/bdvZU6n8oY",
      "expanded_url" : "http:\/\/youtu.be\/J9bhbFLCYfc?a",
      "display_url" : "youtu.be\/J9bhbFLCYfc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "338060881680289792",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/bdvZU6n8oY Coptic Hymns (2\/5\/2013)",
  "id" : 338060881680289792,
  "created_at" : "2013-05-24 22:36:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337820572673265664",
  "text" : "Just tried premium ice cream, way better then Kroger brand",
  "id" : 337820572673265664,
  "created_at" : "2013-05-24 06:41:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/ClgyCykDYF",
      "expanded_url" : "http:\/\/youtu.be\/kNwEB3Sarcs?a",
      "display_url" : "youtu.be\/kNwEB3Sarcs?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337742191155892225",
  "text" : "I liked a @YouTube video http:\/\/t.co\/ClgyCykDYF Minecraft Funny Montage (12)",
  "id" : 337742191155892225,
  "created_at" : "2013-05-24 01:29:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/zrWnB5IzPQ",
      "expanded_url" : "http:\/\/youtu.be\/E60JvoU9j9M?a",
      "display_url" : "youtu.be\/E60JvoU9j9M?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337741898896777216",
  "text" : "I liked a @YouTube video http:\/\/t.co\/zrWnB5IzPQ F1 2012 - F1 Xbox Leagues - Round 2. Brazil",
  "id" : 337741898896777216,
  "created_at" : "2013-05-24 01:28:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/tyZda4rfr4",
      "expanded_url" : "http:\/\/youtu.be\/IqrxzhEyUVU?a",
      "display_url" : "youtu.be\/IqrxzhEyUVU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337741599759028224",
  "text" : "I liked a @YouTube video http:\/\/t.co\/tyZda4rfr4 MUSCULACION HOMBROS fuerza hombros tonificar musculoso musculos shoulders press",
  "id" : 337741599759028224,
  "created_at" : "2013-05-24 01:27:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/xRZ52GfFtf",
      "expanded_url" : "http:\/\/youtu.be\/7vS3a0ZP6cA?a",
      "display_url" : "youtu.be\/7vS3a0ZP6cA?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337741059171962880",
  "text" : "I liked a @YouTube video from @arc_minecraft http:\/\/t.co\/xRZ52GfFtf Minecraft - Hypixel Server Tour (Beta) \u1D34\u1D30",
  "id" : 337741059171962880,
  "created_at" : "2013-05-24 01:25:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/PvDfTTFjHp",
      "expanded_url" : "http:\/\/youtu.be\/3IqP2Bv9lfw?a",
      "display_url" : "youtu.be\/3IqP2Bv9lfw?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337740510271778817",
  "text" : "I liked a @YouTube video http:\/\/t.co\/PvDfTTFjHp what is wicca ..for the uninformed wiccan",
  "id" : 337740510271778817,
  "created_at" : "2013-05-24 01:23:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/qstfUkrhQH",
      "expanded_url" : "http:\/\/youtu.be\/-JWUym4FnK0?a",
      "display_url" : "youtu.be\/-JWUym4FnK0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "337638392366002177",
  "text" : "Hos Erouf: http:\/\/t.co\/qstfUkrhQH via @YouTube",
  "id" : 337638392366002177,
  "created_at" : "2013-05-23 18:37:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "337047516258381826",
  "text" : "I didn't post that least tweet, someone should stop hacking my account",
  "id" : 337047516258381826,
  "created_at" : "2013-05-22 03:29:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/xC0YbWnedH",
      "expanded_url" : "http:\/\/youtu.be\/xbK0C9AYMd8?a",
      "display_url" : "youtu.be\/xbK0C9AYMd8?a"
    } ]
  },
  "geo" : { },
  "id_str" : "335791944666054657",
  "text" : "I liked a @YouTube video http:\/\/t.co\/xC0YbWnedH Chubby Checker - The Twist",
  "id" : 335791944666054657,
  "created_at" : "2013-05-18 16:20:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/71KpDTsdu5",
      "expanded_url" : "http:\/\/blog.galaxyzoo.org\/2013\/04\/09\/more-hubble-more-often\/",
      "display_url" : "blog.galaxyzoo.org\/2013\/04\/09\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "335741377524690945",
  "text" : "http:\/\/t.co\/71KpDTsdu5",
  "id" : 335741377524690945,
  "created_at" : "2013-05-18 12:59:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/335489472361799680\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/eJNIQMw65A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BKfl5cqCIAAD-xA.jpg",
      "id_str" : "335489472370188288",
      "id" : 335489472370188288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BKfl5cqCIAAD-xA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 567
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 567
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/eJNIQMw65A"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "335489472361799680",
  "text" : "IMDB Ranking Increased by 2,517,092, that has got to be a new world record http:\/\/t.co\/eJNIQMw65A",
  "id" : 335489472361799680,
  "created_at" : "2013-05-17 20:18:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 30, 42 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/YRwm2mFOsg",
      "expanded_url" : "http:\/\/youtu.be\/mphwRbplNS0?a",
      "display_url" : "youtu.be\/mphwRbplNS0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "334522539311239168",
  "text" : "I liked a @YouTube video from @gamer456148 http:\/\/t.co\/YRwm2mFOsg The Pentecost Begins Tonight!!!",
  "id" : 334522539311239168,
  "created_at" : "2013-05-15 04:16:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/YRwm2mFOsg",
      "expanded_url" : "http:\/\/youtu.be\/mphwRbplNS0?a",
      "display_url" : "youtu.be\/mphwRbplNS0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "334373330549362688",
  "text" : "The Pentecost Begins Tonight!!!: http:\/\/t.co\/YRwm2mFOsg via @YouTube",
  "id" : 334373330549362688,
  "created_at" : "2013-05-14 18:23:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Food Network",
      "screen_name" : "FoodNetwork",
      "indices" : [ 0, 12 ],
      "id_str" : "20710809",
      "id" : 20710809
    }, {
      "name" : "Food Network Canada",
      "screen_name" : "FoodNetworkCA",
      "indices" : [ 14, 28 ],
      "id_str" : "14500608",
      "id" : 14500608
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333992783352315905",
  "in_reply_to_user_id" : 20710809,
  "text" : "@FoodNetwork, @FoodNetworkCA What person doesn't like the taste of Mash Potatoes they taste so good, especially with chedder",
  "id" : 333992783352315905,
  "created_at" : "2013-05-13 17:10:59 +0000",
  "in_reply_to_screen_name" : "FoodNetwork",
  "in_reply_to_user_id_str" : "20710809",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Ww58YBKpkH",
      "expanded_url" : "http:\/\/hookit.com\/gamer456148",
      "display_url" : "hookit.com\/gamer456148"
    } ]
  },
  "geo" : { },
  "id_str" : "333811036710895616",
  "text" : "Reached 55 sponsors, 66 active programs, 17 Brand Reps, and 105K views on http:\/\/t.co\/Ww58YBKpkH",
  "id" : 333811036710895616,
  "created_at" : "2013-05-13 05:08:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 75, 83 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ZjT472CMtm",
      "expanded_url" : "http:\/\/youtu.be\/lRfvG1kFXLc?a",
      "display_url" : "youtu.be\/lRfvG1kFXLc?a"
    } ]
  },
  "geo" : { },
  "id_str" : "333090650536960000",
  "text" : "Luke Miller beat me in chess few weeks ago :(, but he is brilliant like I (@YouTube http:\/\/t.co\/ZjT472CMtm)",
  "id" : 333090650536960000,
  "created_at" : "2013-05-11 05:26:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 93, 101 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/09bVNHPTub",
      "expanded_url" : "http:\/\/youtu.be\/z9pD_UK6vGU?a",
      "display_url" : "youtu.be\/z9pD_UK6vGU?a"
    } ]
  },
  "geo" : { },
  "id_str" : "333090443657089026",
  "text" : "Encase you guys didn't know this, this is a joke, LOL&lt; I saw this at a FB group and just (@YouTube http:\/\/t.co\/09bVNHPTub)",
  "id" : 333090443657089026,
  "created_at" : "2013-05-11 05:25:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333053393272700928",
  "text" : "Book publishing is so hard",
  "id" : 333053393272700928,
  "created_at" : "2013-05-11 02:58:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/vvbkuj6521",
      "expanded_url" : "http:\/\/amazon.com",
      "display_url" : "amazon.com"
    } ]
  },
  "geo" : { },
  "id_str" : "333053228319133697",
  "text" : "read my new eBook at http:\/\/t.co\/vvbkuj6521",
  "id" : 333053228319133697,
  "created_at" : "2013-05-11 02:57:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "333053135499177984",
  "text" : "My dad hit me again and it hurts :\/",
  "id" : 333053135499177984,
  "created_at" : "2013-05-11 02:57:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332974496803848192",
  "text" : "Check this out http:\/\/fiverr com\/jake2424",
  "id" : 332974496803848192,
  "created_at" : "2013-05-10 21:44:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "332974437060194304",
  "text" : "http:\/\/fiverr. com\/jake2424",
  "id" : 332974437060194304,
  "created_at" : "2013-05-10 21:44:26 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/mtHtUkuM97",
      "expanded_url" : "http:\/\/youtu.be\/64LJkJuTzx0?a",
      "display_url" : "youtu.be\/64LJkJuTzx0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "332169506887720960",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/mtHtUkuM97 Coptic Hymn - Hos Erouf",
  "id" : 332169506887720960,
  "created_at" : "2013-05-08 16:25:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/ZNCSfAOWCR",
      "expanded_url" : "http:\/\/youtu.be\/46ctWLzBDpk?a",
      "display_url" : "youtu.be\/46ctWLzBDpk?a"
    } ]
  },
  "geo" : { },
  "id_str" : "331868086154170368",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/ZNCSfAOWCR COPTIC ORTHODOX HYMNS | Golgotha [Good Friday] The Burial Hymn",
  "id" : 331868086154170368,
  "created_at" : "2013-05-07 20:28:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/Nhk6opQwAO",
      "expanded_url" : "http:\/\/youtu.be\/8I0XBcq7Ub0?a",
      "display_url" : "youtu.be\/8I0XBcq7Ub0?a"
    } ]
  },
  "geo" : { },
  "id_str" : "331867988426911746",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/Nhk6opQwAO COPTIC ORTHODOX HYMNS | Singary Psalm Easter",
  "id" : 331867988426911746,
  "created_at" : "2013-05-07 20:27:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331549983692165121",
  "text" : "But am not sure, should I?",
  "id" : 331549983692165121,
  "created_at" : "2013-05-06 23:24:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "331549916285517824",
  "text" : "I am thinking of becoming a Coptic monk",
  "id" : 331549916285517824,
  "created_at" : "2013-05-06 23:23:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/xGUfgbpqKm",
      "expanded_url" : "http:\/\/blog.galaxyzoo.org\/2013\/04\/09\/more-hubble-more-often\/#comments",
      "display_url" : "blog.galaxyzoo.org\/2013\/04\/09\/mor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "331241221618012160",
  "text" : "http:\/\/t.co\/xGUfgbpqKm",
  "id" : 331241221618012160,
  "created_at" : "2013-05-06 02:57:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/6HWIqiibUB",
      "expanded_url" : "http:\/\/Vixra.org",
      "display_url" : "Vixra.org"
    } ]
  },
  "geo" : { },
  "id_str" : "330750928510672896",
  "text" : "http:\/\/t.co\/6HWIqiibUB",
  "id" : 330750928510672896,
  "created_at" : "2013-05-04 18:29:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/zgQL5hxJjJ",
      "expanded_url" : "http:\/\/sdrv.ms\/10d9bea",
      "display_url" : "sdrv.ms\/10d9bea"
    } ]
  },
  "geo" : { },
  "id_str" : "330717483319312384",
  "text" : "New haircut http:\/\/t.co\/zgQL5hxJjJ",
  "id" : 330717483319312384,
  "created_at" : "2013-05-04 16:16:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "330458148177580032",
  "text" : "Just talked to Jenna B. She is awesome, and so sweet",
  "id" : 330458148177580032,
  "created_at" : "2013-05-03 23:05:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/7yaBbwbeGk",
      "expanded_url" : "http:\/\/youtu.be\/QH0jgERjewY?a",
      "display_url" : "youtu.be\/QH0jgERjewY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "330355398949363714",
  "text" : "I liked a @YouTube video http:\/\/t.co\/7yaBbwbeGk Hallelujag (Leonard Cohen) AMKAMAL Coverup",
  "id" : 330355398949363714,
  "created_at" : "2013-05-03 16:17:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/hgOtebn9lw",
      "expanded_url" : "http:\/\/sdrv.ms\/10XqyFY",
      "display_url" : "sdrv.ms\/10XqyFY"
    } ]
  },
  "geo" : { },
  "id_str" : "329833317916614656",
  "text" : "Miracles happen, sometimes in your own house!!! http:\/\/t.co\/hgOtebn9lw",
  "id" : 329833317916614656,
  "created_at" : "2013-05-02 05:42:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 49, 57 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rh9ruHEEom",
      "expanded_url" : "http:\/\/youtu.be\/y9kp0s6mq90?a",
      "display_url" : "youtu.be\/y9kp0s6mq90?a"
    } ]
  },
  "geo" : { },
  "id_str" : "329756234087559169",
  "text" : "Love Autodesk, especially Autodesk Inventor 2.1 (@YouTube http:\/\/t.co\/rh9ruHEEom)",
  "id" : 329756234087559169,
  "created_at" : "2013-05-02 00:36:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "329664148264857600",
  "text" : "God bless dear Coptic brothers",
  "id" : 329664148264857600,
  "created_at" : "2013-05-01 18:30:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]