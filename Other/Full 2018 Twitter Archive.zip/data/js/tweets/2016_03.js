Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714154687885238272",
  "text" : "For God so loved the world, he gave his only son, so whoever believes in him shall inherit eternal life in Heaven",
  "id" : 714154687885238272,
  "created_at" : "2016-03-27 18:18:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/714154454317080576\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/O03Mk7vqEi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cekvrt7WAAMvIzj.jpg",
      "id_str" : "714154444024315907",
      "id" : 714154444024315907,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cekvrt7WAAMvIzj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1217
      }, {
        "h" : 402,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1217
      }, {
        "h" : 709,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/O03Mk7vqEi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714154454317080576",
  "text" : "I like how cross filters make photos look better, digital editing is a breeze nowadays https:\/\/t.co\/O03Mk7vqEi",
  "id" : 714154454317080576,
  "created_at" : "2016-03-27 18:17:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Holmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "714139313970159616",
  "geo" : { },
  "id_str" : "714139589506629632",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Decorate Easter eggs with your nephew, it will be so adorable",
  "id" : 714139589506629632,
  "in_reply_to_status_id" : 714139313970159616,
  "created_at" : "2016-03-27 17:18:40 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/713928399690076161\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/dEstL3Yvlw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CehiGJMXEAAigJt.jpg",
      "id_str" : "713928398624722944",
      "id" : 713928398624722944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CehiGJMXEAAigJt.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dEstL3Yvlw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/FwWUjQjsjq",
      "expanded_url" : "http:\/\/engt.co\/22DZ5bl",
      "display_url" : "engt.co\/22DZ5bl"
    } ]
  },
  "geo" : { },
  "id_str" : "714111405771907073",
  "text" : "RT @engadget: Lockheed Martin's hypersonic aircraft plans are taking shape https:\/\/t.co\/FwWUjQjsjq https:\/\/t.co\/dEstL3Yvlw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/713928399690076161\/photo\/1",
        "indices" : [ 85, 108 ],
        "url" : "https:\/\/t.co\/dEstL3Yvlw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CehiGJMXEAAigJt.jpg",
        "id_str" : "713928398624722944",
        "id" : 713928398624722944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CehiGJMXEAAigJt.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/dEstL3Yvlw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/FwWUjQjsjq",
        "expanded_url" : "http:\/\/engt.co\/22DZ5bl",
        "display_url" : "engt.co\/22DZ5bl"
      } ]
    },
    "geo" : { },
    "id_str" : "713928399690076161",
    "text" : "Lockheed Martin's hypersonic aircraft plans are taking shape https:\/\/t.co\/FwWUjQjsjq https:\/\/t.co\/dEstL3Yvlw",
    "id" : 713928399690076161,
    "created_at" : "2016-03-27 03:19:29 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 714111405771907073,
  "created_at" : "2016-03-27 15:26:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/0mamaT182j",
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/714098399646191616",
      "display_url" : "twitter.com\/slidenerdtech\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "714110776089382912",
  "text" : "Haha https:\/\/t.co\/0mamaT182j",
  "id" : 714110776089382912,
  "created_at" : "2016-03-27 15:24:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/c1pZEtT8KI",
      "expanded_url" : "http:\/\/ow.ly\/YZxK0",
      "display_url" : "ow.ly\/YZxK0"
    } ]
  },
  "geo" : { },
  "id_str" : "714110671131189248",
  "text" : "RT @BarbaraCorcoran: In school I couldn't learn, but it taught me to use my imagination to fill in the blanks.https:\/\/t.co\/c1pZEtT8KI via @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "INQUISITR",
        "screen_name" : "theinquisitr",
        "indices" : [ 117, 130 ],
        "id_str" : "14722676",
        "id" : 14722676
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/c1pZEtT8KI",
        "expanded_url" : "http:\/\/ow.ly\/YZxK0",
        "display_url" : "ow.ly\/YZxK0"
      } ]
    },
    "geo" : { },
    "id_str" : "714035543290605569",
    "text" : "In school I couldn't learn, but it taught me to use my imagination to fill in the blanks.https:\/\/t.co\/c1pZEtT8KI via @TheInquisitr",
    "id" : 714035543290605569,
    "created_at" : "2016-03-27 10:25:14 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 714110671131189248,
  "created_at" : "2016-03-27 15:23:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/AmdhenTjmC",
      "expanded_url" : "http:\/\/fb.me\/4Eyd476VR",
      "display_url" : "fb.me\/4Eyd476VR"
    } ]
  },
  "geo" : { },
  "id_str" : "714110625866256384",
  "text" : "RT @EmperorDarroux: 8 Microsoft Word features that will take you to the next level https:\/\/t.co\/AmdhenTjmC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/AmdhenTjmC",
        "expanded_url" : "http:\/\/fb.me\/4Eyd476VR",
        "display_url" : "fb.me\/4Eyd476VR"
      } ]
    },
    "geo" : { },
    "id_str" : "714109977955164161",
    "text" : "8 Microsoft Word features that will take you to the next level https:\/\/t.co\/AmdhenTjmC",
    "id" : 714109977955164161,
    "created_at" : "2016-03-27 15:21:00 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 714110625866256384,
  "created_at" : "2016-03-27 15:23:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/714110184612884484\/photo\/1",
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/hhHBPEW3y1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CekHbHbWQAAbyiG.jpg",
      "id_str" : "714110178346549248",
      "id" : 714110178346549248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CekHbHbWQAAbyiG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 579
      }, {
        "h" : 752,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hhHBPEW3y1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714110184612884484",
  "text" : "Highest form of conservatism according to this poll, even though the questions seemed a bit snarky https:\/\/t.co\/hhHBPEW3y1",
  "id" : 714110184612884484,
  "created_at" : "2016-03-27 15:21:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713091733479899136",
  "text" : "RT @BarbaraCorcoran: Stop comparing yourself to everyone else around you. If you\u2019re busy minding someone else\u2019s business, no one is minding\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "713059235656044544",
    "text" : "Stop comparing yourself to everyone else around you. If you\u2019re busy minding someone else\u2019s business, no one is minding yours.",
    "id" : 713059235656044544,
    "created_at" : "2016-03-24 17:45:44 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 713091733479899136,
  "created_at" : "2016-03-24 19:54:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 14, 30 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/jceD6Fp8iq",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/017eb381-5fc4-49fc-8255-3ddaf8c63745",
      "display_url" : "amp.twimg.com\/v\/017eb381-5fc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "713091701397696512",
  "text" : "RT @tedcruz: .@realDonaldTrump has been supporting leftwing, liberal Democratic politicians for 40 years.\nhttps:\/\/t.co\/jceD6Fp8iq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/jceD6Fp8iq",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/017eb381-5fc4-49fc-8255-3ddaf8c63745",
        "display_url" : "amp.twimg.com\/v\/017eb381-5fc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "712794593230585856",
    "text" : ".@realDonaldTrump has been supporting leftwing, liberal Democratic politicians for 40 years.\nhttps:\/\/t.co\/jceD6Fp8iq",
    "id" : 712794593230585856,
    "created_at" : "2016-03-24 00:14:08 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 713091701397696512,
  "created_at" : "2016-03-24 19:54:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 3, 16 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "713091607269081088",
  "text" : "RT @JosefLokmani: @gamer456148 looks great",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "712681646785486849",
    "geo" : { },
    "id_str" : "713078209965920257",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 looks great",
    "id" : 713078209965920257,
    "in_reply_to_status_id" : 712681646785486849,
    "created_at" : "2016-03-24 19:01:08 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "protected" : false,
      "id_str" : "703541068462235648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836658752577290241\/4sTW-DBF_normal.jpg",
      "id" : 703541068462235648,
      "verified" : false
    }
  },
  "id" : 713091607269081088,
  "created_at" : "2016-03-24 19:54:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/712681646785486849\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/7c9EXed8SN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeP0KLdXIAULTZ3.jpg",
      "id_str" : "712681621766479877",
      "id" : 712681621766479877,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeP0KLdXIAULTZ3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/7c9EXed8SN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712681646785486849",
  "text" : "Definitely a 5 star burger from Buddy's https:\/\/t.co\/7c9EXed8SN",
  "id" : 712681646785486849,
  "created_at" : "2016-03-23 16:45:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Startup Grind",
      "screen_name" : "StartupGrind",
      "indices" : [ 3, 16 ],
      "id_str" : "108698830",
      "id" : 108698830
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StartupGrind\/status\/712246051843997696\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/I7RAI0JSOf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeJn_d6UsAE6PmF.jpg",
      "id_str" : "712246031136632833",
      "id" : 712246031136632833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeJn_d6UsAE6PmF.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 732
      }, {
        "h" : 490,
        "resize" : "fit",
        "w" : 732
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/I7RAI0JSOf"
    } ],
    "hashtags" : [ {
      "text" : "JeSuisBruxelles",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "712399754160959488",
  "text" : "RT @StartupGrind: Our thoughts are with Brussels today   #JeSuisBruxelles https:\/\/t.co\/I7RAI0JSOf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StartupGrind\/status\/712246051843997696\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/I7RAI0JSOf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeJn_d6UsAE6PmF.jpg",
        "id_str" : "712246031136632833",
        "id" : 712246031136632833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeJn_d6UsAE6PmF.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 732
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 732
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 732
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/I7RAI0JSOf"
      } ],
      "hashtags" : [ {
        "text" : "JeSuisBruxelles",
        "indices" : [ 39, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "712246051843997696",
    "text" : "Our thoughts are with Brussels today   #JeSuisBruxelles https:\/\/t.co\/I7RAI0JSOf",
    "id" : 712246051843997696,
    "created_at" : "2016-03-22 11:54:26 +0000",
    "user" : {
      "name" : "Startup Grind",
      "screen_name" : "StartupGrind",
      "protected" : false,
      "id_str" : "108698830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1060159994732011520\/I-trzNUF_normal.jpg",
      "id" : 108698830,
      "verified" : true
    }
  },
  "id" : 712399754160959488,
  "created_at" : "2016-03-22 22:05:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/711973615923761152\/photo\/1",
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Pb8q9Lzdrz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeFwNxcWIAA5QM0.jpg",
      "id_str" : "711973598014087168",
      "id" : 711973598014087168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeFwNxcWIAA5QM0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/Pb8q9Lzdrz"
    } ],
    "hashtags" : [ {
      "text" : "JackASS",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711973615923761152",
  "text" : "When someone hits your car and leaves while you were parked and outside. #JackASS https:\/\/t.co\/Pb8q9Lzdrz",
  "id" : 711973615923761152,
  "created_at" : "2016-03-21 17:51:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/711963582112509952\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/4PVGaNFhrY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CeFnFQzUsAE0iEs.jpg",
      "id_str" : "711963556208488449",
      "id" : 711963556208488449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeFnFQzUsAE0iEs.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/4PVGaNFhrY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711963582112509952",
  "text" : "Went to Hamlin Pub, had the Wow burger: 4.3\/5 stars https:\/\/t.co\/4PVGaNFhrY",
  "id" : 711963582112509952,
  "created_at" : "2016-03-21 17:12:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "indices" : [ 3, 15 ],
      "id_str" : "19253334",
      "id" : 19253334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/L85C8G63X2",
      "expanded_url" : "http:\/\/bit.ly\/25e6soE",
      "display_url" : "bit.ly\/25e6soE"
    } ]
  },
  "geo" : { },
  "id_str" : "711720094611673090",
  "text" : "RT @pluralsight: 46% of devs don't have compsci degrees and other stats from Stack Overflow's annual survey: https:\/\/t.co\/L85C8G63X2 https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.salesforce.com\" rel=\"nofollow\"\u003ESalesforce - Social Studio\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pluralsight\/status\/711698599453847553\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/MqylEYP4TD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CeB2GsKW8AA2urO.jpg",
        "id_str" : "711698598430437376",
        "id" : 711698598430437376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CeB2GsKW8AA2urO.jpg",
        "sizes" : [ {
          "h" : 587,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1308
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1308
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/MqylEYP4TD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/L85C8G63X2",
        "expanded_url" : "http:\/\/bit.ly\/25e6soE",
        "display_url" : "bit.ly\/25e6soE"
      } ]
    },
    "geo" : { },
    "id_str" : "711698599453847553",
    "text" : "46% of devs don't have compsci degrees and other stats from Stack Overflow's annual survey: https:\/\/t.co\/L85C8G63X2 https:\/\/t.co\/MqylEYP4TD",
    "id" : 711698599453847553,
    "created_at" : "2016-03-20 23:39:03 +0000",
    "user" : {
      "name" : "Pluralsight",
      "screen_name" : "pluralsight",
      "protected" : false,
      "id_str" : "19253334",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1037405801743171584\/Cy-t4ONq_normal.jpg",
      "id" : 19253334,
      "verified" : true
    }
  },
  "id" : 711720094611673090,
  "created_at" : "2016-03-21 01:04:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "leadbyexample",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711719650699120640",
  "text" : "RT @BarbaraCorcoran: If you want to have a creative culture, you can't get it by reading books. You get it by example. #leadbyexample",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "leadbyexample",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711590882173165569",
    "text" : "If you want to have a creative culture, you can't get it by reading books. You get it by example. #leadbyexample",
    "id" : 711590882173165569,
    "created_at" : "2016-03-20 16:31:01 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 711719650699120640,
  "created_at" : "2016-03-21 01:02:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711719618252038144",
  "text" : "RT @tedcruz: I have a word for the people of Cuba who will witness the gaudy spectacle in Havana: America has not forgotten you: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/AiTSTraOPA",
        "expanded_url" : "http:\/\/www.politico.com\/magazine\/story\/2016\/03\/obama-cuba-visit-ted-cruz-213749",
        "display_url" : "politico.com\/magazine\/story\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "711655952970219520",
    "text" : "I have a word for the people of Cuba who will witness the gaudy spectacle in Havana: America has not forgotten you: https:\/\/t.co\/AiTSTraOPA",
    "id" : 711655952970219520,
    "created_at" : "2016-03-20 20:49:35 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 711719618252038144,
  "created_at" : "2016-03-21 01:02:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justine Ezarik",
      "screen_name" : "ijustine",
      "indices" : [ 0, 9 ],
      "id_str" : "7846",
      "id" : 7846
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "711667897513418753",
  "geo" : { },
  "id_str" : "711719485485555713",
  "in_reply_to_user_id" : 7846,
  "text" : "@ijustine Happy Birthday to one of the few female techies on YouTube with a quirky personality",
  "id" : 711719485485555713,
  "in_reply_to_status_id" : 711667897513418753,
  "created_at" : "2016-03-21 01:02:03 +0000",
  "in_reply_to_screen_name" : "ijustine",
  "in_reply_to_user_id_str" : "7846",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaffyDonald",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711719204957847552",
  "text" : "RT @tedcruz: Dear #DaffyDonald, don't be scared. It seems you're confused on some of my policy positions. Let's debate and clear this up.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DaffyDonald",
        "indices" : [ 5, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "711273509914152960",
    "text" : "Dear #DaffyDonald, don't be scared. It seems you're confused on some of my policy positions. Let's debate and clear this up.",
    "id" : 711273509914152960,
    "created_at" : "2016-03-19 19:29:54 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 711719204957847552,
  "created_at" : "2016-03-21 01:00:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709519051815567360",
  "text" : "RT @BarbaraCorcoran: The difference between people who are hugely successful &amp; those who aren\u2019t is the time it takes them to get back up af\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "709459237857042433",
    "text" : "The difference between people who are hugely successful &amp; those who aren\u2019t is the time it takes them to get back up after being knocked down",
    "id" : 709459237857042433,
    "created_at" : "2016-03-14 19:20:38 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 709519051815567360,
  "created_at" : "2016-03-14 23:18:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "indices" : [ 3, 17 ],
      "id_str" : "179245596",
      "id" : 179245596
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 38, 46 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709518403975946242",
  "text" : "RT @DavidLimbaugh: But my support for @tedcruz \u2014 as rock solid as it is \u2014 is not based on idolatry, hero-worship, or cult of personality. H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 19, 27 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "709180762801573888",
    "text" : "But my support for @tedcruz \u2014 as rock solid as it is \u2014 is not based on idolatry, hero-worship, or cult of personality. He\u2019s the real deal.",
    "id" : 709180762801573888,
    "created_at" : "2016-03-14 00:54:04 +0000",
    "user" : {
      "name" : "David Limbaugh",
      "screen_name" : "DavidLimbaugh",
      "protected" : false,
      "id_str" : "179245596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2570040697\/bnbr5p86kg4a4t1e9wa9_normal.png",
      "id" : 179245596,
      "verified" : false
    }
  },
  "id" : 709518403975946242,
  "created_at" : "2016-03-14 23:15:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Mekota",
      "screen_name" : "PettieBettie",
      "indices" : [ 3, 16 ],
      "id_str" : "838211755",
      "id" : 838211755
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CLE",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709093208941326336",
  "text" : "RT @PettieBettie: #CLE is amazing, thank you all! Would like to let you know Kelly Blazek has sent a very nice apology email, for which I t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CLE",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "438440482314526720",
    "text" : "#CLE is amazing, thank you all! Would like to let you know Kelly Blazek has sent a very nice apology email, for which I thank her.",
    "id" : 438440482314526720,
    "created_at" : "2014-02-25 22:28:51 +0000",
    "user" : {
      "name" : "Diana Mekota",
      "screen_name" : "PettieBettie",
      "protected" : false,
      "id_str" : "838211755",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/455731625641254913\/rUtTszrY_normal.jpeg",
      "id" : 838211755,
      "verified" : false
    }
  },
  "id" : 709093208941326336,
  "created_at" : "2016-03-13 19:06:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WBK",
      "screen_name" : "WBKnoblock",
      "indices" : [ 3, 14 ],
      "id_str" : "26518374",
      "id" : 26518374
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707276898666020864",
  "text" : "RT @WBKnoblock: Michigan, go vote! For registered republicans, this is an extremely important state if you're Anti-Trump.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "707256220533526529",
    "text" : "Michigan, go vote! For registered republicans, this is an extremely important state if you're Anti-Trump.",
    "id" : 707256220533526529,
    "created_at" : "2016-03-08 17:26:37 +0000",
    "user" : {
      "name" : "WBK",
      "screen_name" : "WBKnoblock",
      "protected" : false,
      "id_str" : "26518374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/960469843148292096\/j1vu0Gyp_normal.jpg",
      "id" : 26518374,
      "verified" : false
    }
  },
  "id" : 707276898666020864,
  "created_at" : "2016-03-08 18:48:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/707003663437406208\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/WlcNiGV4EO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cc_IFB3WIAAaPGk.jpg",
      "id_str" : "707003655245930496",
      "id" : 707003655245930496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cc_IFB3WIAAaPGk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1050
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/WlcNiGV4EO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "707003663437406208",
  "text" : "God's creation is a masterpiece not something meant to make defamatory comments towards. We should love God's work. https:\/\/t.co\/WlcNiGV4EO",
  "id" : 707003663437406208,
  "created_at" : "2016-03-08 00:43:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherri Crepeau",
      "screen_name" : "jmurbulldog",
      "indices" : [ 3, 15 ],
      "id_str" : "742450574575177728",
      "id" : 742450574575177728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706671806644686850",
  "text" : "RT @jmurbulldog: What an incredible woman Nancy Reagan was, I pray my future wife will love me as much as she loved Ronald - RIP \uD83D\uDE4F\uD83C\uDFFB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706630336860561408",
    "text" : "What an incredible woman Nancy Reagan was, I pray my future wife will love me as much as she loved Ronald - RIP \uD83D\uDE4F\uD83C\uDFFB",
    "id" : 706630336860561408,
    "created_at" : "2016-03-06 23:59:35 +0000",
    "user" : {
      "name" : "Josh Allan Murray",
      "screen_name" : "JoshAllanMurray",
      "protected" : false,
      "id_str" : "184005873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1021916093152030721\/-c5xQszt_normal.jpg",
      "id" : 184005873,
      "verified" : true
    }
  },
  "id" : 706671806644686850,
  "created_at" : "2016-03-07 02:44:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mackenzie\u30C3",
      "screen_name" : "BigmacHill",
      "indices" : [ 0, 11 ],
      "id_str" : "500135383",
      "id" : 500135383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "700743584832757760",
  "geo" : { },
  "id_str" : "706671113888264192",
  "in_reply_to_user_id" : 500135383,
  "text" : "@BigmacHill Wow parking was that good, lol \uD83D\uDE02\uD83D\uDE0E",
  "id" : 706671113888264192,
  "in_reply_to_status_id" : 700743584832757760,
  "created_at" : "2016-03-07 02:41:37 +0000",
  "in_reply_to_screen_name" : "BigmacHill",
  "in_reply_to_user_id_str" : "500135383",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emily",
      "screen_name" : "Emily_Blue29",
      "indices" : [ 3, 16 ],
      "id_str" : "562129618",
      "id" : 562129618
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisisOU",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706670515902091264",
  "text" : "RT @Emily_Blue29: Finding a parking spot at 1030 on a Monday is just such a personal victory #thisisOU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thisisOU",
        "indices" : [ 75, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704329057090019328",
    "text" : "Finding a parking spot at 1030 on a Monday is just such a personal victory #thisisOU",
    "id" : 704329057090019328,
    "created_at" : "2016-02-29 15:35:07 +0000",
    "user" : {
      "name" : "Emily",
      "screen_name" : "Emily_Blue29",
      "protected" : false,
      "id_str" : "562129618",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/856274000758149120\/p6VkYgPE_normal.jpg",
      "id" : 562129618,
      "verified" : false
    }
  },
  "id" : 706670515902091264,
  "created_at" : "2016-03-07 02:39:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Lite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Owen James (March 18)",
      "screen_name" : "owenjamesja",
      "indices" : [ 3, 15 ],
      "id_str" : "37738151",
      "id" : 37738151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "706669897804341249",
  "text" : "RT @owenjamesja: Nancy Reagan was a true wife who believed in the vow \"....for better or worse...\"  RIP Mrs. R.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "706668975137030144",
    "text" : "Nancy Reagan was a true wife who believed in the vow \"....for better or worse...\"  RIP Mrs. R.",
    "id" : 706668975137030144,
    "created_at" : "2016-03-07 02:33:07 +0000",
    "user" : {
      "name" : "Owen James (March 18)",
      "screen_name" : "owenjamesja",
      "protected" : false,
      "id_str" : "37738151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3056167815\/73106a543aa9cabb19999b77fb9e7f85_normal.jpeg",
      "id" : 37738151,
      "verified" : false
    }
  },
  "id" : 706669897804341249,
  "created_at" : "2016-03-07 02:36:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "indices" : [ 3, 14 ],
      "id_str" : "305791165",
      "id" : 305791165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/JgFCMZslof",
      "expanded_url" : "http:\/\/vine.co\/v\/M1IOZFHzYdW",
      "display_url" : "vine.co\/v\/M1IOZFHzYdW"
    } ]
  },
  "geo" : { },
  "id_str" : "705976976075595776",
  "text" : "RT @WWEXStream: How to hitchhike.. https:\/\/t.co\/JgFCMZslof",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/JgFCMZslof",
        "expanded_url" : "http:\/\/vine.co\/v\/M1IOZFHzYdW",
        "display_url" : "vine.co\/v\/M1IOZFHzYdW"
      } ]
    },
    "geo" : { },
    "id_str" : "705976728582279168",
    "text" : "How to hitchhike.. https:\/\/t.co\/JgFCMZslof",
    "id" : 705976728582279168,
    "created_at" : "2016-03-05 04:42:23 +0000",
    "user" : {
      "name" : "WWEXStream.com",
      "screen_name" : "WWEXStream",
      "protected" : false,
      "id_str" : "305791165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465976113496223744\/iEGR6Kkr_normal.jpeg",
      "id" : 305791165,
      "verified" : false
    }
  },
  "id" : 705976976075595776,
  "created_at" : "2016-03-05 04:43:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705976364923555840",
  "text" : "RT @JustOneAsian: The smell of gasoline &gt;&gt;&gt;&gt;&gt;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705970688188932097",
    "text" : "The smell of gasoline &gt;&gt;&gt;&gt;&gt;",
    "id" : 705970688188932097,
    "created_at" : "2016-03-05 04:18:23 +0000",
    "user" : {
      "name" : "Tommy \u30C4",
      "screen_name" : "Asian_Made",
      "protected" : false,
      "id_str" : "263330949",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/986796980469891072\/wfXqA8xu_normal.jpg",
      "id" : 263330949,
      "verified" : false
    }
  },
  "id" : 705976364923555840,
  "created_at" : "2016-03-05 04:40:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LifeWay Men",
      "screen_name" : "LifeWayMen",
      "indices" : [ 0, 11 ],
      "id_str" : "250314657",
      "id" : 250314657
    }, {
      "name" : "Tim DeTellis",
      "screen_name" : "timdetellis",
      "indices" : [ 12, 24 ],
      "id_str" : "15975925",
      "id" : 15975925
    }, {
      "name" : "Tim Tebow",
      "screen_name" : "TimTebow",
      "indices" : [ 25, 34 ],
      "id_str" : "166270127",
      "id" : 166270127
    }, {
      "name" : "Johnny Hunt",
      "screen_name" : "johnnymhunt",
      "indices" : [ 35, 47 ],
      "id_str" : "50281265",
      "id" : 50281265
    }, {
      "name" : "Nick Vujicic",
      "screen_name" : "nickvujicic",
      "indices" : [ 48, 60 ],
      "id_str" : "15601251",
      "id" : 15601251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705849057017630720",
  "geo" : { },
  "id_str" : "705976056285675520",
  "in_reply_to_user_id" : 250314657,
  "text" : "@LifeWayMen @timdetellis @TimTebow @johnnymhunt @nickvujicic Wish I could've attended :&gt;)",
  "id" : 705976056285675520,
  "in_reply_to_status_id" : 705849057017630720,
  "created_at" : "2016-03-05 04:39:42 +0000",
  "in_reply_to_screen_name" : "LifeWayMen",
  "in_reply_to_user_id_str" : "250314657",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Olsen",
      "screen_name" : "PeteOlsen",
      "indices" : [ 3, 13 ],
      "id_str" : "18183592",
      "id" : 18183592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/SmQiTKHP44",
      "expanded_url" : "http:\/\/fb.me\/7aZqhUlRG",
      "display_url" : "fb.me\/7aZqhUlRG"
    } ]
  },
  "geo" : { },
  "id_str" : "705975804237377536",
  "text" : "RT @PeteOlsen: Unbelievable meal! \u2014 eating Thai food at Ryohin Asian Fusion Restaurant https:\/\/t.co\/SmQiTKHP44",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/SmQiTKHP44",
        "expanded_url" : "http:\/\/fb.me\/7aZqhUlRG",
        "display_url" : "fb.me\/7aZqhUlRG"
      } ]
    },
    "geo" : { },
    "id_str" : "705969410238840833",
    "text" : "Unbelievable meal! \u2014 eating Thai food at Ryohin Asian Fusion Restaurant https:\/\/t.co\/SmQiTKHP44",
    "id" : 705969410238840833,
    "created_at" : "2016-03-05 04:13:18 +0000",
    "user" : {
      "name" : "Peter Olsen",
      "screen_name" : "PeteOlsen",
      "protected" : false,
      "id_str" : "18183592",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979450565385109504\/XeVyTueE_normal.jpg",
      "id" : 18183592,
      "verified" : false
    }
  },
  "id" : 705975804237377536,
  "created_at" : "2016-03-05 04:38:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "indices" : [ 3, 14 ],
      "id_str" : "222482865",
      "id" : 222482865
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/amitava235\/status\/705468334079348738\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/hc67rkvFty",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcpTtjtWIAU6i66.jpg",
      "id_str" : "705468333781557253",
      "id" : 705468333781557253,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcpTtjtWIAU6i66.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/hc67rkvFty"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/CSuoBSaQVY",
      "expanded_url" : "http:\/\/tvista.in\/1ORvFJL",
      "display_url" : "tvista.in\/1ORvFJL"
    } ]
  },
  "geo" : { },
  "id_str" : "705975678039101440",
  "text" : "RT @amitava235: Robotic Animals Will Soon be the Nemesis of the Poachers\nRead on: https:\/\/t.co\/CSuoBSaQVY https:\/\/t.co\/hc67rkvFty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/amitava235\/status\/705468334079348738\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/hc67rkvFty",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcpTtjtWIAU6i66.jpg",
        "id_str" : "705468333781557253",
        "id" : 705468333781557253,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcpTtjtWIAU6i66.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/hc67rkvFty"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/CSuoBSaQVY",
        "expanded_url" : "http:\/\/tvista.in\/1ORvFJL",
        "display_url" : "tvista.in\/1ORvFJL"
      } ]
    },
    "geo" : { },
    "id_str" : "705468334079348738",
    "text" : "Robotic Animals Will Soon be the Nemesis of the Poachers\nRead on: https:\/\/t.co\/CSuoBSaQVY https:\/\/t.co\/hc67rkvFty",
    "id" : 705468334079348738,
    "created_at" : "2016-03-03 19:02:12 +0000",
    "user" : {
      "name" : "Amitava Sarkar",
      "screen_name" : "amitava235",
      "protected" : false,
      "id_str" : "222482865",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/556878626906722304\/R-U_SUZW_normal.jpeg",
      "id" : 222482865,
      "verified" : false
    }
  },
  "id" : 705975678039101440,
  "created_at" : "2016-03-05 04:38:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ZByU924T3d",
      "expanded_url" : "http:\/\/fb.me\/6oweEB1zz",
      "display_url" : "fb.me\/6oweEB1zz"
    } ]
  },
  "geo" : { },
  "id_str" : "705975592336924672",
  "text" : "RT @EmperorDarroux: This is what happens when you put marshmallows in a vacuum https:\/\/t.co\/ZByU924T3d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/ZByU924T3d",
        "expanded_url" : "http:\/\/fb.me\/6oweEB1zz",
        "display_url" : "fb.me\/6oweEB1zz"
      } ]
    },
    "geo" : { },
    "id_str" : "705467998887288832",
    "text" : "This is what happens when you put marshmallows in a vacuum https:\/\/t.co\/ZByU924T3d",
    "id" : 705467998887288832,
    "created_at" : "2016-03-03 19:00:52 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 705975592336924672,
  "created_at" : "2016-03-05 04:37:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "geo" : { },
  "id_str" : "705973966775656448",
  "text" : "Still waiting for real Hoverboards https:\/\/t.co\/HfViSZFgjj",
  "id" : 705973966775656448,
  "created_at" : "2016-03-05 04:31:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/HfViSZFgjj",
      "expanded_url" : "http:\/\/bit.ly\/1NLrEdr",
      "display_url" : "bit.ly\/1NLrEdr"
    } ]
  },
  "geo" : { },
  "id_str" : "705973878343012352",
  "text" : "A book I wrote before https:\/\/t.co\/HfViSZFgjj",
  "id" : 705973878343012352,
  "created_at" : "2016-03-05 04:31:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alice Perkins",
      "screen_name" : "AlicePerkins6",
      "indices" : [ 3, 17 ],
      "id_str" : "578765420",
      "id" : 578765420
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlicePerkins6\/status\/685130125436911616\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1dfSKjnrpp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYISN7wW8AAz2FD.jpg",
      "id_str" : "685130123901857792",
      "id" : 685130123901857792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYISN7wW8AAz2FD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2073,
        "resize" : "fit",
        "w" : 2764
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/1dfSKjnrpp"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/AlicePerkins6\/status\/685130125436911616\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/1dfSKjnrpp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CYISHXaWQAA8FfD.jpg",
      "id_str" : "685130011066646528",
      "id" : 685130011066646528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYISHXaWQAA8FfD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 3240,
        "resize" : "fit",
        "w" : 4320
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/1dfSKjnrpp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705973683282644992",
  "text" : "RT @AlicePerkins6: Happy new year sweets!!! This is my beautiful kitty \u2605\u2605\u2605. https:\/\/t.co\/1dfSKjnrpp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlicePerkins6\/status\/685130125436911616\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/1dfSKjnrpp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYISN7wW8AAz2FD.jpg",
        "id_str" : "685130123901857792",
        "id" : 685130123901857792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYISN7wW8AAz2FD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2073,
          "resize" : "fit",
          "w" : 2764
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1dfSKjnrpp"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AlicePerkins6\/status\/685130125436911616\/photo\/1",
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/1dfSKjnrpp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CYISHXaWQAA8FfD.jpg",
        "id_str" : "685130011066646528",
        "id" : 685130011066646528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CYISHXaWQAA8FfD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 3240,
          "resize" : "fit",
          "w" : 4320
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1dfSKjnrpp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "685130125436911616",
    "text" : "Happy new year sweets!!! This is my beautiful kitty \u2605\u2605\u2605. https:\/\/t.co\/1dfSKjnrpp",
    "id" : 685130125436911616,
    "created_at" : "2016-01-07 16:05:25 +0000",
    "user" : {
      "name" : "Alice Perkins",
      "screen_name" : "AlicePerkins6",
      "protected" : false,
      "id_str" : "578765420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1062853145917820929\/mlQA8AR7_normal.jpg",
      "id" : 578765420,
      "verified" : false
    }
  },
  "id" : 705973683282644992,
  "created_at" : "2016-03-05 04:30:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 14, 22 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 26, 41 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/705957516107079682\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/oA9SNBZrMX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccvff7NWoAAI-My.jpg",
      "id_str" : "705903506176253952",
      "id" : 705903506176253952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccvff7NWoAAI-My.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/oA9SNBZrMX"
    } ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705973473248731137",
  "text" : "RT @FoxNews: .@tedcruz on @HillaryClinton's legal woes: \u201COrange is the new Democratic blue.\u201D #Hannity https:\/\/t.co\/oA9SNBZrMX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 1, 9 ],
        "id_str" : "23022687",
        "id" : 23022687
      }, {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 13, 28 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/705957516107079682\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/oA9SNBZrMX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ccvff7NWoAAI-My.jpg",
        "id_str" : "705903506176253952",
        "id" : 705903506176253952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ccvff7NWoAAI-My.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/oA9SNBZrMX"
      } ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705957516107079682",
    "text" : ".@tedcruz on @HillaryClinton's legal woes: \u201COrange is the new Democratic blue.\u201D #Hannity https:\/\/t.co\/oA9SNBZrMX",
    "id" : 705957516107079682,
    "created_at" : "2016-03-05 03:26:02 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 705973473248731137,
  "created_at" : "2016-03-05 04:29:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hannity",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "CPAC",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705973264020062208",
  "text" : "RT @seanhannity: Still to Come on #Hannity: My #CPAC speech about insurgent candidates &amp; why Republicans need to come together to take down\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hillary Clinton",
        "screen_name" : "HillaryClinton",
        "indices" : [ 127, 142 ],
        "id_str" : "1339835893",
        "id" : 1339835893
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 17, 25 ]
      }, {
        "text" : "CPAC",
        "indices" : [ 30, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705962808647614464",
    "text" : "Still to Come on #Hannity: My #CPAC speech about insurgent candidates &amp; why Republicans need to come together to take down @HillaryClinton.",
    "id" : 705962808647614464,
    "created_at" : "2016-03-05 03:47:04 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 705973264020062208,
  "created_at" : "2016-03-05 04:28:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Holmes",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dowork",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705973238829096962",
  "text" : "RT @HelloRyanHolmes: Juggling YouTube videos, 2nd channel vlogs, social media, gaming, and everything else is an all day thing. #dowork #wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dowork",
        "indices" : [ 107, 114 ]
      }, {
        "text" : "workinghard",
        "indices" : [ 115, 127 ]
      }, {
        "text" : "rhodeisland",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705673412505567233",
    "text" : "Juggling YouTube videos, 2nd channel vlogs, social media, gaming, and everything else is an all day thing. #dowork #workinghard #rhodeisland",
    "id" : 705673412505567233,
    "created_at" : "2016-03-04 08:37:06 +0000",
    "user" : {
      "name" : "Ryan Holmes",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1055572637496287237\/3ZiHrhBM_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 705973238829096962,
  "created_at" : "2016-03-05 04:28:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/705614366683566080\/photo\/1",
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/AskXcCNuAj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcrYhwhWEAAhkf1.jpg",
      "id_str" : "705614366108946432",
      "id" : 705614366108946432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcrYhwhWEAAhkf1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1262,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 285
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 162
      }, {
        "h" : 1262,
        "resize" : "fit",
        "w" : 300
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/AskXcCNuAj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705614366683566080",
  "text" : "Lasting relationships in one picture, lol https:\/\/t.co\/AskXcCNuAj",
  "id" : 705614366683566080,
  "created_at" : "2016-03-04 04:42:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 3, 16 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 18, 28 ],
      "id_str" : "618294231",
      "id" : 618294231
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 29, 41 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705169155939504130",
  "text" : "RT @JosefLokmani: @_grammar_ @gamer456148 I wonder what a grammar FBI would recommend.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grammar Police",
        "screen_name" : "_grammar_",
        "indices" : [ 0, 10 ],
        "id_str" : "618294231",
        "id" : 618294231
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 11, 23 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "705117485549260800",
    "geo" : { },
    "id_str" : "705161972157976577",
    "in_reply_to_user_id" : 618294231,
    "text" : "@_grammar_ @gamer456148 I wonder what a grammar FBI would recommend.",
    "id" : 705161972157976577,
    "in_reply_to_status_id" : 705117485549260800,
    "created_at" : "2016-03-02 22:44:50 +0000",
    "in_reply_to_screen_name" : "_grammar_",
    "in_reply_to_user_id_str" : "618294231",
    "user" : {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "protected" : false,
      "id_str" : "703541068462235648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836658752577290241\/4sTW-DBF_normal.jpg",
      "id" : 703541068462235648,
      "verified" : false
    }
  },
  "id" : 705169155939504130,
  "created_at" : "2016-03-02 23:13:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 3, 16 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 18, 30 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705169142459068416",
  "text" : "RT @JosefLokmani: @gamer456148 sup, yeah. That looks awesome.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "705152249174085632",
    "geo" : { },
    "id_str" : "705158173892734977",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 sup, yeah. That looks awesome.",
    "id" : 705158173892734977,
    "in_reply_to_status_id" : 705152249174085632,
    "created_at" : "2016-03-02 22:29:44 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "protected" : false,
      "id_str" : "703541068462235648",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836658752577290241\/4sTW-DBF_normal.jpg",
      "id" : 703541068462235648,
      "verified" : false
    }
  },
  "id" : 705169142459068416,
  "created_at" : "2016-03-02 23:13:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel Squire",
      "screen_name" : "travelsquire",
      "indices" : [ 3, 16 ],
      "id_str" : "25354439",
      "id" : 25354439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TRAVEX",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705153176790540288",
  "text" : "RT @travelsquire: Q1: Do you usually take a spring vacation or break? Why or why not? #TRAVEX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TRAVEX",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705150798590771200",
    "text" : "Q1: Do you usually take a spring vacation or break? Why or why not? #TRAVEX",
    "id" : 705150798590771200,
    "created_at" : "2016-03-02 22:00:26 +0000",
    "user" : {
      "name" : "Travel Squire",
      "screen_name" : "travelsquire",
      "protected" : false,
      "id_str" : "25354439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1676507896\/NewTravelSquiresmall_2_normal.jpg",
      "id" : 25354439,
      "verified" : false
    }
  },
  "id" : 705153176790540288,
  "created_at" : "2016-03-02 22:09:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/K0mbatW0lf\/status\/511931070779248640\/photo\/1",
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/1MzXgHibUI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxq-mHMCEAA07kw.jpg",
      "id_str" : "511931069633794048",
      "id" : 511931069633794048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxq-mHMCEAA07kw.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 454,
        "resize" : "fit",
        "w" : 960
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/1MzXgHibUI"
    } ],
    "hashtags" : [ {
      "text" : "BadSonicFanArt",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705152897206624256",
  "text" : "RT @BestGamezUp: #BadSonicFanArt \"it's a party\" https:\/\/t.co\/1MzXgHibUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/K0mbatW0lf\/status\/511931070779248640\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/1MzXgHibUI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxq-mHMCEAA07kw.jpg",
        "id_str" : "511931069633794048",
        "id" : 511931069633794048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxq-mHMCEAA07kw.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 454,
          "resize" : "fit",
          "w" : 960
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/1MzXgHibUI"
      } ],
      "hashtags" : [ {
        "text" : "BadSonicFanArt",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "705151997142503424",
    "text" : "#BadSonicFanArt \"it's a party\" https:\/\/t.co\/1MzXgHibUI",
    "id" : 705151997142503424,
    "created_at" : "2016-03-02 22:05:11 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 705152897206624256,
  "created_at" : "2016-03-02 22:08:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705152567748239361",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani There are so many tech events in Sweden, you could have so much fun!!!",
  "id" : 705152567748239361,
  "created_at" : "2016-03-02 22:07:27 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/705152249174085632\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/VAihKx7jHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cck0OqEWwAASQU-.jpg",
      "id_str" : "705152243075563520",
      "id" : 705152243075563520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cck0OqEWwAASQU-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 535
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 813,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/VAihKx7jHh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705152249174085632",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani You should go to events like these. Finish college, network with smart people, you are still young. https:\/\/t.co\/VAihKx7jHh",
  "id" : 705152249174085632,
  "created_at" : "2016-03-02 22:06:11 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "indices" : [ 3, 13 ],
      "id_str" : "618294231",
      "id" : 618294231
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 15, 27 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705117602977181696",
  "text" : "RT @_grammar_: @gamer456148, it might be better if you had said \u201Cmention [there] is only a\u201D instead. \u2018Their\u2019 belongs to \u2018them\u2019.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/Your_Grammar\" rel=\"nofollow\"\u003Emagical magic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "705116573816614916",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 68.417839516385, 110.270070088366 ]
    },
    "id_str" : "705117485549260800",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148, it might be better if you had said \u201Cmention [there] is only a\u201D instead. \u2018Their\u2019 belongs to \u2018them\u2019.",
    "id" : 705117485549260800,
    "in_reply_to_status_id" : 705116573816614916,
    "created_at" : "2016-03-02 19:48:03 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Grammar Police",
      "screen_name" : "_grammar_",
      "protected" : false,
      "id_str" : "618294231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785169027169521664\/j5rftldn_normal.png",
      "id" : 618294231,
      "verified" : false
    }
  },
  "id" : 705117602977181696,
  "created_at" : "2016-03-02 19:48:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark R. Levin",
      "screen_name" : "marklevinshow",
      "indices" : [ 3, 17 ],
      "id_str" : "38495835",
      "id" : 38495835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/zRWQJmIeEq",
      "expanded_url" : "http:\/\/fb.me\/4ORE306D0",
      "display_url" : "fb.me\/4ORE306D0"
    } ]
  },
  "geo" : { },
  "id_str" : "705117463915008000",
  "text" : "RT @marklevinshow: Cruz wins Alaska despite Palin endorsement of Trump https:\/\/t.co\/zRWQJmIeEq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/zRWQJmIeEq",
        "expanded_url" : "http:\/\/fb.me\/4ORE306D0",
        "display_url" : "fb.me\/4ORE306D0"
      } ]
    },
    "geo" : { },
    "id_str" : "704997824807755777",
    "text" : "Cruz wins Alaska despite Palin endorsement of Trump https:\/\/t.co\/zRWQJmIeEq",
    "id" : 704997824807755777,
    "created_at" : "2016-03-02 11:52:34 +0000",
    "user" : {
      "name" : "Mark R. Levin",
      "screen_name" : "marklevinshow",
      "protected" : false,
      "id_str" : "38495835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116305623\/80c5515ce8244c85105172fe5640f550_normal.jpeg",
      "id" : 38495835,
      "verified" : true
    }
  },
  "id" : 705117463915008000,
  "created_at" : "2016-03-02 19:47:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1367531",
      "id" : 1367531
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 46, 54 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/704848946699481088\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/q1hhASV1yy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CcggYcpUAAANFNr.jpg",
      "id_str" : "704848946061901824",
      "id" : 704848946061901824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcggYcpUAAANFNr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/q1hhASV1yy"
    } ],
    "hashtags" : [ {
      "text" : "SuperTuesday",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705117183433580548",
  "text" : "RT @FoxNews: BREAKING NEWS: Fox News projects @tedcruz as the winner of the Texas Republican Primary. #SuperTuesday https:\/\/t.co\/q1hhASV1yy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 33, 41 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FoxNews\/status\/704848946699481088\/photo\/1",
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/q1hhASV1yy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CcggYcpUAAANFNr.jpg",
        "id_str" : "704848946061901824",
        "id" : 704848946061901824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CcggYcpUAAANFNr.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/q1hhASV1yy"
      } ],
      "hashtags" : [ {
        "text" : "SuperTuesday",
        "indices" : [ 89, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "704848946699481088",
    "text" : "BREAKING NEWS: Fox News projects @tedcruz as the winner of the Texas Republican Primary. #SuperTuesday https:\/\/t.co\/q1hhASV1yy",
    "id" : 704848946699481088,
    "created_at" : "2016-03-02 02:00:59 +0000",
    "user" : {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "protected" : false,
      "id_str" : "1367531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/918480715158716419\/4X8oCbge_normal.jpg",
      "id" : 1367531,
      "verified" : true
    }
  },
  "id" : 705117183433580548,
  "created_at" : "2016-03-02 19:46:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 3, 12 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/gK9CsrV3Ot",
      "expanded_url" : "http:\/\/randpaul.com\/l\/waste-report",
      "display_url" : "randpaul.com\/l\/waste-report"
    } ]
  },
  "geo" : { },
  "id_str" : "705117045105389568",
  "text" : "RT @RandPaul: DC politicians think your money is theirs, and they can spend it however they want. Visit: https:\/\/t.co\/gK9CsrV3Ot\nhttps:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/gK9CsrV3Ot",
        "expanded_url" : "http:\/\/randpaul.com\/l\/waste-report",
        "display_url" : "randpaul.com\/l\/waste-report"
      }, {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/phAofKWuEo",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/97f3a1e5-f49f-4e28-b8ed-b9d720f5c5df",
        "display_url" : "amp.twimg.com\/v\/97f3a1e5-f49\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "705035411328933889",
    "text" : "DC politicians think your money is theirs, and they can spend it however they want. Visit: https:\/\/t.co\/gK9CsrV3Ot\nhttps:\/\/t.co\/phAofKWuEo",
    "id" : 705035411328933889,
    "created_at" : "2016-03-02 14:21:55 +0000",
    "user" : {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "protected" : false,
      "id_str" : "216881337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681152691461042177\/_PrgDgFA_normal.jpg",
      "id" : 216881337,
      "verified" : true
    }
  },
  "id" : 705117045105389568,
  "created_at" : "2016-03-02 19:46:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "704042097389789184",
  "geo" : { },
  "id_str" : "705116873520599041",
  "in_reply_to_user_id" : 703541068462235648,
  "text" : "@JosefLokmani Yes, I miss being obsessed with potential medical devices, lol",
  "id" : 705116873520599041,
  "in_reply_to_status_id" : 704042097389789184,
  "created_at" : "2016-03-02 19:45:37 +0000",
  "in_reply_to_screen_name" : "JosefLokmani",
  "in_reply_to_user_id_str" : "703541068462235648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 0, 6 ],
      "id_str" : "70266297",
      "id" : 70266297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705107353193078785",
  "geo" : { },
  "id_str" : "705116710710353920",
  "in_reply_to_user_id" : 70266297,
  "text" : "@udemy I see courses like Rob Percival's who offered free hosting on his more expensive courses, to me it doesn't make much sense to do this",
  "id" : 705116710710353920,
  "in_reply_to_status_id" : 705107353193078785,
  "created_at" : "2016-03-02 19:44:58 +0000",
  "in_reply_to_screen_name" : "udemy",
  "in_reply_to_user_id_str" : "70266297",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 0, 6 ],
      "id_str" : "70266297",
      "id" : 70266297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705107353193078785",
  "geo" : { },
  "id_str" : "705116573816614916",
  "in_reply_to_user_id" : 70266297,
  "text" : "@udemy Plus not to mention their is only a $30 price range which will lead to more problems in the long run",
  "id" : 705116573816614916,
  "in_reply_to_status_id" : 705107353193078785,
  "created_at" : "2016-03-02 19:44:26 +0000",
  "in_reply_to_screen_name" : "udemy",
  "in_reply_to_user_id_str" : "70266297",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 0, 6 ],
      "id_str" : "70266297",
      "id" : 70266297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705107353193078785",
  "geo" : { },
  "id_str" : "705116419051036672",
  "in_reply_to_user_id" : 70266297,
  "text" : "@udemy I want to be able to give free coupons to my app users and subscribers, as a business coach this was one of the reasons I used udemy",
  "id" : 705116419051036672,
  "in_reply_to_status_id" : 705107353193078785,
  "created_at" : "2016-03-02 19:43:49 +0000",
  "in_reply_to_screen_name" : "udemy",
  "in_reply_to_user_id_str" : "70266297",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 3, 9 ],
      "id_str" : "70266297",
      "id" : 70266297
    }, {
      "name" : "Udemy for Business",
      "screen_name" : "UdemyforBiz",
      "indices" : [ 14, 26 ],
      "id_str" : "3517787594",
      "id" : 3517787594
    }, {
      "name" : "Darren Shimkus",
      "screen_name" : "DarrenShimkus",
      "indices" : [ 60, 74 ],
      "id_str" : "271068004",
      "id" : 271068004
    }, {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 78, 87 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/iJ1yjPGgSx",
      "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/case-fast-learning-darren-shimkus",
      "display_url" : "linkedin.com\/pulse\/case-fas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "705106094444511232",
  "text" : "RT @udemy: RT @UdemyforBiz: \"The Case for Fast Learning\" by @DarrenShimkus on @LinkedIn https:\/\/t.co\/iJ1yjPGgSx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Udemy for Business",
        "screen_name" : "UdemyforBiz",
        "indices" : [ 3, 15 ],
        "id_str" : "3517787594",
        "id" : 3517787594
      }, {
        "name" : "Darren Shimkus",
        "screen_name" : "DarrenShimkus",
        "indices" : [ 49, 63 ],
        "id_str" : "271068004",
        "id" : 271068004
      }, {
        "name" : "LinkedIn",
        "screen_name" : "LinkedIn",
        "indices" : [ 67, 76 ],
        "id_str" : "13058772",
        "id" : 13058772
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/iJ1yjPGgSx",
        "expanded_url" : "https:\/\/www.linkedin.com\/pulse\/case-fast-learning-darren-shimkus",
        "display_url" : "linkedin.com\/pulse\/case-fas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "704800385362436096",
    "text" : "RT @UdemyforBiz: \"The Case for Fast Learning\" by @DarrenShimkus on @LinkedIn https:\/\/t.co\/iJ1yjPGgSx",
    "id" : 704800385362436096,
    "created_at" : "2016-03-01 22:48:01 +0000",
    "user" : {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "protected" : false,
      "id_str" : "70266297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1013891333155577856\/7EsvLcOr_normal.jpg",
      "id" : 70266297,
      "verified" : true
    }
  },
  "id" : 705106094444511232,
  "created_at" : "2016-03-02 19:02:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Udemy",
      "screen_name" : "udemy",
      "indices" : [ 0, 6 ],
      "id_str" : "70266297",
      "id" : 70266297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "705102351384838146",
  "geo" : { },
  "id_str" : "705106037146144769",
  "in_reply_to_user_id" : 70266297,
  "text" : "@udemy Are you serious? Shouldn't instructors have control of pricing for their own courses? Can we get good news for once?",
  "id" : 705106037146144769,
  "in_reply_to_status_id" : 705102351384838146,
  "created_at" : "2016-03-02 19:02:34 +0000",
  "in_reply_to_screen_name" : "udemy",
  "in_reply_to_user_id_str" : "70266297",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/705105553849077761\/photo\/1",
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/WI49xzHsJZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CckJwsVW8AIdD1K.jpg",
      "id_str" : "705105548799307778",
      "id" : 705105548799307778,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CckJwsVW8AIdD1K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/WI49xzHsJZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705105553849077761",
  "text" : "Cruz may be starting to catch up https:\/\/t.co\/WI49xzHsJZ",
  "id" : 705105553849077761,
  "created_at" : "2016-03-02 19:00:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "704859298749407233",
  "text" : "Cruz, keeping it cool in Texas!!!",
  "id" : 704859298749407233,
  "created_at" : "2016-03-02 02:42:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : true,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]