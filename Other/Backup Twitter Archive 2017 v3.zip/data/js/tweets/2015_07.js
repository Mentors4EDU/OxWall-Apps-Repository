Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627265475920015361",
  "text" : "@JosefLokmani If they think like that, they are entirely brain dead",
  "id" : 627265475920015361,
  "created_at" : "2015-07-31 23:51:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/qiwLqtkMkf",
      "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/623245117776723968",
      "display_url" : "twitter.com\/YoungCons\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "627242490391851008",
  "text" : "RT @hannahbleau_: Seriously though.  https:\/\/t.co\/qiwLqtkMkf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 19, 42 ],
        "url" : "https:\/\/t.co\/qiwLqtkMkf",
        "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/623245117776723968",
        "display_url" : "twitter.com\/YoungCons\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "623271008653344768",
    "text" : "Seriously though.  https:\/\/t.co\/qiwLqtkMkf",
    "id" : 623271008653344768,
    "created_at" : "2015-07-20 23:19:22 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 627242490391851008,
  "created_at" : "2015-07-31 22:20:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627240670097358848",
  "text" : "I don't care about the fact that Dr.Walter Palmer killed a lion, what is a bigger issue is that he was charged with sexual harassment",
  "id" : 627240670097358848,
  "created_at" : "2015-07-31 22:13:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/627240380778479616\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/sy0Uafa9LB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLRnzXEUkAAKkfR.jpg",
      "id_str" : "627240380174471168",
      "id" : 627240380174471168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLRnzXEUkAAKkfR.jpg",
      "sizes" : [ {
        "h" : 160,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 90,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 872
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 872
      } ],
      "display_url" : "pic.twitter.com\/sy0Uafa9LB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627240380778479616",
  "text" : "What type of sicko would type something like this? http:\/\/t.co\/sy0Uafa9LB",
  "id" : 627240380778479616,
  "created_at" : "2015-07-31 22:12:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627121872451338241",
  "text" : "Thing big not small, reason wisely not unwisely, and don't vote as a liberal but vote as a conservative. Common sense people-",
  "id" : 627121872451338241,
  "created_at" : "2015-07-31 14:21:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627121627654942720",
  "text" : "Stop ignoring what may be in-front of you, stop judging unless informed",
  "id" : 627121627654942720,
  "created_at" : "2015-07-31 14:20:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627121175202791425",
  "text" : "The constitution constitutes Human rights; Obama's agenda constitutes humans losing most of those rights. What makes sense to you?",
  "id" : 627121175202791425,
  "created_at" : "2015-07-31 14:18:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627120901033738240",
  "text" : "People deserve freedom only if they seek truth. Knock and the door will be open. Seek and you will find.",
  "id" : 627120901033738240,
  "created_at" : "2015-07-31 14:17:28 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627120691633082368",
  "text" : "You only live once so why not live it for the lord",
  "id" : 627120691633082368,
  "created_at" : "2015-07-31 14:16:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627120579825549312",
  "text" : "The difference between Conservatism and Liberalism is like the difference between a toy scooter and a Ferrari. Conservatism is the Ferrari.",
  "id" : 627120579825549312,
  "created_at" : "2015-07-31 14:16:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627120252091002880",
  "text" : "God is an absolute truth, the bible is the most profound book of wisdom",
  "id" : 627120252091002880,
  "created_at" : "2015-07-31 14:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627120110734602244",
  "text" : "Imagine a world with social Darwinism? Hitler, Stalin, and Zedong all did",
  "id" : 627120110734602244,
  "created_at" : "2015-07-31 14:14:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627119498093441024",
  "text" : "Be the change in you want to be in the world, not the change the government wants you to be",
  "id" : 627119498093441024,
  "created_at" : "2015-07-31 14:11:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627119370410405888",
  "text" : "Humans have rationality, reason and a free will. However not always does that will end up being good, and many of us are loosing our reason",
  "id" : 627119370410405888,
  "created_at" : "2015-07-31 14:11:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627119083985616896",
  "text" : "If you abort a child, you don't deserve to live, even if it was to save yourself. Who kills an unborn baby? Jesus taught love and sacrifice.",
  "id" : 627119083985616896,
  "created_at" : "2015-07-31 14:10:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627118716061286401",
  "text" : "Our hard work should determine our financial income not the IRS",
  "id" : 627118716061286401,
  "created_at" : "2015-07-31 14:08:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627118492605526017",
  "text" : "If we wanna follow Jesus, we shouldn't be making excuses",
  "id" : 627118492605526017,
  "created_at" : "2015-07-31 14:07:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627118304147042306",
  "text" : "We follow God for his glory, wisdom, salvation, knowledge, and indescribable love. We follow God for life not just to make us happy.",
  "id" : 627118304147042306,
  "created_at" : "2015-07-31 14:07:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627118143924637697",
  "text" : "Your dreams aren't want is in charge of your reality but how you follow God is what makes up your life.",
  "id" : 627118143924637697,
  "created_at" : "2015-07-31 14:06:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627118027650142208",
  "text" : "Stop dreaming and just try your best and let God do the rest",
  "id" : 627118027650142208,
  "created_at" : "2015-07-31 14:06:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117933987262466",
  "text" : "We can live in reality or virtual reality but be prepared to face the consequences in real life",
  "id" : 627117933987262466,
  "created_at" : "2015-07-31 14:05:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117797445922816",
  "text" : "A soul mate cares about where you will end up after you die",
  "id" : 627117797445922816,
  "created_at" : "2015-07-31 14:05:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117728537706496",
  "text" : "Love is on the inside not the outside, and isn't just a physical rush but an emotional and indescribable sensation",
  "id" : 627117728537706496,
  "created_at" : "2015-07-31 14:04:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117530377789440",
  "text" : "Does who loose liberty in order to gain a freedom, doesn't have self dignity, doesn't deserve liberty, and aren't really free.",
  "id" : 627117530377789440,
  "created_at" : "2015-07-31 14:04:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117372458070016",
  "text" : "Making peace doesn't mean agreeing with what everyone says or compromising your beliefs",
  "id" : 627117372458070016,
  "created_at" : "2015-07-31 14:03:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117213242269697",
  "text" : "Nobody has 4 hour work weeks so stop hoping to strike Gold and just get up on your ass",
  "id" : 627117213242269697,
  "created_at" : "2015-07-31 14:02:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117112587325441",
  "text" : "The greedy may prosper on earth but will they prosper in heaven?",
  "id" : 627117112587325441,
  "created_at" : "2015-07-31 14:02:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627117005297045504",
  "text" : "Would you rather stand up to authority or be a door mat for the the rest of your life?",
  "id" : 627117005297045504,
  "created_at" : "2015-07-31 14:01:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627116903505494016",
  "text" : "The difference between visionaries and a revolutionaries are that revolutionaries don't dream, they take action",
  "id" : 627116903505494016,
  "created_at" : "2015-07-31 14:01:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "627116768125943809",
  "text" : "Sometimes the most sociable people are the most nervous",
  "id" : 627116768125943809,
  "created_at" : "2015-07-31 14:01:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/626877523117256704\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/wszSLOqJyi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLMdySUUsAE1z03.jpg",
      "id_str" : "626877522882375681",
      "id" : 626877522882375681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLMdySUUsAE1z03.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/wszSLOqJyi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626877523117256704",
  "text" : "3.85\/5 stars for taste, 2\/5 stars for price \uD83D\uDE02 http:\/\/t.co\/wszSLOqJyi",
  "id" : 626877523117256704,
  "created_at" : "2015-07-30 22:10:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Bruewer",
      "screen_name" : "nickbruewer",
      "indices" : [ 3, 15 ],
      "id_str" : "2842052974",
      "id" : 2842052974
    }, {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 21, 30 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thisisou",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626809180142325760",
  "text" : "RT @nickbruewer: Hey @oaklandu how about we stop raising tuition and stop paying LeBron to come watch our men's basketball games? #thisisou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oakland University",
        "screen_name" : "oaklandu",
        "indices" : [ 4, 13 ],
        "id_str" : "17468189",
        "id" : 17468189
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thisisou",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625118971826688001",
    "text" : "Hey @oaklandu how about we stop raising tuition and stop paying LeBron to come watch our men's basketball games? #thisisou",
    "id" : 625118971826688001,
    "created_at" : "2015-07-26 01:42:31 +0000",
    "user" : {
      "name" : "Nick Bruewer",
      "screen_name" : "nickbruewer",
      "protected" : false,
      "id_str" : "2842052974",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849391533568794624\/5SLlhupQ_normal.jpg",
      "id" : 2842052974,
      "verified" : false
    }
  },
  "id" : 626809180142325760,
  "created_at" : "2015-07-30 17:38:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626752115612979200",
  "text" : "Does coffee turn everyone nicer, lol #ThisIsOU",
  "id" : 626752115612979200,
  "created_at" : "2015-07-30 13:52:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626746436839845888",
  "text" : "Going out of your way to tell someone good morning, or have a blessed day is a nice thing to do. Even if you may never see them again :)",
  "id" : 626746436839845888,
  "created_at" : "2015-07-30 13:29:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 0, 14 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626148947220918272",
  "geo" : { },
  "id_str" : "626738007731798016",
  "in_reply_to_user_id" : 1410252020,
  "text" : "@slidenerdtech Why go to the Apple Store, I use Amazon or eBay!!!",
  "id" : 626738007731798016,
  "in_reply_to_status_id" : 626148947220918272,
  "created_at" : "2015-07-30 12:55:59 +0000",
  "in_reply_to_screen_name" : "slidenerdtech",
  "in_reply_to_user_id_str" : "1410252020",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "indices" : [ 3, 17 ],
      "id_str" : "1410252020",
      "id" : 1410252020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/626148947220918272\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/JiWVtRDJbL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCHJmBWUAAFAYB.jpg",
      "id_str" : "626148947099275264",
      "id" : 626148947099275264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCHJmBWUAAFAYB.jpg",
      "sizes" : [ {
        "h" : 443,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 651
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 651
      } ],
      "display_url" : "pic.twitter.com\/JiWVtRDJbL"
    } ],
    "hashtags" : [ {
      "text" : "programmer",
      "indices" : [ 42, 53 ]
    }, {
      "text" : "internet",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "developer",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626737763325485057",
  "text" : "RT @slidenerdtech: life with a programmer #programmer #internet #developer http:\/\/t.co\/JiWVtRDJbL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slidenerdtech\/status\/626148947220918272\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/JiWVtRDJbL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CLCHJmBWUAAFAYB.jpg",
        "id_str" : "626148947099275264",
        "id" : 626148947099275264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLCHJmBWUAAFAYB.jpg",
        "sizes" : [ {
          "h" : 443,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 651
        }, {
          "h" : 481,
          "resize" : "fit",
          "w" : 651
        } ],
        "display_url" : "pic.twitter.com\/JiWVtRDJbL"
      } ],
      "hashtags" : [ {
        "text" : "programmer",
        "indices" : [ 23, 34 ]
      }, {
        "text" : "internet",
        "indices" : [ 35, 44 ]
      }, {
        "text" : "developer",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "626148947220918272",
    "text" : "life with a programmer #programmer #internet #developer http:\/\/t.co\/JiWVtRDJbL",
    "id" : 626148947220918272,
    "created_at" : "2015-07-28 21:55:16 +0000",
    "user" : {
      "name" : "slidenerd",
      "screen_name" : "slidenerdtech",
      "protected" : false,
      "id_str" : "1410252020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3626569194\/9efac426d5465cf43ae94b41838e0a51_normal.jpeg",
      "id" : 1410252020,
      "verified" : false
    }
  },
  "id" : 626737763325485057,
  "created_at" : "2015-07-30 12:55:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SlideNERD",
      "screen_name" : "slidenerd",
      "indices" : [ 0, 10 ],
      "id_str" : "506219284",
      "id" : 506219284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626737294502948864",
  "in_reply_to_user_id" : 506219284,
  "text" : "@Slidenerd just reached 7k students, better step up my game ;)",
  "id" : 626737294502948864,
  "created_at" : "2015-07-30 12:53:09 +0000",
  "in_reply_to_screen_name" : "slidenerd",
  "in_reply_to_user_id_str" : "506219284",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/626714244579479552\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/UCUglFvvm4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLKJSOpWUAAiRIl.jpg",
      "id_str" : "626714244420096000",
      "id" : 626714244420096000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLKJSOpWUAAiRIl.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1133,
        "resize" : "fit",
        "w" : 1400
      } ],
      "display_url" : "pic.twitter.com\/UCUglFvvm4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626714244579479552",
  "text" : "Bob Marley makes some good coffee, lol. Seriously though, rest in peace. http:\/\/t.co\/UCUglFvvm4",
  "id" : 626714244579479552,
  "created_at" : "2015-07-30 11:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625568416745717760",
  "geo" : { },
  "id_str" : "626540639681777664",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Not unless you are a Jeweler",
  "id" : 626540639681777664,
  "in_reply_to_status_id" : 625568416745717760,
  "created_at" : "2015-07-29 23:51:43 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626540559256129537",
  "text" : "RT @HelloRyanHolmes: It takes time to figure out whose gold, and whose gold plated.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.everypost.me\" rel=\"nofollow\"\u003EEverypost\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625568416745717760",
    "text" : "It takes time to figure out whose gold, and whose gold plated.",
    "id" : 625568416745717760,
    "created_at" : "2015-07-27 07:28:27 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829221632141094915\/wHMAVGFY_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 626540559256129537,
  "created_at" : "2015-07-29 23:51:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625573405203402752",
  "geo" : { },
  "id_str" : "626540496840728576",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Which floor is that and which building? How are we supposed to know what you are talking about :P",
  "id" : 626540496840728576,
  "in_reply_to_status_id" : 625573405203402752,
  "created_at" : "2015-07-29 23:51:09 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625574676262072320",
  "geo" : { },
  "id_str" : "626540336366657536",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes I felt the same way,lots of people don't find unconditional love at your age, I mean it isn't like you are 30, keep looking",
  "id" : 626540336366657536,
  "in_reply_to_status_id" : 625574676262072320,
  "created_at" : "2015-07-29 23:50:31 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 93, 102 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626513651369906176",
  "text" : "On the day after my birthday, I will be going to the \"Business Forum Conference Series 2015\" @Oaklandu #ThisIsOU",
  "id" : 626513651369906176,
  "created_at" : "2015-07-29 22:04:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626469623425183745",
  "geo" : { },
  "id_str" : "626503525552381952",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Dang it, at least I have Linux",
  "id" : 626503525552381952,
  "in_reply_to_status_id" : 626469623425183745,
  "created_at" : "2015-07-29 21:24:15 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 3, 19 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/sER0oYVVdP",
      "expanded_url" : "http:\/\/youtu.be\/kh_nNfC719g?a",
      "display_url" : "youtu.be\/kh_nNfC719g?a"
    } ]
  },
  "geo" : { },
  "id_str" : "626503476894240768",
  "text" : "RT @HelloRyanHolmes: Did you upgrade to Windows 10? http:\/\/t.co\/sER0oYVVdP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/sER0oYVVdP",
        "expanded_url" : "http:\/\/youtu.be\/kh_nNfC719g?a",
        "display_url" : "youtu.be\/kh_nNfC719g?a"
      } ]
    },
    "geo" : { },
    "id_str" : "626469623425183745",
    "text" : "Did you upgrade to Windows 10? http:\/\/t.co\/sER0oYVVdP",
    "id" : 626469623425183745,
    "created_at" : "2015-07-29 19:09:32 +0000",
    "user" : {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "protected" : false,
      "id_str" : "32809159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/829221632141094915\/wHMAVGFY_normal.jpg",
      "id" : 32809159,
      "verified" : false
    }
  },
  "id" : 626503476894240768,
  "created_at" : "2015-07-29 21:24:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626498151852027905",
  "geo" : { },
  "id_str" : "626503380345552896",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Want to loose a huge cut of your ad revenue for sponsorship benefits go ahead, but I wouldn't recommend it for you",
  "id" : 626503380345552896,
  "in_reply_to_status_id" : 626498151852027905,
  "created_at" : "2015-07-29 21:23:40 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626498151852027905",
  "geo" : { },
  "id_str" : "626503194093338624",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes I owned YouTube networks and were part of YouTube partnerships before, for your type of channel they will take a huge cut",
  "id" : 626503194093338624,
  "in_reply_to_status_id" : 626498151852027905,
  "created_at" : "2015-07-29 21:22:55 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Hoft",
      "screen_name" : "gatewaypundit",
      "indices" : [ 3, 17 ],
      "id_str" : "19211550",
      "id" : 19211550
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 24, 32 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/gSkMt2X1HW",
      "expanded_url" : "https:\/\/shar.es\/1sxhfa",
      "display_url" : "shar.es\/1sxhfa"
    } ]
  },
  "geo" : { },
  "id_str" : "626502852962168832",
  "text" : "RT @gatewaypundit: WOW! @TedCruz Goes to Senate Floor \u2013 Accuses Majority Leader McConnell of Lying (VIDEO) https:\/\/t.co\/gSkMt2X1HW via @gat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 5, 13 ],
        "id_str" : "23022687",
        "id" : 23022687
      }, {
        "name" : "Jim Hoft",
        "screen_name" : "gatewaypundit",
        "indices" : [ 116, 130 ],
        "id_str" : "19211550",
        "id" : 19211550
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/gSkMt2X1HW",
        "expanded_url" : "https:\/\/shar.es\/1sxhfa",
        "display_url" : "shar.es\/1sxhfa"
      } ]
    },
    "geo" : { },
    "id_str" : "624644030199021568",
    "text" : "WOW! @TedCruz Goes to Senate Floor \u2013 Accuses Majority Leader McConnell of Lying (VIDEO) https:\/\/t.co\/gSkMt2X1HW via @gatewaypundit",
    "id" : 624644030199021568,
    "created_at" : "2015-07-24 18:15:16 +0000",
    "user" : {
      "name" : "Jim Hoft",
      "screen_name" : "gatewaypundit",
      "protected" : false,
      "id_str" : "19211550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2333537481\/cunytcjxusinsxkh9vex_normal.jpeg",
      "id" : 19211550,
      "verified" : false
    }
  },
  "id" : 626502852962168832,
  "created_at" : "2015-07-29 21:21:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TEA Party for Cruz",
      "screen_name" : "TeaParty4Cruz",
      "indices" : [ 3, 17 ],
      "id_str" : "3232895802",
      "id" : 3232895802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TedCruz2016",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626502799979773952",
  "text" : "RT @TeaParty4Cruz: Buckle your seat belts folks, we're approaching Cruzing attitude: #TedCruz2016 stirs up \u2018grassroots tsunami\u2019 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TedCruz2016",
        "indices" : [ 66, 78 ]
      }, {
        "text" : "Cruz",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/XPVZzcIOzD",
        "expanded_url" : "http:\/\/www.theblaze.com\/stories\/2015\/07\/26\/after-stunning-takedown-of-mitch-mcconnell-on-senate-floor-ted-cruz-wants-to-stir-up-a-grassroots-tsunami-against-the-washington-cartel",
        "display_url" : "theblaze.com\/stories\/2015\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "625502711413256192",
    "text" : "Buckle your seat belts folks, we're approaching Cruzing attitude: #TedCruz2016 stirs up \u2018grassroots tsunami\u2019 http:\/\/t.co\/XPVZzcIOzD #Cruz",
    "id" : 625502711413256192,
    "created_at" : "2015-07-27 03:07:22 +0000",
    "user" : {
      "name" : "TEA Party for Cruz",
      "screen_name" : "TeaParty4Cruz",
      "protected" : false,
      "id_str" : "3232895802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796817440072036352\/Unrgxzor_normal.jpg",
      "id" : 3232895802,
      "verified" : false
    }
  },
  "id" : 626502799979773952,
  "created_at" : "2015-07-29 21:21:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MythicApps",
      "screen_name" : "MythicApps",
      "indices" : [ 0, 11 ],
      "id_str" : "3041445029",
      "id" : 3041445029
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sneaky",
      "indices" : [ 42, 49 ]
    }, {
      "text" : "ThisIsOU",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626502396424753152",
  "in_reply_to_user_id" : 3041445029,
  "text" : "@MythicApps Just applied, fingers crossed #Sneaky #ThisIsOU",
  "id" : 626502396424753152,
  "created_at" : "2015-07-29 21:19:45 +0000",
  "in_reply_to_screen_name" : "MythicApps",
  "in_reply_to_user_id_str" : "3041445029",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrizzHacks",
      "screen_name" : "GrizzHacks",
      "indices" : [ 0, 11 ],
      "id_str" : "3257314503",
      "id" : 3257314503
    }, {
      "name" : "MHacks",
      "screen_name" : "mhacks",
      "indices" : [ 12, 19 ],
      "id_str" : "870221107",
      "id" : 870221107
    }, {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 20, 29 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623304425973526529",
  "geo" : { },
  "id_str" : "626499179360063488",
  "in_reply_to_user_id" : 3257314503,
  "text" : "@GrizzHacks @mhacks @oaklandu Just applied, can't wait to see what may happen next, better keep secret ;)",
  "id" : 626499179360063488,
  "in_reply_to_status_id" : 623304425973526529,
  "created_at" : "2015-07-29 21:06:58 +0000",
  "in_reply_to_screen_name" : "GrizzHacks",
  "in_reply_to_user_id_str" : "3257314503",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "indices" : [ 3, 19 ],
      "id_str" : "29856819",
      "id" : 29856819
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/theRealKiyosaki\/status\/624655340940845056\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/WeyB76XaYG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKoPWjpUAAAGnDc.jpg",
      "id_str" : "624328378544291840",
      "id" : 624328378544291840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKoPWjpUAAAGnDc.jpg",
      "sizes" : [ {
        "h" : 463,
        "resize" : "fit",
        "w" : 618
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 618
      } ],
      "display_url" : "pic.twitter.com\/WeyB76XaYG"
    } ],
    "hashtags" : [ {
      "text" : "richdad",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626389806369665024",
  "text" : "RT @theRealKiyosaki: #richdad http:\/\/t.co\/WeyB76XaYG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theRealKiyosaki\/status\/624655340940845056\/photo\/1",
        "indices" : [ 9, 31 ],
        "url" : "http:\/\/t.co\/WeyB76XaYG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKoPWjpUAAAGnDc.jpg",
        "id_str" : "624328378544291840",
        "id" : 624328378544291840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKoPWjpUAAAGnDc.jpg",
        "sizes" : [ {
          "h" : 463,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 618
        } ],
        "display_url" : "pic.twitter.com\/WeyB76XaYG"
      } ],
      "hashtags" : [ {
        "text" : "richdad",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "624655340940845056",
    "text" : "#richdad http:\/\/t.co\/WeyB76XaYG",
    "id" : 624655340940845056,
    "created_at" : "2015-07-24 19:00:13 +0000",
    "user" : {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "protected" : false,
      "id_str" : "29856819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472421066007015424\/MHUJj15g_normal.jpeg",
      "id" : 29856819,
      "verified" : true
    }
  },
  "id" : 626389806369665024,
  "created_at" : "2015-07-29 13:52:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "626389529566576640",
  "geo" : { },
  "id_str" : "626389621245628416",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 I love giving people good laughs #ThisIsOU",
  "id" : 626389621245628416,
  "in_reply_to_status_id" : 626389529566576640,
  "created_at" : "2015-07-29 13:51:38 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626389529566576640",
  "text" : "Hi can I tell you a story, there once was the Man at Oakland who was telling this girl a story, his name was Andrew Kamal, nice to meet you.",
  "id" : 626389529566576640,
  "created_at" : "2015-07-29 13:51:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626155302988181506",
  "text" : "A 150 premise paper, nearly 30 pages of writing in a week, lots of redos #ThisIsOU I can do this!!!",
  "id" : 626155302988181506,
  "created_at" : "2015-07-28 22:20:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "indices" : [ 3, 19 ],
      "id_str" : "29856819",
      "id" : 29856819
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/theRealKiyosaki\/status\/625324794028818432\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/BzTXCZkmzb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK2ZkwkUkAAMaX2.jpg",
      "id_str" : "625324780065951744",
      "id" : 625324780065951744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK2ZkwkUkAAMaX2.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 618
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 618
      } ],
      "display_url" : "pic.twitter.com\/BzTXCZkmzb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626084980368654336",
  "text" : "RT @theRealKiyosaki: http:\/\/t.co\/BzTXCZkmzb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/theRealKiyosaki\/status\/625324794028818432\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/BzTXCZkmzb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CK2ZkwkUkAAMaX2.jpg",
        "id_str" : "625324780065951744",
        "id" : 625324780065951744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK2ZkwkUkAAMaX2.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 618
        } ],
        "display_url" : "pic.twitter.com\/BzTXCZkmzb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625324794028818432",
    "text" : "http:\/\/t.co\/BzTXCZkmzb",
    "id" : 625324794028818432,
    "created_at" : "2015-07-26 15:20:23 +0000",
    "user" : {
      "name" : "Robert T. Kiyosaki",
      "screen_name" : "theRealKiyosaki",
      "protected" : false,
      "id_str" : "29856819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472421066007015424\/MHUJj15g_normal.jpeg",
      "id" : 29856819,
      "verified" : true
    }
  },
  "id" : 626084980368654336,
  "created_at" : "2015-07-28 17:41:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626084294306312192",
  "text" : "Connor Bruggemann, Mohammad Islam, and Timothy Blair; what is up with these teens becoming stock millionaires? It is like a magic secret",
  "id" : 626084294306312192,
  "created_at" : "2015-07-28 17:38:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625443301571739649",
  "geo" : { },
  "id_str" : "626018554517827584",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Josef is great at HTML and somewhat can design some things.",
  "id" : 626018554517827584,
  "in_reply_to_status_id" : 625443301571739649,
  "created_at" : "2015-07-28 13:17:08 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625443301571739649",
  "geo" : { },
  "id_str" : "626018228184215552",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani Search Anti-Gravity propulsion engines or Heim theory, it will blow your mind!!!",
  "id" : 626018228184215552,
  "in_reply_to_status_id" : 625443301571739649,
  "created_at" : "2015-07-28 13:15:51 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 20, 33 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626018072571289600",
  "text" : "RT @chknfriedsteak: @JosefLokmani I've always been fascinated by space travel, or a lack thereof. Thoughts?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 0, 13 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625443301571739649",
    "text" : "@JosefLokmani I've always been fascinated by space travel, or a lack thereof. Thoughts?",
    "id" : 625443301571739649,
    "created_at" : "2015-07-26 23:11:17 +0000",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 626018072571289600,
  "created_at" : "2015-07-28 13:15:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626017826906763264",
  "text" : "I asked people what time this is, that's socializing right? \uD83D\uDE06 #ThisIsOU",
  "id" : 626017826906763264,
  "created_at" : "2015-07-28 13:14:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/626017612766556160\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/v959jSPO12",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CLAPs7PWsAAJquG.jpg",
      "id_str" : "626017612695252992",
      "id" : 626017612695252992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CLAPs7PWsAAJquG.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v959jSPO12"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626017612766556160",
  "text" : "I had too many energy drinks today. Coffee and now this juice. http:\/\/t.co\/v959jSPO12",
  "id" : 626017612766556160,
  "created_at" : "2015-07-28 13:13:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coupon Trump",
      "screen_name" : "CouponTrump",
      "indices" : [ 0, 12 ],
      "id_str" : "2370179022",
      "id" : 2370179022
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625737497306365953",
  "geo" : { },
  "id_str" : "625741483522572288",
  "in_reply_to_user_id" : 2370179022,
  "text" : "@CouponTrump For a limited time;)",
  "id" : 625741483522572288,
  "in_reply_to_status_id" : 625737497306365953,
  "created_at" : "2015-07-27 18:56:10 +0000",
  "in_reply_to_screen_name" : "CouponTrump",
  "in_reply_to_user_id_str" : "2370179022",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625741398344605696",
  "text" : "RT @AntoniPoint: Teenager Gets Patent on Hydrofuel Solar Car Design: Teenager Andrew Magdy Kamal is the co inventor of the Hydrofuel Solar \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "393410464459157505",
    "text" : "Teenager Gets Patent on Hydrofuel Solar Car Design: Teenager Andrew Magdy Kamal is the co inventor of the Hydrofuel Solar Car and Des...",
    "id" : 393410464459157505,
    "created_at" : "2013-10-24 16:15:38 +0000",
    "user" : {
      "name" : "ahre volado",
      "screen_name" : "ahrevolado",
      "protected" : false,
      "id_str" : "1898115774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739555074708475904\/oTuVr693_normal.jpg",
      "id" : 1898115774,
      "verified" : false
    }
  },
  "id" : 625741398344605696,
  "created_at" : "2015-07-27 18:55:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625710165841604608",
  "text" : "Knock, knock; Who's there? Andrew Kamal, nice to meet you. Works 3\/4th of the time. Not everyone has a sense of humor.",
  "id" : 625710165841604608,
  "created_at" : "2015-07-27 16:51:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 20, 33 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625412942914277378",
  "text" : "RT @chknfriedsteak: @JosefLokmani great idea!! We should all do the same, however, I feel that we can't just stick our heads in the sand wh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 0, 13 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625412275050930177",
    "text" : "@JosefLokmani great idea!! We should all do the same, however, I feel that we can't just stick our heads in the sand while working on I.P.",
    "id" : 625412275050930177,
    "created_at" : "2015-07-26 21:08:00 +0000",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 625412942914277378,
  "created_at" : "2015-07-26 21:10:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625412880041672704",
  "text" : "@JosefLokmani Josef I hope you find peace through the lord. Brother I hope you become more successful then me. You are a very bright kid.",
  "id" : 625412880041672704,
  "created_at" : "2015-07-26 21:10:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625410440596619264",
  "geo" : { },
  "id_str" : "625410899243859968",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani Josef is an awesome person, I personally know him. Though, he isn't good at politics, he is still a bright kid",
  "id" : 625410899243859968,
  "in_reply_to_status_id" : 625410440596619264,
  "created_at" : "2015-07-26 21:02:32 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 33, 46 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625410593491652608",
  "text" : "RT @chknfriedsteak: @gamer456148 @JosefLokmani I like Josef- I think if he wasn't so misinformed about politics, he'd be a nice guy!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 13, 26 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "625407443498074114",
    "geo" : { },
    "id_str" : "625410440596619264",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @JosefLokmani I like Josef- I think if he wasn't so misinformed about politics, he'd be a nice guy!!",
    "id" : 625410440596619264,
    "in_reply_to_status_id" : 625407443498074114,
    "created_at" : "2015-07-26 21:00:43 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 625410593491652608,
  "created_at" : "2015-07-26 21:01:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625410026245636096",
  "text" : "@JosefLokmani Reading that book will let you truly know what Conservatism &amp; my political ideology is. Don't tweet what you don't know about",
  "id" : 625410026245636096,
  "created_at" : "2015-07-26 20:59:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/625409802345291776\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/LvvSizsCae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK3m5qLWUAAwz3h.jpg",
      "id_str" : "625409801523187712",
      "id" : 625409801523187712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK3m5qLWUAAwz3h.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 537,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 537,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LvvSizsCae"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625409802345291776",
  "text" : "@JosefLokmani Drugs can't be used for self defense. Josef, I think you should read this. http:\/\/t.co\/LvvSizsCae",
  "id" : 625409802345291776,
  "created_at" : "2015-07-26 20:58:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625407844179906561",
  "text" : "@JosefLokmani Josef, you are like a brother to me, with all due honesty Politics isn't your best subject. Just like how I suck at finance.",
  "id" : 625407844179906561,
  "created_at" : "2015-07-26 20:50:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 60, 75 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625407443498074114",
  "text" : "@JosefLokmani I am done Josef. You can settle this out with @chknfriedsteak You are a smart kid, but never enter the Lion's den uninformed.",
  "id" : 625407443498074114,
  "created_at" : "2015-07-26 20:48:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625406447812243457",
  "text" : "If we ban guns we should start banning Cutlery, Books, Tools, etc. Weapons don't hurt people. Objects don't hurt people. People hurt people",
  "id" : 625406447812243457,
  "created_at" : "2015-07-26 20:44:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625406184221208576",
  "text" : "@JosefLokmani @chknfriedsteak He just said patriots are for Gun Control. I am not sure Josef knows what he is talking about.",
  "id" : 625406184221208576,
  "created_at" : "2015-07-26 20:43:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 59, 74 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625401109507538944",
  "geo" : { },
  "id_str" : "625405215727054848",
  "in_reply_to_user_id" : 332579081,
  "text" : "@JosefLokmani We shouldn't us profanity towards each other @chknfriedsteak We shouldn't insult someone's country.",
  "id" : 625405215727054848,
  "in_reply_to_status_id" : 625401109507538944,
  "created_at" : "2015-07-26 20:39:57 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625401109507538944",
  "geo" : { },
  "id_str" : "625404761714634753",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani Nearly 48,000 patents came from Sweden, I am sure at least a few of them are good.",
  "id" : 625404761714634753,
  "in_reply_to_status_id" : 625401109507538944,
  "created_at" : "2015-07-26 20:38:09 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625401109507538944",
  "geo" : { },
  "id_str" : "625404429932589056",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani  In the last 40 years alone was a 30% decrease in Christians in Sweden.",
  "id" : 625404429932589056,
  "in_reply_to_status_id" : 625401109507538944,
  "created_at" : "2015-07-26 20:36:50 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625401109507538944",
  "geo" : { },
  "id_str" : "625404397753909249",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani Sweden was doing much better before joining the European Union.",
  "id" : 625404397753909249,
  "in_reply_to_status_id" : 625401109507538944,
  "created_at" : "2015-07-26 20:36:42 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625402484589244416",
  "text" : "@JosefLokmani I am saying your current Prime Minister isn't as good as the last.",
  "id" : 625402484589244416,
  "created_at" : "2015-07-26 20:29:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Susan\u2764\uFE0F",
      "screen_name" : "srmitchell60",
      "indices" : [ 3, 16 ],
      "id_str" : "175370325",
      "id" : 175370325
    }, {
      "name" : "Linda",
      "screen_name" : "Linnlondon1",
      "indices" : [ 19, 31 ],
      "id_str" : "51609807",
      "id" : 51609807
    }, {
      "name" : "saint by the sea",
      "screen_name" : "stbythec",
      "indices" : [ 33, 42 ],
      "id_str" : "117440808",
      "id" : 117440808
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625396653940412416",
  "text" : "RT @srmitchell60: .@Linnlondon1 .@stbythec  I get it now that I read the article... BHO is such a jerk! They are so juvenile!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Linda",
        "screen_name" : "Linnlondon1",
        "indices" : [ 1, 13 ],
        "id_str" : "51609807",
        "id" : 51609807
      }, {
        "name" : "saint by the sea",
        "screen_name" : "stbythec",
        "indices" : [ 15, 24 ],
        "id_str" : "117440808",
        "id" : 117440808
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "386213957314560000",
    "geo" : { },
    "id_str" : "386268992094371840",
    "in_reply_to_user_id" : 51609807,
    "text" : ".@Linnlondon1 .@stbythec  I get it now that I read the article... BHO is such a jerk! They are so juvenile!!!",
    "id" : 386268992094371840,
    "in_reply_to_status_id" : 386213957314560000,
    "created_at" : "2013-10-04 23:17:58 +0000",
    "in_reply_to_screen_name" : "Linnlondon1",
    "in_reply_to_user_id_str" : "51609807",
    "user" : {
      "name" : "Just Susan\u2764\uFE0F",
      "screen_name" : "srmitchell60",
      "protected" : false,
      "id_str" : "175370325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739927615121690624\/KxXR49fG_normal.jpg",
      "id" : 175370325,
      "verified" : false
    }
  },
  "id" : 625396653940412416,
  "created_at" : "2015-07-26 20:05:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda",
      "screen_name" : "Linnlondon1",
      "indices" : [ 0, 12 ],
      "id_str" : "51609807",
      "id" : 51609807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "386213957314560000",
  "geo" : { },
  "id_str" : "625396599338999808",
  "in_reply_to_user_id" : 51609807,
  "text" : "@Linnlondon1 LOL",
  "id" : 625396599338999808,
  "in_reply_to_status_id" : 386213957314560000,
  "created_at" : "2015-07-26 20:05:43 +0000",
  "in_reply_to_screen_name" : "Linnlondon1",
  "in_reply_to_user_id_str" : "51609807",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625395785241374720",
  "text" : "@JosefLokmani Reinfeldt was qualified for his position, but not over qualified. Your current PM though is just awful. Obama is worse though.",
  "id" : 625395785241374720,
  "created_at" : "2015-07-26 20:02:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625395237498843136",
  "text" : "@JosefLokmani If he was fully conservative though, I think the economy would have went up rather then just staying stable.",
  "id" : 625395237498843136,
  "created_at" : "2015-07-26 20:00:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625391372384735232",
  "text" : "@JosefLokmani He by the way was more conservative economically then the current Prime minister.",
  "id" : 625391372384735232,
  "created_at" : "2015-07-26 19:44:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625391209763217408",
  "text" : "@JosefLokmani He is definitely ten times better the current prime minister. The economy stayed stable under him",
  "id" : 625391209763217408,
  "created_at" : "2015-07-26 19:44:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625390717767143424",
  "text" : "@JosefLokmani By the way the Swedish dollar and the economy got worse and decreased after democratic and liberal rule.",
  "id" : 625390717767143424,
  "created_at" : "2015-07-26 19:42:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625390379345518592",
  "text" : "@JosefLokmani Stefan L\u00F6fven and Fredrik Reinfeldt are liberals, but they aren't as bad as the US president.  Why don't we make a trade?",
  "id" : 625390379345518592,
  "created_at" : "2015-07-26 19:41:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625389008881876993",
  "text" : "@JosefLokmani I got to go Josef, but keep in mind my political ideology isn't the reason of America's downfall, and it ain't stupid as well",
  "id" : 625389008881876993,
  "created_at" : "2015-07-26 19:35:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625388190027894784",
  "text" : "@JosefLokmani The US is going to have a huge downfall if they don't bring back modern liberty, truth, justice, integrity,&amp; true conservatism",
  "id" : 625388190027894784,
  "created_at" : "2015-07-26 19:32:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625387956841410560",
  "text" : "@JosefLokmani You are brainwashed or else you wouldn't think my political ideology is stupid, the same applies to most Americans.",
  "id" : 625387956841410560,
  "created_at" : "2015-07-26 19:31:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teenage Republicans",
      "screen_name" : "TheTeenageGOP",
      "indices" : [ 0, 14 ],
      "id_str" : "2571925363",
      "id" : 2571925363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619511858463133696",
  "geo" : { },
  "id_str" : "625387442691014656",
  "in_reply_to_user_id" : 2571925363,
  "text" : "@TheTeenageGOP At least according to libs",
  "id" : 625387442691014656,
  "in_reply_to_status_id" : 619511858463133696,
  "created_at" : "2015-07-26 19:29:20 +0000",
  "in_reply_to_screen_name" : "TheTeenageGOP",
  "in_reply_to_user_id_str" : "2571925363",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teenage Republicans",
      "screen_name" : "TheTeenageGOP",
      "indices" : [ 3, 17 ],
      "id_str" : "2571925363",
      "id" : 2571925363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625387407177859073",
  "text" : "RT @TheTeenageGOP: July 10, 2015. The Confederate Flag is apparently more despicable then the Nazi Swastika.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619511858463133696",
    "text" : "July 10, 2015. The Confederate Flag is apparently more despicable then the Nazi Swastika.",
    "id" : 619511858463133696,
    "created_at" : "2015-07-10 14:21:51 +0000",
    "user" : {
      "name" : "Teenage Republicans",
      "screen_name" : "TheTeenageGOP",
      "protected" : false,
      "id_str" : "2571925363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478700587299897344\/6v8BF1by_normal.jpeg",
      "id" : 2571925363,
      "verified" : false
    }
  },
  "id" : 625387407177859073,
  "created_at" : "2015-07-26 19:29:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 43, 56 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625387240273932288",
  "text" : "All this debating have gave me a headache. @JosefLokmani Go read a book before you blame us for things we haven't supported or caused",
  "id" : 625387240273932288,
  "created_at" : "2015-07-26 19:28:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firefox \uD83E\uDD8A\uD83C\uDF0D",
      "screen_name" : "firefox",
      "indices" : [ 3, 11 ],
      "id_str" : "2142731",
      "id" : 2142731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/firefox\/status\/625334807204007937\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/q0P3QuKBB9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKsAXSqUMAUXl_6.jpg",
      "id_str" : "624593373467258885",
      "id" : 624593373467258885,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKsAXSqUMAUXl_6.jpg",
      "sizes" : [ {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q0P3QuKBB9"
    } ],
    "hashtags" : [ {
      "text" : "redpandaofthemonth",
      "indices" : [ 63, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625386831446700033",
  "text" : "RT @firefox: This Firefox is all snuggled up, safe and secure. #redpandaofthemonth http:\/\/t.co\/q0P3QuKBB9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/firefox\/status\/625334807204007937\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/q0P3QuKBB9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKsAXSqUMAUXl_6.jpg",
        "id_str" : "624593373467258885",
        "id" : 624593373467258885,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKsAXSqUMAUXl_6.jpg",
        "sizes" : [ {
          "h" : 671,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 671,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 393,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 223,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q0P3QuKBB9"
      } ],
      "hashtags" : [ {
        "text" : "redpandaofthemonth",
        "indices" : [ 50, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "625334807204007937",
    "text" : "This Firefox is all snuggled up, safe and secure. #redpandaofthemonth http:\/\/t.co\/q0P3QuKBB9",
    "id" : 625334807204007937,
    "created_at" : "2015-07-26 16:00:10 +0000",
    "user" : {
      "name" : "Firefox \uD83E\uDD8A\uD83C\uDF0D",
      "screen_name" : "firefox",
      "protected" : false,
      "id_str" : "2142731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747872627218350081\/37FasHm-_normal.jpg",
      "id" : 2142731,
      "verified" : true
    }
  },
  "id" : 625386831446700033,
  "created_at" : "2015-07-26 19:26:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625386516911685632",
  "text" : "@JosefLokmani @chknfriedsteak Why else would they have an idiot elected twice because he is black?",
  "id" : 625386516911685632,
  "created_at" : "2015-07-26 19:25:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625386429405921281",
  "text" : "@JosefLokmani @chknfriedsteak People in the US are brainwashed by the leftist society and media propaganda, I admit that.",
  "id" : 625386429405921281,
  "created_at" : "2015-07-26 19:25:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625386194566795264",
  "text" : "@JosefLokmani @chknfriedsteak Did I mention during the Reagan years, crime rates started to decline in major violent cities?",
  "id" : 625386194566795264,
  "created_at" : "2015-07-26 19:24:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625385897073225728",
  "text" : "@JosefLokmani The more you are talking the more you are proving my point more, the things you are saying weren't done cause of conservatives",
  "id" : 625385897073225728,
  "created_at" : "2015-07-26 19:23:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 111, 123 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625385732513865733",
  "text" : "@JosefLokmani @chknfriedsteak Things conservatives haven't supported. There has been a higher crime rate after @BarackObama took office.",
  "id" : 625385732513865733,
  "created_at" : "2015-07-26 19:22:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625385494906601473",
  "text" : "@JosefLokmani @chknfriedsteak I just told you, the rise of Illegal immigration, drug trafficking, and dishonesty in our government.",
  "id" : 625385494906601473,
  "created_at" : "2015-07-26 19:21:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625384782067814400",
  "text" : "@JosefLokmani @chknfriedsteak The right to own a gun prevents government tyranny, and protects the rights of self defense",
  "id" : 625384782067814400,
  "created_at" : "2015-07-26 19:18:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625384643433529344",
  "text" : "@JosefLokmani @chknfriedsteak Adolf Hitler once said to control a nation, you must first unarm them.",
  "id" : 625384643433529344,
  "created_at" : "2015-07-26 19:18:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625384522419425280",
  "text" : "@JosefLokmani @chknfriedsteak Liberals want to create Gun control and make conservatives look bad so they have more control over its people",
  "id" : 625384522419425280,
  "created_at" : "2015-07-26 19:17:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625384412885176326",
  "text" : "@JosefLokmani @chknfriedsteak Search Eric Holder and the Fast and Furious scandal. Conservatives support responsible usage for self defense.",
  "id" : 625384412885176326,
  "created_at" : "2015-07-26 19:17:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625384050157596672",
  "text" : "@JosefLokmani @chknfriedsteak Did you know Eric Holder was part of a scandal in which he ignored a huge illegal trade to make us look bad?",
  "id" : 625384050157596672,
  "created_at" : "2015-07-26 19:15:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625383812772573184",
  "text" : "@JosefLokmani @chknfriedsteak Switzerland has less gun control then the US and it he lowest crime rate but they promote responsible usage.",
  "id" : 625383812772573184,
  "created_at" : "2015-07-26 19:14:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625383654416588805",
  "text" : "@JosefLokmani @chknfriedsteak Most of mass murders are either illegals or mentally unstable criminals who obtained guns in illegal ways.",
  "id" : 625383654416588805,
  "created_at" : "2015-07-26 19:14:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625382558243639296",
  "text" : "@JosefLokmani @chknfriedsteak That has nothing to do with our political discussion. Also have you took a look on population density?",
  "id" : 625382558243639296,
  "created_at" : "2015-07-26 19:09:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 39, 55 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625378220637077504",
  "text" : "RT @chknfriedsteak: @gamer456148 yeah- @realDonaldTrump is the equivalent of fire ants in the pants if the GOP establishment. This should b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 19, 35 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "623652454018719745",
    "geo" : { },
    "id_str" : "623659435148185600",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 yeah- @realDonaldTrump is the equivalent of fire ants in the pants if the GOP establishment. This should be fun to watch.",
    "id" : 623659435148185600,
    "in_reply_to_status_id" : 623652454018719745,
    "created_at" : "2015-07-22 01:02:51 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 625378220637077504,
  "created_at" : "2015-07-26 18:52:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625377843950841856",
  "text" : "@JosefLokmani @chknfriedsteak Read the works of Ronald Reagan or about how the first Republican president freed the slaves, then come back",
  "id" : 625377843950841856,
  "created_at" : "2015-07-26 18:51:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625376204783120384",
  "geo" : { },
  "id_str" : "625377478333308929",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Age has nothing to do with it, he is a Swede, and has been brainwashed to believe conservatives are evil due to propaganda.",
  "id" : 625377478333308929,
  "in_reply_to_status_id" : 625376204783120384,
  "created_at" : "2015-07-26 18:49:44 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625376938987782145",
  "text" : "@JosefLokmani You support liberalism more then conservatism, that doesn't make you a liberal. I personally think you have no political side.",
  "id" : 625376938987782145,
  "created_at" : "2015-07-26 18:47:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625375884879523840",
  "text" : "@JosefLokmani @chknfriedsteak And we are also free to politely disagree and think liberalism is a complete idiotic ideology.",
  "id" : 625375884879523840,
  "created_at" : "2015-07-26 18:43:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625375726620024834",
  "text" : "@JosefLokmani @chknfriedsteak Josef, I don't know what tell you. You are free to call us stupid or disagree with us, as it is free speech.",
  "id" : 625375726620024834,
  "created_at" : "2015-07-26 18:42:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "indices" : [ 3, 14 ],
      "id_str" : "1074480192",
      "id" : 1074480192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LZl8mYcJ36",
      "expanded_url" : "http:\/\/1.usa.gov\/1LI6D26",
      "display_url" : "1.usa.gov\/1LI6D26"
    } ]
  },
  "geo" : { },
  "id_str" : "625317201562746880",
  "text" : "RT @SenTedCruz: The priorities of the American people are not the priorities of Republican leadership.\u00A0http:\/\/t.co\/LZl8mYcJ36 http:\/\/t.co\/S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenTedCruz\/status\/624665830081581056\/video\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/SVdGY0ar40",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/624665703908528129\/pu\/img\/SXSoK8uFV_HJZuqv.jpg",
        "id_str" : "624665703908528129",
        "id" : 624665703908528129,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/624665703908528129\/pu\/img\/SXSoK8uFV_HJZuqv.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/SVdGY0ar40"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/LZl8mYcJ36",
        "expanded_url" : "http:\/\/1.usa.gov\/1LI6D26",
        "display_url" : "1.usa.gov\/1LI6D26"
      } ]
    },
    "geo" : { },
    "id_str" : "624665830081581056",
    "text" : "The priorities of the American people are not the priorities of Republican leadership.\u00A0http:\/\/t.co\/LZl8mYcJ36 http:\/\/t.co\/SVdGY0ar40",
    "id" : 624665830081581056,
    "created_at" : "2015-07-24 19:41:54 +0000",
    "user" : {
      "name" : "Senator Ted Cruz",
      "screen_name" : "SenTedCruz",
      "protected" : false,
      "id_str" : "1074480192",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762696550124363776\/lf5RZxth_normal.jpg",
      "id" : 1074480192,
      "verified" : true
    }
  },
  "id" : 625317201562746880,
  "created_at" : "2015-07-26 14:50:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BP",
      "screen_name" : "BP_plc",
      "indices" : [ 18, 25 ],
      "id_str" : "1648024394",
      "id" : 1648024394
    }, {
      "name" : "Speedway",
      "screen_name" : "Speedway",
      "indices" : [ 58, 67 ],
      "id_str" : "851526206",
      "id" : 851526206
    }, {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 87, 97 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625316598249824256",
  "text" : "I got Iced Coffee @BP_plc for $2.49, and it is also cheap @Speedway ;College cafe' and @Starbucks is a ripoff in prices.",
  "id" : 625316598249824256,
  "created_at" : "2015-07-26 14:47:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxthon Browser",
      "screen_name" : "Maxthon",
      "indices" : [ 3, 11 ],
      "id_str" : "16900948",
      "id" : 16900948
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "security",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/97J2cAQcUa",
      "expanded_url" : "http:\/\/bit.ly\/1eE5LP6",
      "display_url" : "bit.ly\/1eE5LP6"
    } ]
  },
  "geo" : { },
  "id_str" : "625316110502596609",
  "text" : "RT @Maxthon: Do you trust your phone's #security enough to make purchases online? http:\/\/t.co\/97J2cAQcUa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "security",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/97J2cAQcUa",
        "expanded_url" : "http:\/\/bit.ly\/1eE5LP6",
        "display_url" : "bit.ly\/1eE5LP6"
      } ]
    },
    "geo" : { },
    "id_str" : "624727261682360320",
    "text" : "Do you trust your phone's #security enough to make purchases online? http:\/\/t.co\/97J2cAQcUa",
    "id" : 624727261682360320,
    "created_at" : "2015-07-24 23:46:00 +0000",
    "user" : {
      "name" : "Maxthon Browser",
      "screen_name" : "Maxthon",
      "protected" : false,
      "id_str" : "16900948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/831367514097455104\/FACU47V4_normal.jpg",
      "id" : 16900948,
      "verified" : false
    }
  },
  "id" : 625316110502596609,
  "created_at" : "2015-07-26 14:45:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AdRoll",
      "screen_name" : "AdRoll",
      "indices" : [ 0, 7 ],
      "id_str" : "18818543",
      "id" : 18818543
    }, {
      "name" : "Maxthon Browser",
      "screen_name" : "Maxthon",
      "indices" : [ 8, 16 ],
      "id_str" : "16900948",
      "id" : 16900948
    }, {
      "name" : "AdRoll",
      "screen_name" : "AdRoll",
      "indices" : [ 110, 117 ],
      "id_str" : "18818543",
      "id" : 18818543
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/625316017993052160\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/47JhsIYZPG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CK2Rms8VAAAgZWF.jpg",
      "id_str" : "625316017359618048",
      "id" : 625316017359618048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CK2Rms8VAAAgZWF.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 342
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/47JhsIYZPG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625316017993052160",
  "in_reply_to_user_id" : 18818543,
  "text" : "@AdRoll @Maxthon Ads like these shouldn't show up on browser homepages or \"children friendly\" sites. Disgrace @AdRoll http:\/\/t.co\/47JhsIYZPG",
  "id" : 625316017993052160,
  "created_at" : "2015-07-26 14:45:31 +0000",
  "in_reply_to_screen_name" : "AdRoll",
  "in_reply_to_user_id_str" : "18818543",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "indices" : [ 0, 13 ],
      "id_str" : "149913262",
      "id" : 149913262
    }, {
      "name" : "Conservative Mom",
      "screen_name" : "ConservThoughts",
      "indices" : [ 14, 30 ],
      "id_str" : "105715146",
      "id" : 105715146
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502449377126805504",
  "geo" : { },
  "id_str" : "625269067826507776",
  "in_reply_to_user_id" : 149913262,
  "text" : "@iowahawkblog @ConservThoughts Don't forget the Iran Nuclear Deal, the Iranian officials are laughing at America as we speak.",
  "id" : 625269067826507776,
  "in_reply_to_status_id" : 502449377126805504,
  "created_at" : "2015-07-26 11:38:57 +0000",
  "in_reply_to_screen_name" : "iowahawkblog",
  "in_reply_to_user_id_str" : "149913262",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "indices" : [ 0, 13 ],
      "id_str" : "149913262",
      "id" : 149913262
    }, {
      "name" : "Conservative Mom",
      "screen_name" : "ConservThoughts",
      "indices" : [ 14, 30 ],
      "id_str" : "105715146",
      "id" : 105715146
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 35, 47 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502498504472666112",
  "geo" : { },
  "id_str" : "625268797885313024",
  "in_reply_to_user_id" : 149913262,
  "text" : "@iowahawkblog @ConservThoughts The @BarackObama hope poster propaganda maker is apparently shocked Obama isn't who he expected",
  "id" : 625268797885313024,
  "in_reply_to_status_id" : 502498504472666112,
  "created_at" : "2015-07-26 11:37:53 +0000",
  "in_reply_to_screen_name" : "iowahawkblog",
  "in_reply_to_user_id_str" : "149913262",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "indices" : [ 3, 16 ],
      "id_str" : "149913262",
      "id" : 149913262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625268420708290560",
  "text" : "RT @iowahawkblog: \"First they ignore you, then they mock you, then you win.\" -Gandhi\n\"First they fund you, then they mock you, then you beh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502798705314242560",
    "text" : "\"First they ignore you, then they mock you, then you win.\" -Gandhi\n\"First they fund you, then they mock you, then you behead them.\" -ISIS",
    "id" : 502798705314242560,
    "created_at" : "2014-08-22 12:45:27 +0000",
    "user" : {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "protected" : false,
      "id_str" : "149913262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879271765\/2375_84984116216_633511216_2728356_7132856_n_normal.jpg",
      "id" : 149913262,
      "verified" : false
    }
  },
  "id" : 625268420708290560,
  "created_at" : "2015-07-26 11:36:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "indices" : [ 3, 16 ],
      "id_str" : "149913262",
      "id" : 149913262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625268324541329408",
  "text" : "RT @iowahawkblog: White House says the \"Islamic State\" has nothing to do with Islam, sort of like the \"United States\" has nothing to do wit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502800229247488000",
    "text" : "White House says the \"Islamic State\" has nothing to do with Islam, sort of like the \"United States\" has nothing to do with unity.",
    "id" : 502800229247488000,
    "created_at" : "2014-08-22 12:51:30 +0000",
    "user" : {
      "name" : "David Burge",
      "screen_name" : "iowahawkblog",
      "protected" : false,
      "id_str" : "149913262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1879271765\/2375_84984116216_633511216_2728356_7132856_n_normal.jpg",
      "id" : 149913262,
      "verified" : false
    }
  },
  "id" : 625268324541329408,
  "created_at" : "2015-07-26 11:36:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 66, 75 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625268088783638529",
  "text" : "Seriously I hate disgusting click bait ads all over the internet, @BuzzFeed",
  "id" : 625268088783638529,
  "created_at" : "2015-07-26 11:35:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AdRoll",
      "screen_name" : "AdRoll",
      "indices" : [ 10, 17 ],
      "id_str" : "18818543",
      "id" : 18818543
    }, {
      "name" : "9GAG",
      "screen_name" : "9GAG",
      "indices" : [ 102, 107 ],
      "id_str" : "16548023",
      "id" : 16548023
    }, {
      "name" : "CollegeHumor",
      "screen_name" : "CollegeHumor",
      "indices" : [ 108, 121 ],
      "id_str" : "16825289",
      "id" : 16825289
    }, {
      "name" : "The Young Turks",
      "screen_name" : "TheYoungTurks",
      "indices" : [ 122, 136 ],
      "id_str" : "14957147",
      "id" : 14957147
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625267761913167872",
  "text" : "Thanks to @AdRoll for promoting disgusting adult ads and allowing them through the system. Also thank @9GAG @CollegeHumor @TheYoungTurks",
  "id" : 625267761913167872,
  "created_at" : "2015-07-26 11:33:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625138381668909056",
  "text" : "RT @chknfriedsteak: @gamer456148 I understand what Trump is trying to do, but unfortunately he doesn't have a resistor installed between hi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "625131983656603648",
    "geo" : { },
    "id_str" : "625135371643269120",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I understand what Trump is trying to do, but unfortunately he doesn't have a resistor installed between his processor and mouth",
    "id" : 625135371643269120,
    "in_reply_to_status_id" : 625131983656603648,
    "created_at" : "2015-07-26 02:47:41 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 625138381668909056,
  "created_at" : "2015-07-26 02:59:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 43, 51 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625133651710357504",
  "text" : "RT @chknfriedsteak: @gamer456148 I enjoyed @tedcruz owning Mitch McConnell yesterday.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 23, 31 ],
        "id_str" : "23022687",
        "id" : 23022687
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "625130578065682432",
    "geo" : { },
    "id_str" : "625131492599967744",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I enjoyed @tedcruz owning Mitch McConnell yesterday.",
    "id" : 625131492599967744,
    "in_reply_to_status_id" : 625130578065682432,
    "created_at" : "2015-07-26 02:32:16 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 625133651710357504,
  "created_at" : "2015-07-26 02:40:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625131906380660736",
  "geo" : { },
  "id_str" : "625133477055332352",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Yeah Jeb Bush would be the monkey in the Republican ring.",
  "id" : 625133477055332352,
  "in_reply_to_status_id" : 625131906380660736,
  "created_at" : "2015-07-26 02:40:10 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 16, 24 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625131492599967744",
  "geo" : { },
  "id_str" : "625133166492303360",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @tedcruz Oh my gosh yes!!!",
  "id" : 625133166492303360,
  "in_reply_to_status_id" : 625131492599967744,
  "created_at" : "2015-07-26 02:38:55 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625131067842801664",
  "geo" : { },
  "id_str" : "625132679986565120",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak What he said on the Oprah Winfrey show makes me wanna barf. A new age motivational speaker being a VP, no thanks",
  "id" : 625132679986565120,
  "in_reply_to_status_id" : 625131067842801664,
  "created_at" : "2015-07-26 02:36:59 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625131067842801664",
  "geo" : { },
  "id_str" : "625131983656603648",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak He is insulting both sides, his best chance is running independent. He went as far as insulting Walker, who was nice to him.",
  "id" : 625131983656603648,
  "in_reply_to_status_id" : 625131067842801664,
  "created_at" : "2015-07-26 02:34:13 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt S",
      "screen_name" : "AmbassadorSeips",
      "indices" : [ 3, 19 ],
      "id_str" : "246874928",
      "id" : 246874928
    }, {
      "name" : "Young Conservatives",
      "screen_name" : "YoungCons",
      "indices" : [ 21, 31 ],
      "id_str" : "42822396",
      "id" : 42822396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625131443610591232",
  "text" : "RT @AmbassadorSeips: @YoungCons I see what he is doing. Insults the right and the left then runs as an independent",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Young Conservatives",
        "screen_name" : "YoungCons",
        "indices" : [ 0, 10 ],
        "id_str" : "42822396",
        "id" : 42822396
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "624632235468025856",
    "geo" : { },
    "id_str" : "624632493073797122",
    "in_reply_to_user_id" : 42822396,
    "text" : "@YoungCons I see what he is doing. Insults the right and the left then runs as an independent",
    "id" : 624632493073797122,
    "in_reply_to_status_id" : 624632235468025856,
    "created_at" : "2015-07-24 17:29:26 +0000",
    "in_reply_to_screen_name" : "YoungCons",
    "in_reply_to_user_id_str" : "42822396",
    "user" : {
      "name" : "Matt S",
      "screen_name" : "AmbassadorSeips",
      "protected" : false,
      "id_str" : "246874928",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832045261723672577\/r4tRoTCI_normal.jpg",
      "id" : 246874928,
      "verified" : false
    }
  },
  "id" : 625131443610591232,
  "created_at" : "2015-07-26 02:32:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Young Conservatives",
      "screen_name" : "YoungCons",
      "indices" : [ 3, 13 ],
      "id_str" : "42822396",
      "id" : 42822396
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/624632235468025856\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/oUDHAyXXyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKsjtRrVAAAysDA.jpg",
      "id_str" : "624632234067165184",
      "id" : 624632234067165184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKsjtRrVAAAysDA.jpg",
      "sizes" : [ {
        "h" : 362,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 362,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/oUDHAyXXyX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/gVKwQoJeh9",
      "expanded_url" : "http:\/\/www.youngcons.com\/donald-trump-blames-2008-financial-crisis-on-republicans\/",
      "display_url" : "youngcons.com\/donald-trump-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "625131408219074560",
  "text" : "RT @YoungCons: Ugh: Look Who Donald Trump Just BLAMED for the 2008 Financial Crisis http:\/\/t.co\/gVKwQoJeh9 http:\/\/t.co\/oUDHAyXXyX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YoungCons\/status\/624632235468025856\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/oUDHAyXXyX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKsjtRrVAAAysDA.jpg",
        "id_str" : "624632234067165184",
        "id" : 624632234067165184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKsjtRrVAAAysDA.jpg",
        "sizes" : [ {
          "h" : 362,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 362,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/oUDHAyXXyX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/gVKwQoJeh9",
        "expanded_url" : "http:\/\/www.youngcons.com\/donald-trump-blames-2008-financial-crisis-on-republicans\/",
        "display_url" : "youngcons.com\/donald-trump-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "624632235468025856",
    "text" : "Ugh: Look Who Donald Trump Just BLAMED for the 2008 Financial Crisis http:\/\/t.co\/gVKwQoJeh9 http:\/\/t.co\/oUDHAyXXyX",
    "id" : 624632235468025856,
    "created_at" : "2015-07-24 17:28:24 +0000",
    "user" : {
      "name" : "Young Conservatives",
      "screen_name" : "YoungCons",
      "protected" : false,
      "id_str" : "42822396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/804732920661413892\/Kj1d5f6-_normal.jpg",
      "id" : 42822396,
      "verified" : false
    }
  },
  "id" : 625131408219074560,
  "created_at" : "2015-07-26 02:31:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625129960366309376",
  "geo" : { },
  "id_str" : "625130948057780224",
  "in_reply_to_user_id" : 210979938,
  "text" : "@chknfriedsteak I am however, in no way a huge Bush fan due to how Bush handled: Iran, Immigration, and foreign relations. (unwisely)",
  "id" : 625130948057780224,
  "in_reply_to_status_id" : 625129960366309376,
  "created_at" : "2015-07-26 02:30:07 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625129960366309376",
  "geo" : { },
  "id_str" : "625130578065682432",
  "in_reply_to_user_id" : 210979938,
  "text" : "@chknfriedsteak I was in some support in Trump until what he said about the 2008 economic crisis, complete bull to blame bush",
  "id" : 625130578065682432,
  "in_reply_to_status_id" : 625129960366309376,
  "created_at" : "2015-07-26 02:28:38 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625129960366309376",
  "geo" : { },
  "id_str" : "625130314940174337",
  "in_reply_to_user_id" : 210979938,
  "text" : "@chknfriedsteak He is more of an independent and he is doing harm to the grand ole' party he claims to be a part off",
  "id" : 625130314940174337,
  "in_reply_to_status_id" : 625129960366309376,
  "created_at" : "2015-07-26 02:27:36 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "625129960366309376",
  "geo" : { },
  "id_str" : "625130156840067072",
  "in_reply_to_user_id" : 210979938,
  "text" : "@chknfriedsteak Don't think he is a real conservative, he is more midway and though strict is his personality, he shouldn't run Republican",
  "id" : 625130156840067072,
  "in_reply_to_status_id" : 625129960366309376,
  "created_at" : "2015-07-26 02:26:58 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625129960366309376",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak I am beginning to have second thoughts about Trump, he said on MSNBC he thinks in some cases liberals are doing econ. better",
  "id" : 625129960366309376,
  "created_at" : "2015-07-26 02:26:11 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark R. Levin",
      "screen_name" : "marklevinshow",
      "indices" : [ 3, 17 ],
      "id_str" : "38495835",
      "id" : 38495835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2GncdP5UQ9",
      "expanded_url" : "http:\/\/fb.me\/465Zx4i9G",
      "display_url" : "fb.me\/465Zx4i9G"
    } ]
  },
  "geo" : { },
  "id_str" : "625126539328360448",
  "text" : "RT @marklevinshow: Thanks to Donald Trump for his kind tweet re my book, Plunder &amp; Deceit http:\/\/t.co\/2GncdP5UQ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/2GncdP5UQ9",
        "expanded_url" : "http:\/\/fb.me\/465Zx4i9G",
        "display_url" : "fb.me\/465Zx4i9G"
      } ]
    },
    "geo" : { },
    "id_str" : "624670319010295808",
    "text" : "Thanks to Donald Trump for his kind tweet re my book, Plunder &amp; Deceit http:\/\/t.co\/2GncdP5UQ9",
    "id" : 624670319010295808,
    "created_at" : "2015-07-24 19:59:44 +0000",
    "user" : {
      "name" : "Mark R. Levin",
      "screen_name" : "marklevinshow",
      "protected" : false,
      "id_str" : "38495835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000116305623\/80c5515ce8244c85105172fe5640f550_normal.jpeg",
      "id" : 38495835,
      "verified" : true
    }
  },
  "id" : 625126539328360448,
  "created_at" : "2015-07-26 02:12:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 38, 46 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "624987427808124928",
  "geo" : { },
  "id_str" : "625126082870681600",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump What do you think of @tedcruz who by the way is my primary choice of candidate? I mean Cruz will make a great candidate :)",
  "id" : 625126082870681600,
  "in_reply_to_status_id" : 624987427808124928,
  "created_at" : "2015-07-26 02:10:47 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Ariana Trump",
      "screen_name" : "TiffanyATrump",
      "indices" : [ 0, 14 ],
      "id_str" : "245963716",
      "id" : 245963716
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "625124845760684032",
  "in_reply_to_user_id" : 245963716,
  "text" : "@TiffanyATrump So your dad is running for president, my dad is running for ten pounds \uD83D\uDE06 I wonder if I was the first to throw that joke in!!",
  "id" : 625124845760684032,
  "created_at" : "2015-07-26 02:05:52 +0000",
  "in_reply_to_screen_name" : "TiffanyATrump",
  "in_reply_to_user_id_str" : "245963716",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 0, 8 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624308892248322052",
  "in_reply_to_user_id" : 10228272,
  "text" : "@YouTube made a new mobile UI design",
  "id" : 624308892248322052,
  "created_at" : "2015-07-23 20:03:33 +0000",
  "in_reply_to_screen_name" : "YouTube",
  "in_reply_to_user_id_str" : "10228272",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "American Refugee",
      "screen_name" : "mericanrefugee",
      "indices" : [ 3, 18 ],
      "id_str" : "947843994",
      "id" : 947843994
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mericanrefugee\/status\/622567892865916929\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DAzYdBCyyD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKPOMw2UkAA2tC6.jpg",
      "id_str" : "622567892173754368",
      "id" : 622567892173754368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKPOMw2UkAA2tC6.jpg",
      "sizes" : [ {
        "h" : 1370,
        "resize" : "fit",
        "w" : 908
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1370,
        "resize" : "fit",
        "w" : 908
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 905,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DAzYdBCyyD"
    } ],
    "hashtags" : [ {
      "text" : "CruzCrew",
      "indices" : [ 93, 102 ]
    }, {
      "text" : "Waar",
      "indices" : [ 103, 108 ]
    }, {
      "text" : "PJNET",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624234198023450624",
  "text" : "RT @mericanrefugee: Let's forget this Trump distraction and get serious about electing Cruz. #CruzCrew #Waar #PJNET http:\/\/t.co\/DAzYdBCyyD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mericanrefugee\/status\/622567892865916929\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/DAzYdBCyyD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CKPOMw2UkAA2tC6.jpg",
        "id_str" : "622567892173754368",
        "id" : 622567892173754368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKPOMw2UkAA2tC6.jpg",
        "sizes" : [ {
          "h" : 1370,
          "resize" : "fit",
          "w" : 908
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1370,
          "resize" : "fit",
          "w" : 908
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 905,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DAzYdBCyyD"
      } ],
      "hashtags" : [ {
        "text" : "CruzCrew",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "Waar",
        "indices" : [ 83, 88 ]
      }, {
        "text" : "PJNET",
        "indices" : [ 89, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622567892865916929",
    "text" : "Let's forget this Trump distraction and get serious about electing Cruz. #CruzCrew #Waar #PJNET http:\/\/t.co\/DAzYdBCyyD",
    "id" : 622567892865916929,
    "created_at" : "2015-07-19 00:45:27 +0000",
    "user" : {
      "name" : "American Refugee",
      "screen_name" : "mericanrefugee",
      "protected" : false,
      "id_str" : "947843994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610592110044180480\/s0IbV3mB_normal.png",
      "id" : 947843994,
      "verified" : false
    }
  },
  "id" : 624234198023450624,
  "created_at" : "2015-07-23 15:06:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/624234071883927552\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4S2qgkzggL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKm5lJUVAAAJkjK.jpg",
      "id_str" : "624234071175004160",
      "id" : 624234071175004160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKm5lJUVAAAJkjK.jpg",
      "sizes" : [ {
        "h" : 287,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 460
      }, {
        "h" : 212,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 460
      } ],
      "display_url" : "pic.twitter.com\/4S2qgkzggL"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "624234071883927552",
  "text" : "Samantha, Lauren, and this person named Erica have all been victims of the \"Break the Ice Joke\" #ThisIsOU http:\/\/t.co\/4S2qgkzggL",
  "id" : 624234071883927552,
  "created_at" : "2015-07-23 15:06:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AD",
      "indices" : [ 39, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/HxG1xCdO7H",
      "expanded_url" : "http:\/\/fb.me\/48803KJuC",
      "display_url" : "fb.me\/48803KJuC"
    } ]
  },
  "geo" : { },
  "id_str" : "624055111606792192",
  "text" : "Can't wait to see this on Thanksgiving #AD http:\/\/t.co\/HxG1xCdO7H",
  "id" : 624055111606792192,
  "created_at" : "2015-07-23 03:15:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Gov. Mike Huckabee",
      "screen_name" : "GovMikeHuckabee",
      "indices" : [ 18, 34 ],
      "id_str" : "15416505",
      "id" : 15416505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623844671454859264",
  "text" : "RT @seanhannity: .@GovMikeHuckabee: \u201CThis president, why doesn\u2019t he order his Attorney General to conduct an investigation of Planned Paren\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gov. Mike Huckabee",
        "screen_name" : "GovMikeHuckabee",
        "indices" : [ 1, 17 ],
        "id_str" : "15416505",
        "id" : 15416505
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hannity",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621510071424409600",
    "text" : ".@GovMikeHuckabee: \u201CThis president, why doesn\u2019t he order his Attorney General to conduct an investigation of Planned Parenthood?\u201D #Hannity",
    "id" : 621510071424409600,
    "created_at" : "2015-07-16 02:42:02 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 623844671454859264,
  "created_at" : "2015-07-22 13:18:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 0, 10 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/623844060919406592\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/umyuYJF9Ji",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKhW3jXWcAERpn-.jpg",
      "id_str" : "623844060776787969",
      "id" : 623844060776787969,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKhW3jXWcAERpn-.jpg",
      "sizes" : [ {
        "h" : 592,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1381,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1010,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/umyuYJF9Ji"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623844060919406592",
  "in_reply_to_user_id" : 30973,
  "text" : "@Starbucks This is more calories then my breakfast. #ThisIsOU http:\/\/t.co\/umyuYJF9Ji",
  "id" : 623844060919406592,
  "created_at" : "2015-07-22 13:16:29 +0000",
  "in_reply_to_screen_name" : "Starbucks",
  "in_reply_to_user_id_str" : "30973",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623826080688779265",
  "text" : "Class in 30 minutes, time to think outside the box #ThisIsOU",
  "id" : 623826080688779265,
  "created_at" : "2015-07-22 12:05:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623681510369947648",
  "text" : "We need to at least try and bring back this country to the baby loving, church going, gun owning, flag flowing, liberty that it once was!!!",
  "id" : 623681510369947648,
  "created_at" : "2015-07-22 02:30:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Connors",
      "screen_name" : "Evconn5",
      "indices" : [ 3, 11 ],
      "id_str" : "2729980120",
      "id" : 2729980120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623680930335428608",
  "text" : "RT @Evconn5: \"Where ever this flag's flown, we take care of our own.\" -Bruce Springsteen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622626433475702784",
    "text" : "\"Where ever this flag's flown, we take care of our own.\" -Bruce Springsteen",
    "id" : 622626433475702784,
    "created_at" : "2015-07-19 04:38:04 +0000",
    "user" : {
      "name" : "Evan Connors",
      "screen_name" : "Evconn5",
      "protected" : false,
      "id_str" : "2729980120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796544222643953664\/1sUQxKFx_normal.jpg",
      "id" : 2729980120,
      "verified" : false
    }
  },
  "id" : 623680930335428608,
  "created_at" : "2015-07-22 02:28:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amal Ragheb",
      "screen_name" : "ragheb_amal",
      "indices" : [ 3, 15 ],
      "id_str" : "1575549728",
      "id" : 1575549728
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/TS24BcX827",
      "expanded_url" : "http:\/\/youtu.be\/BfFQi4HVvbo",
      "display_url" : "youtu.be\/BfFQi4HVvbo"
    } ]
  },
  "geo" : { },
  "id_str" : "623680680522715137",
  "text" : "RT @ragheb_amal: Je nai nan - Have mercy - \u062C\u064A \u0646\u0627\u064A \u0646\u0627\u0646 - a Coptic hymn http:\/\/t.co\/TS24BcX827",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/TS24BcX827",
        "expanded_url" : "http:\/\/youtu.be\/BfFQi4HVvbo",
        "display_url" : "youtu.be\/BfFQi4HVvbo"
      } ]
    },
    "geo" : { },
    "id_str" : "621320893340512257",
    "text" : "Je nai nan - Have mercy - \u062C\u064A \u0646\u0627\u064A \u0646\u0627\u0646 - a Coptic hymn http:\/\/t.co\/TS24BcX827",
    "id" : 621320893340512257,
    "created_at" : "2015-07-15 14:10:19 +0000",
    "user" : {
      "name" : "Amal Ragheb",
      "screen_name" : "ragheb_amal",
      "protected" : false,
      "id_str" : "1575549728",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/424508859286179840\/s6zG1wIp_normal.jpeg",
      "id" : 1575549728,
      "verified" : false
    }
  },
  "id" : 623680680522715137,
  "created_at" : "2015-07-22 02:27:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621414965132443648",
  "geo" : { },
  "id_str" : "623680268969181184",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani I would trade Obama for Putin any day",
  "id" : 623680268969181184,
  "in_reply_to_status_id" : 621414965132443648,
  "created_at" : "2015-07-22 02:25:38 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621414965132443648",
  "geo" : { },
  "id_str" : "623680168997982208",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani part of communism and social Marxism goes against some of Putin's economic and religious beliefs-",
  "id" : 623680168997982208,
  "in_reply_to_status_id" : 621414965132443648,
  "created_at" : "2015-07-22 02:25:14 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621414965132443648",
  "geo" : { },
  "id_str" : "623679769729634304",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani He is somewhere between communism and Stuanch conservative and he sure isn't a liberal",
  "id" : 623679769729634304,
  "in_reply_to_status_id" : 621414965132443648,
  "created_at" : "2015-07-22 02:23:39 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621414965132443648",
  "geo" : { },
  "id_str" : "623679574585425920",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani It combines Unity for Russia and independent political affiliations with conservative ideology",
  "id" : 623679574585425920,
  "in_reply_to_status_id" : 621414965132443648,
  "created_at" : "2015-07-22 02:22:52 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621414965132443648",
  "geo" : { },
  "id_str" : "623679244564967424",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani I would say he is more of an independent, part of his own political movement called People's Front for Russia",
  "id" : 623679244564967424,
  "in_reply_to_status_id" : 621414965132443648,
  "created_at" : "2015-07-22 02:21:33 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623676796786053120",
  "text" : "RT @chknfriedsteak: @gamer456148 spot on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "623667506209792001",
    "geo" : { },
    "id_str" : "623668224576454656",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 spot on.",
    "id" : 623668224576454656,
    "in_reply_to_status_id" : 623667506209792001,
    "created_at" : "2015-07-22 01:37:46 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 623676796786053120,
  "created_at" : "2015-07-22 02:11:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/623667506209792001\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HTumJw8sAl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKe2SrDWEAAanXX.jpg",
      "id_str" : "623667505324756992",
      "id" : 623667505324756992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKe2SrDWEAAanXX.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HTumJw8sAl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623667506209792001",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Not the first time I use a meme to describe my political views, but this basically sums it up!!! http:\/\/t.co\/HTumJw8sAl",
  "id" : 623667506209792001,
  "created_at" : "2015-07-22 01:34:55 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "623314327274041345",
  "geo" : { },
  "id_str" : "623652454018719745",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak I love trump, he is a no BS type of guy and great for the economy, but my first choice candidate would be Ted Cruz",
  "id" : 623652454018719745,
  "in_reply_to_status_id" : 623314327274041345,
  "created_at" : "2015-07-22 00:35:06 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623577090755985408",
  "text" : "Oh goodness #ThisIsOU",
  "id" : 623577090755985408,
  "created_at" : "2015-07-21 19:35:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Dunne",
      "screen_name" : "dunners11",
      "indices" : [ 3, 13 ],
      "id_str" : "564732923",
      "id" : 564732923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623501226857111552",
  "text" : "RT @dunners11: Frustrating day but what a week! I will learn so much from this incredible experience! Can't thank you enough for all the su\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dreambig",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "623218066294460416",
    "text" : "Frustrating day but what a week! I will learn so much from this incredible experience! Can't thank you enough for all the support! #dreambig",
    "id" : 623218066294460416,
    "created_at" : "2015-07-20 19:49:00 +0000",
    "user" : {
      "name" : "Paul Dunne",
      "screen_name" : "dunners11",
      "protected" : false,
      "id_str" : "564732923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835882958875680772\/g9rkDP9Y_normal.jpg",
      "id" : 564732923,
      "verified" : false
    }
  },
  "id" : 623501226857111552,
  "created_at" : "2015-07-21 14:34:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/623501020895780865\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/tlB9ouZhW8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKce3_6WUAAY1e5.jpg",
      "id_str" : "623501020811907072",
      "id" : 623501020811907072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKce3_6WUAAY1e5.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tlB9ouZhW8"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623501020895780865",
  "text" : "More coffee #ThisIsOU # LibraryCafe http:\/\/t.co\/tlB9ouZhW8",
  "id" : 623501020895780865,
  "created_at" : "2015-07-21 14:33:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622627877347930112",
  "geo" : { },
  "id_str" : "623317368098418689",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes We are worried, you can't be so negative man. Think of all the good things in life. Don't worry be happy \uD83D\uDE0A",
  "id" : 623317368098418689,
  "in_reply_to_status_id" : 622627877347930112,
  "created_at" : "2015-07-21 02:23:35 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Dunne",
      "screen_name" : "dunners11",
      "indices" : [ 3, 13 ],
      "id_str" : "564732923",
      "id" : 564732923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheOpen",
      "indices" : [ 119, 127 ]
    }, {
      "text" : "GoBlazers",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "623088869626523649",
  "text" : "RT @dunners11: What an enjoyable day that was! Thanks again for all the support! Let's see what tomorrow throws at us! #TheOpen #GoBlazers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheOpen",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "GoBlazers",
        "indices" : [ 113, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "622849897998458881",
    "text" : "What an enjoyable day that was! Thanks again for all the support! Let's see what tomorrow throws at us! #TheOpen #GoBlazers",
    "id" : 622849897998458881,
    "created_at" : "2015-07-19 19:26:02 +0000",
    "user" : {
      "name" : "Paul Dunne",
      "screen_name" : "dunners11",
      "protected" : false,
      "id_str" : "564732923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835882958875680772\/g9rkDP9Y_normal.jpg",
      "id" : 564732923,
      "verified" : false
    }
  },
  "id" : 623088869626523649,
  "created_at" : "2015-07-20 11:15:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/622478952788049920\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/fav0hF2seM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKN9TzeWEAAZ5BU.jpg",
      "id_str" : "622478952695730176",
      "id" : 622478952695730176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKN9TzeWEAAZ5BU.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fav0hF2seM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622478952788049920",
  "text" : "Great candy http:\/\/t.co\/fav0hF2seM",
  "id" : 622478952788049920,
  "created_at" : "2015-07-18 18:52:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Video Games",
      "screen_name" : "EleenaFisher",
      "indices" : [ 3, 16 ],
      "id_str" : "268536859",
      "id" : 268536859
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/449267621079580672\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/GV2hsWBarb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwehVoIAAAzern.jpg",
      "id_str" : "449267620920164352",
      "id" : 449267620920164352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwehVoIAAAzern.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/GV2hsWBarb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622098970601488384",
  "text" : "RT @EleenaFisher: That strange moment when you see your childhood behind glass in a museum. http:\/\/t.co\/GV2hsWBarb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/449267621079580672\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/GV2hsWBarb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwehVoIAAAzern.jpg",
        "id_str" : "449267620920164352",
        "id" : 449267620920164352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwehVoIAAAzern.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/GV2hsWBarb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621809600136806402",
    "text" : "That strange moment when you see your childhood behind glass in a museum. http:\/\/t.co\/GV2hsWBarb",
    "id" : 621809600136806402,
    "created_at" : "2015-07-16 22:32:15 +0000",
    "user" : {
      "name" : "Video Games",
      "screen_name" : "EleenaFisher",
      "protected" : false,
      "id_str" : "268536859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817019958836137984\/xs0pPXA2_normal.jpg",
      "id" : 268536859,
      "verified" : false
    }
  },
  "id" : 622098970601488384,
  "created_at" : "2015-07-17 17:42:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zigmah \/ Zach",
      "screen_name" : "YaBoyZigmah",
      "indices" : [ 3, 15 ],
      "id_str" : "1214576132",
      "id" : 1214576132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "622098839617564673",
  "text" : "RT @YaBoyZigmah: Some people act so immature sometimes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589258759932903426",
    "text" : "Some people act so immature sometimes.",
    "id" : 589258759932903426,
    "created_at" : "2015-04-18 02:46:50 +0000",
    "user" : {
      "name" : "Zigmah \/ Zach",
      "screen_name" : "YaBoyZigmah",
      "protected" : false,
      "id_str" : "1214576132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691446893554110465\/VpGi_7bx_normal.png",
      "id" : 1214576132,
      "verified" : false
    }
  },
  "id" : 622098839617564673,
  "created_at" : "2015-07-17 17:41:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guy Kawasaki",
      "screen_name" : "GuyKawasaki",
      "indices" : [ 0, 12 ],
      "id_str" : "8453452",
      "id" : 8453452
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622070044026118144",
  "geo" : { },
  "id_str" : "622098525468364800",
  "in_reply_to_user_id" : 8453452,
  "text" : "@GuyKawasaki Try Bill Gates or Robert Herjavec's house next",
  "id" : 622098525468364800,
  "in_reply_to_status_id" : 622070044026118144,
  "created_at" : "2015-07-17 17:40:21 +0000",
  "in_reply_to_screen_name" : "GuyKawasaki",
  "in_reply_to_user_id_str" : "8453452",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621770210068946944",
  "geo" : { },
  "id_str" : "622098025905803265",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Works 1 out of 10 times",
  "id" : 622098025905803265,
  "in_reply_to_status_id" : 621770210068946944,
  "created_at" : "2015-07-17 17:38:22 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621770210068946944",
  "geo" : { },
  "id_str" : "622097948718051328",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Get out of the friend son: Ignore her for weeks tell she forgets about you, then be like hey girl I got something to say",
  "id" : 622097948718051328,
  "in_reply_to_status_id" : 621770210068946944,
  "created_at" : "2015-07-17 17:38:03 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "622094641656020992",
  "geo" : { },
  "id_str" : "622097017108570112",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes You basically described every marriage ever, lol",
  "id" : 622097017108570112,
  "in_reply_to_status_id" : 622094641656020992,
  "created_at" : "2015-07-17 17:34:21 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CathyMcMorrisRodgers",
      "screen_name" : "cathymcmorris",
      "indices" : [ 3, 17 ],
      "id_str" : "17976923",
      "id" : 17976923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621717489618157568",
  "text" : "RT @cathymcmorris: Last week, in an overwhelmingly bipartisan vote, we passed the 21st Century Cures Act, to empower life-saving innovation\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cures2015",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "620960030481870849",
    "text" : "Last week, in an overwhelmingly bipartisan vote, we passed the 21st Century Cures Act, to empower life-saving innovation. #Cures2015",
    "id" : 620960030481870849,
    "created_at" : "2015-07-14 14:16:22 +0000",
    "user" : {
      "name" : "CathyMcMorrisRodgers",
      "screen_name" : "cathymcmorris",
      "protected" : false,
      "id_str" : "17976923",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/741337467714953217\/5t14nEYg_normal.jpg",
      "id" : 17976923,
      "verified" : true
    }
  },
  "id" : 621717489618157568,
  "created_at" : "2015-07-16 16:26:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Upton",
      "screen_name" : "RepFredUpton",
      "indices" : [ 3, 16 ],
      "id_str" : "124224165",
      "id" : 124224165
    }, {
      "name" : "Energy and Commerce",
      "screen_name" : "HouseCommerce",
      "indices" : [ 79, 93 ],
      "id_str" : "114756202",
      "id" : 114756202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621717233903927296",
  "text" : "RT @RepFredUpton: Planned Parenthood video is abhorrent and rips at the heart. @HouseCommerce will get to the bottom of this appalling situ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy and Commerce",
        "screen_name" : "HouseCommerce",
        "indices" : [ 61, 75 ],
        "id_str" : "114756202",
        "id" : 114756202
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621352306521604096",
    "text" : "Planned Parenthood video is abhorrent and rips at the heart. @HouseCommerce will get to the bottom of this appalling situation.",
    "id" : 621352306521604096,
    "created_at" : "2015-07-15 16:15:08 +0000",
    "user" : {
      "name" : "Fred Upton",
      "screen_name" : "RepFredUpton",
      "protected" : false,
      "id_str" : "124224165",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000507840583\/0dc990a78881b2a41d0dc1e7e751b839_normal.jpeg",
      "id" : 124224165,
      "verified" : true
    }
  },
  "id" : 621717233903927296,
  "created_at" : "2015-07-16 16:25:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KID",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621716856563437568",
  "text" : "I had a $5 shopping spree today. The results were a fried foods\/ pastries attack and got some garage sale toys\/gifts, when will I learn #KID",
  "id" : 621716856563437568,
  "created_at" : "2015-07-16 16:23:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/621716347987324928\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/luEehvApch",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKDHuXLW8AAghKz.jpg",
      "id_str" : "621716347886694400",
      "id" : 621716347886694400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKDHuXLW8AAghKz.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/luEehvApch"
    } ],
    "hashtags" : [ {
      "text" : "Donut",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621716347987324928",
  "text" : "How a real pastry looks like: Knapp's #Donut http:\/\/t.co\/luEehvApch",
  "id" : 621716347987324928,
  "created_at" : "2015-07-16 16:21:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sploder.com",
      "screen_name" : "sploder",
      "indices" : [ 57, 65 ],
      "id_str" : "39554440",
      "id" : 39554440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621686586233745408",
  "text" : "I made a game with my little sis yesterday thanks to the @sploder website :)",
  "id" : 621686586233745408,
  "created_at" : "2015-07-16 14:23:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/621686289910394880\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/Ep1HbljEQB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKCsYuaWUAAuPt2.jpg",
      "id_str" : "621686289352511488",
      "id" : 621686289352511488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKCsYuaWUAAuPt2.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 918,
        "resize" : "fit",
        "w" : 1632
      } ],
      "display_url" : "pic.twitter.com\/Ep1HbljEQB"
    } ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "meat",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621686289910394880",
  "text" : "I see this occasionally #ThisIsOU #meat http:\/\/t.co\/Ep1HbljEQB",
  "id" : 621686289910394880,
  "created_at" : "2015-07-16 14:22:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland Basketball",
      "screen_name" : "OaklandMBB",
      "indices" : [ 3, 14 ],
      "id_str" : "2860750384",
      "id" : 2860750384
    }, {
      "name" : "Keith Benson",
      "screen_name" : "RealKITO",
      "indices" : [ 25, 34 ],
      "id_str" : "149735268",
      "id" : 149735268
    }, {
      "name" : "Orlando Magic",
      "screen_name" : "OrlandoMagic",
      "indices" : [ 41, 54 ],
      "id_str" : "19537303",
      "id" : 19537303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WearTheBear",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/Le9ntXUNIe",
      "expanded_url" : "https:\/\/twitter.com\/OrlandoMagic\/status\/618850072349032448",
      "display_url" : "twitter.com\/OrlandoMagic\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621685877341818880",
  "text" : "RT @OaklandMBB: OU Great @RealKITO leads @OrlandoMagic to another win! #WearTheBear https:\/\/t.co\/Le9ntXUNIe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Keith Benson",
        "screen_name" : "RealKITO",
        "indices" : [ 9, 18 ],
        "id_str" : "149735268",
        "id" : 149735268
      }, {
        "name" : "Orlando Magic",
        "screen_name" : "OrlandoMagic",
        "indices" : [ 25, 38 ],
        "id_str" : "19537303",
        "id" : 19537303
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WearTheBear",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/Le9ntXUNIe",
        "expanded_url" : "https:\/\/twitter.com\/OrlandoMagic\/status\/618850072349032448",
        "display_url" : "twitter.com\/OrlandoMagic\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "618875579593564161",
    "text" : "OU Great @RealKITO leads @OrlandoMagic to another win! #WearTheBear https:\/\/t.co\/Le9ntXUNIe",
    "id" : 618875579593564161,
    "created_at" : "2015-07-08 20:13:30 +0000",
    "user" : {
      "name" : "Oakland Basketball",
      "screen_name" : "OaklandMBB",
      "protected" : false,
      "id_str" : "2860750384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776872248405692416\/rq-ELs-7_normal.jpg",
      "id" : 2860750384,
      "verified" : false
    }
  },
  "id" : 621685877341818880,
  "created_at" : "2015-07-16 14:20:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/621685524823150592\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/szxHTmmkRk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKCrr9hW8AA567c.jpg",
      "id_str" : "621685520314331136",
      "id" : 621685520314331136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKCrr9hW8AA567c.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 695
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 351,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/szxHTmmkRk"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/621685524823150592\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/szxHTmmkRk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CKCrsLyW8AAiTMJ.jpg",
      "id_str" : "621685524143730688",
      "id" : 621685524143730688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CKCrsLyW8AAiTMJ.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1632,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/szxHTmmkRk"
    } ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621685524823150592",
  "text" : "#OU for a day, what do you notice is wrong with the image? http:\/\/t.co\/szxHTmmkRk",
  "id" : 621685524823150592,
  "created_at" : "2015-07-16 14:19:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Connors",
      "screen_name" : "Evconn5",
      "indices" : [ 0, 8 ],
      "id_str" : "2729980120",
      "id" : 2729980120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621500620596342784",
  "geo" : { },
  "id_str" : "621501443476955140",
  "in_reply_to_user_id" : 2729980120,
  "text" : "@Evconn5 Saying Obama is a failure is way too nice, he is a failure and a loser, meaning he will never go from failure to winner. EVER!!!",
  "id" : 621501443476955140,
  "in_reply_to_status_id" : 621500620596342784,
  "created_at" : "2015-07-16 02:07:45 +0000",
  "in_reply_to_screen_name" : "Evconn5",
  "in_reply_to_user_id_str" : "2729980120",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Evan Connors",
      "screen_name" : "Evconn5",
      "indices" : [ 3, 11 ],
      "id_str" : "2729980120",
      "id" : 2729980120
    }, {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 13, 25 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 26, 42 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621501134608408576",
  "text" : "RT @Evconn5: @seanhannity @realDonaldTrump Obama is a failure",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sean Hannity",
        "screen_name" : "seanhannity",
        "indices" : [ 0, 12 ],
        "id_str" : "41634520",
        "id" : 41634520
      }, {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 13, 29 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "621500258237874176",
    "geo" : { },
    "id_str" : "621500620596342784",
    "in_reply_to_user_id" : 41634520,
    "text" : "@seanhannity @realDonaldTrump Obama is a failure",
    "id" : 621500620596342784,
    "in_reply_to_status_id" : 621500258237874176,
    "created_at" : "2015-07-16 02:04:29 +0000",
    "in_reply_to_screen_name" : "seanhannity",
    "in_reply_to_user_id_str" : "41634520",
    "user" : {
      "name" : "Evan Connors",
      "screen_name" : "Evconn5",
      "protected" : false,
      "id_str" : "2729980120",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796544222643953664\/1sUQxKFx_normal.jpg",
      "id" : 2729980120,
      "verified" : false
    }
  },
  "id" : 621501134608408576,
  "created_at" : "2015-07-16 02:06:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 0, 12 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 13, 29 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 98, 110 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "621500258237874176",
  "geo" : { },
  "id_str" : "621501092791230465",
  "in_reply_to_user_id" : 41634520,
  "text" : "@seanhannity @realDonaldTrump I agree why make a deal with people who hate our country. Thank you @BarackObama for destroying America!!!",
  "id" : 621501092791230465,
  "in_reply_to_status_id" : 621500258237874176,
  "created_at" : "2015-07-16 02:06:22 +0000",
  "in_reply_to_screen_name" : "seanhannity",
  "in_reply_to_user_id_str" : "41634520",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "indices" : [ 3, 14 ],
      "id_str" : "374209360",
      "id" : 374209360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621467244032344064",
  "text" : "RT @Bible_Time: Teach me the way of life. Fill me with the joy of your presence - Psalm 16:11",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621371729529729024",
    "text" : "Teach me the way of life. Fill me with the joy of your presence - Psalm 16:11",
    "id" : 621371729529729024,
    "created_at" : "2015-07-15 17:32:19 +0000",
    "user" : {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "protected" : false,
      "id_str" : "374209360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1551289662\/hbible_-_Copy_normal.jpg",
      "id" : 374209360,
      "verified" : false
    }
  },
  "id" : 621467244032344064,
  "created_at" : "2015-07-15 23:51:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "indices" : [ 3, 14 ],
      "id_str" : "374209360",
      "id" : 374209360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621467173421191168",
  "text" : "RT @Bible_Time: If we say that we have no sin, we are deceiving ourselves and the truth is not in us. -1 John 1:8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621445574009729028",
    "text" : "If we say that we have no sin, we are deceiving ourselves and the truth is not in us. -1 John 1:8",
    "id" : 621445574009729028,
    "created_at" : "2015-07-15 22:25:45 +0000",
    "user" : {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "protected" : false,
      "id_str" : "374209360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1551289662\/hbible_-_Copy_normal.jpg",
      "id" : 374209360,
      "verified" : false
    }
  },
  "id" : 621467173421191168,
  "created_at" : "2015-07-15 23:51:35 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "indices" : [ 3, 14 ],
      "id_str" : "374209360",
      "id" : 374209360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621467121327992832",
  "text" : "RT @Bible_Time: And my God will supply all your needs according to His riches in glory in Christ Jesus. -Philippians 4:19",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "621457914440585216",
    "text" : "And my God will supply all your needs according to His riches in glory in Christ Jesus. -Philippians 4:19",
    "id" : 621457914440585216,
    "created_at" : "2015-07-15 23:14:47 +0000",
    "user" : {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "protected" : false,
      "id_str" : "374209360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1551289662\/hbible_-_Copy_normal.jpg",
      "id" : 374209360,
      "verified" : false
    }
  },
  "id" : 621467121327992832,
  "created_at" : "2015-07-15 23:51:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WomanAgainstFeminism",
      "screen_name" : "NoToFeminism",
      "indices" : [ 0, 13 ],
      "id_str" : "2709152000",
      "id" : 2709152000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "612408710300696576",
  "geo" : { },
  "id_str" : "621466857967603712",
  "in_reply_to_user_id" : 2709152000,
  "text" : "@NoToFeminism Hah",
  "id" : 621466857967603712,
  "in_reply_to_status_id" : 612408710300696576,
  "created_at" : "2015-07-15 23:50:19 +0000",
  "in_reply_to_screen_name" : "NoToFeminism",
  "in_reply_to_user_id_str" : "2709152000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621466506753376256",
  "text" : "Seriously what is up for people playing the victim role all the time for such innocent things? Not calling out names by the way.",
  "id" : 621466506753376256,
  "created_at" : "2015-07-15 23:48:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621466186467905536",
  "text" : "Ladies I am not a stalker for tweeting at you when you haven't worked on our project for over a week. Learn to grow up and be an adult. Geez",
  "id" : 621466186467905536,
  "created_at" : "2015-07-15 23:47:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Texts I Hate",
      "screen_name" : "TextslHate",
      "indices" : [ 0, 11 ],
      "id_str" : "318948136",
      "id" : 318948136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621464590828892160",
  "in_reply_to_user_id" : 318948136,
  "text" : "@TextslHate How the hell you have 121k followers?",
  "id" : 621464590828892160,
  "created_at" : "2015-07-15 23:41:19 +0000",
  "in_reply_to_screen_name" : "TextslHate",
  "in_reply_to_user_id_str" : "318948136",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Stand4Life",
      "indices" : [ 13, 24 ]
    }, {
      "text" : "DefundPlannedParenthood",
      "indices" : [ 77, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/LErUGUiI2I",
      "expanded_url" : "https:\/\/www.tedcruz.org\/l\/defund-planned-parenthood\/",
      "display_url" : "tedcruz.org\/l\/defund-plann\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "621463550729547776",
  "text" : "RT @tedcruz: #Stand4Life and add your name if you agree it's time to finally #DefundPlannedParenthood! https:\/\/t.co\/LErUGUiI2I http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/621449695588540417\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/jUh5YXY3dn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJ_VH-uUYAAr_L5.png",
        "id_str" : "621449606673489920",
        "id" : 621449606673489920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJ_VH-uUYAAr_L5.png",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1330,
          "resize" : "fit",
          "w" : 2496
        }, {
          "h" : 181,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jUh5YXY3dn"
      } ],
      "hashtags" : [ {
        "text" : "Stand4Life",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "DefundPlannedParenthood",
        "indices" : [ 64, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/LErUGUiI2I",
        "expanded_url" : "https:\/\/www.tedcruz.org\/l\/defund-planned-parenthood\/",
        "display_url" : "tedcruz.org\/l\/defund-plann\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "621449695588540417",
    "text" : "#Stand4Life and add your name if you agree it's time to finally #DefundPlannedParenthood! https:\/\/t.co\/LErUGUiI2I http:\/\/t.co\/jUh5YXY3dn",
    "id" : 621449695588540417,
    "created_at" : "2015-07-15 22:42:08 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 621463550729547776,
  "created_at" : "2015-07-15 23:37:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621463398136594432",
  "in_reply_to_user_id" : 706013713,
  "text" : "@_jaaayme How is the class project we are working on going, as I see you haven't logged in for 8 days and aren't replying to your OU email?",
  "id" : 621463398136594432,
  "created_at" : "2015-07-15 23:36:35 +0000",
  "in_reply_to_screen_name" : "_j4yme",
  "in_reply_to_user_id_str" : "706013713",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.WindowsPhone.com\/\" rel=\"nofollow\"\u003EWindows Phone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsOU",
      "indices" : [ 63, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621350092407218176",
  "text" : "Had so much coffee but so tired, tough day, but I feel blessed #ThisIsOU",
  "id" : 621350092407218176,
  "created_at" : "2015-07-15 16:06:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 47, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619955994106404864",
  "text" : "Oh my goodness, what a tough month is has been #OU",
  "id" : 619955994106404864,
  "created_at" : "2015-07-11 19:46:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619534477241544704",
  "text" : "@JosefLokmani Calm down Josef. Geez",
  "id" : 619534477241544704,
  "created_at" : "2015-07-10 15:51:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 0, 8 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619183175617507328",
  "geo" : { },
  "id_str" : "619484825322430464",
  "in_reply_to_user_id" : 23022687,
  "text" : "@tedcruz Most likely, yes",
  "id" : 619484825322430464,
  "in_reply_to_status_id" : 619183175617507328,
  "created_at" : "2015-07-10 12:34:26 +0000",
  "in_reply_to_screen_name" : "tedcruz",
  "in_reply_to_user_id_str" : "23022687",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/YYB1zkXePi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=owUZ9E9M-VU",
      "display_url" : "youtube.com\/watch?v=owUZ9E\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "619484747232866304",
  "text" : "RT @tedcruz: RETWEET if you agree that sanctuary cities are wrong! https:\/\/t.co\/YYB1zkXePi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 77 ],
        "url" : "https:\/\/t.co\/YYB1zkXePi",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=owUZ9E9M-VU",
        "display_url" : "youtube.com\/watch?v=owUZ9E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619230878909071360",
    "text" : "RETWEET if you agree that sanctuary cities are wrong! https:\/\/t.co\/YYB1zkXePi",
    "id" : 619230878909071360,
    "created_at" : "2015-07-09 19:45:20 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 619484747232866304,
  "created_at" : "2015-07-10 12:34:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619484717453324288",
  "text" : "RT @tedcruz: Obama Admin refuses to enforce immigration laws. It doesn\u2019t make sense for fed govt to release violent criminals: https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/YYB1zkXePi",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=owUZ9E9M-VU",
        "display_url" : "youtube.com\/watch?v=owUZ9E\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "619278204897898497",
    "text" : "Obama Admin refuses to enforce immigration laws. It doesn\u2019t make sense for fed govt to release violent criminals: https:\/\/t.co\/YYB1zkXePi",
    "id" : 619278204897898497,
    "created_at" : "2015-07-09 22:53:24 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 619484717453324288,
  "created_at" : "2015-07-10 12:34:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619484415115296768",
  "text" : "@JosefLokmani Open the borders for Natives? Since when were Native Americans Mexicans?",
  "id" : 619484415115296768,
  "created_at" : "2015-07-10 12:32:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619484165784928256",
  "text" : "@JosefLokmani There is already free college for Native Americans, also did you know the first slave owner was black? Let's stop looking back",
  "id" : 619484165784928256,
  "created_at" : "2015-07-10 12:31:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619483886096109569",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Don't even bother, libs don't love to point out the fact that they caused the most destruction in today's society",
  "id" : 619483886096109569,
  "created_at" : "2015-07-10 12:30:42 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619483367873060864",
  "text" : "@JosefLokmani Do you know the Native Americans were cannibals at Christopher Colombus's times or that a conservative freed the salves?",
  "id" : 619483367873060864,
  "created_at" : "2015-07-10 12:28:39 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 20, 33 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 34, 46 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619482450922749952",
  "text" : "RT @chknfriedsteak: @JosefLokmani @gamer456148 that would be like the Swedes giving Sweden back to the Brommes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 0, 13 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      }, {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 14, 26 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619332276258648064",
    "text" : "@JosefLokmani @gamer456148 that would be like the Swedes giving Sweden back to the Brommes",
    "id" : 619332276258648064,
    "created_at" : "2015-07-10 02:28:15 +0000",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 619482450922749952,
  "created_at" : "2015-07-10 12:25:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "indices" : [ 3, 14 ],
      "id_str" : "374209360",
      "id" : 374209360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619328469483266048",
  "text" : "RT @Bible_Time: I'm a failure. He's my forgiver\nI'm a sinner. He's my savior.\nI'm broken. He's my healer.\nI'm His child. He's my God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619201302980116480",
    "text" : "I'm a failure. He's my forgiver\nI'm a sinner. He's my savior.\nI'm broken. He's my healer.\nI'm His child. He's my God.",
    "id" : 619201302980116480,
    "created_at" : "2015-07-09 17:47:49 +0000",
    "user" : {
      "name" : "Bible Time",
      "screen_name" : "Bible_Time",
      "protected" : false,
      "id_str" : "374209360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1551289662\/hbible_-_Copy_normal.jpg",
      "id" : 374209360,
      "verified" : false
    }
  },
  "id" : 619328469483266048,
  "created_at" : "2015-07-10 02:13:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "PHX CONVENTION CNTR",
      "screen_name" : "PhoenixConvCtr",
      "indices" : [ 98, 113 ],
      "id_str" : "47454323",
      "id" : 47454323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619328108378882048",
  "text" : "RT @realDonaldTrump: BREAKING - Border security rally in Phoenix, AZ at 2PM MST has been moved to @PhoenixConvCtr! Build a wall! Let's Make\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PHX CONVENTION CNTR",
        "screen_name" : "PhoenixConvCtr",
        "indices" : [ 77, 92 ],
        "id_str" : "47454323",
        "id" : 47454323
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "619323936308875264",
    "text" : "BREAKING - Border security rally in Phoenix, AZ at 2PM MST has been moved to @PhoenixConvCtr! Build a wall! Let's Make America Great Again!",
    "id" : 619323936308875264,
    "created_at" : "2015-07-10 01:55:07 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1980294624\/DJT_Headshot_V2_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 619328108378882048,
  "created_at" : "2015-07-10 02:11:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lindsay",
      "screen_name" : "ohhlindsayelyse",
      "indices" : [ 0, 16 ],
      "id_str" : "732498882622455809",
      "id" : 732498882622455809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619237560951242752",
  "geo" : { },
  "id_str" : "619327721756299264",
  "in_reply_to_user_id" : 90584114,
  "text" : "@ohhlindsayelyse prayer",
  "id" : 619327721756299264,
  "in_reply_to_status_id" : 619237560951242752,
  "created_at" : "2015-07-10 02:10:10 +0000",
  "in_reply_to_screen_name" : "gglindsayelyse",
  "in_reply_to_user_id_str" : "90584114",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2661",
      "screen_name" : "lmlosingmyself",
      "indices" : [ 0, 15 ],
      "id_str" : "1546897832",
      "id" : 1546897832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619324447938473984",
  "geo" : { },
  "id_str" : "619327426074648576",
  "in_reply_to_user_id" : 1546897832,
  "text" : "@lmlosingmyself I noticed, be strong and find a purpose",
  "id" : 619327426074648576,
  "in_reply_to_status_id" : 619324447938473984,
  "created_at" : "2015-07-10 02:08:59 +0000",
  "in_reply_to_screen_name" : "lmlosingmyself",
  "in_reply_to_user_id_str" : "1546897832",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madison Elena.",
      "screen_name" : "MadiAntonucci",
      "indices" : [ 0, 14 ],
      "id_str" : "3040563378",
      "id" : 3040563378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619318601598681088",
  "geo" : { },
  "id_str" : "619327130900537344",
  "in_reply_to_user_id" : 3040563378,
  "text" : "@MadiAntonucci Don't listen to music like that",
  "id" : 619327130900537344,
  "in_reply_to_status_id" : 619318601598681088,
  "created_at" : "2015-07-10 02:07:49 +0000",
  "in_reply_to_screen_name" : "MadiAntonucci",
  "in_reply_to_user_id_str" : "3040563378",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Suicidal guy..",
      "screen_name" : "brokensoul_12",
      "indices" : [ 0, 14 ],
      "id_str" : "1030493964",
      "id" : 1030493964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619258546992103424",
  "geo" : { },
  "id_str" : "619326795217813505",
  "in_reply_to_user_id" : 1030493964,
  "text" : "@brokensoul_12 Find God in your life, suicide is never the answer. You were on this earth for a purpose. Never lose hope. Never be a quitter",
  "id" : 619326795217813505,
  "in_reply_to_status_id" : 619258546992103424,
  "created_at" : "2015-07-10 02:06:29 +0000",
  "in_reply_to_screen_name" : "brokensoul_12",
  "in_reply_to_user_id_str" : "1030493964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abraham",
      "screen_name" : "Abzdeman20",
      "indices" : [ 14, 25 ],
      "id_str" : "280201001",
      "id" : 280201001
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619317754450079744",
  "geo" : { },
  "id_str" : "619325855584677888",
  "in_reply_to_user_id" : 326330017,
  "text" : "@rollinsordie @Abzdeman20 Don't lose hope, find God and ask what he wants for your life",
  "id" : 619325855584677888,
  "in_reply_to_status_id" : 619317754450079744,
  "created_at" : "2015-07-10 02:02:45 +0000",
  "in_reply_to_screen_name" : "brian_cals",
  "in_reply_to_user_id_str" : "326330017",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Simmons",
      "screen_name" : "BillSimmons",
      "indices" : [ 0, 12 ],
      "id_str" : "32765534",
      "id" : 32765534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619163849640390656",
  "geo" : { },
  "id_str" : "619325192410677249",
  "in_reply_to_user_id" : 32765534,
  "text" : "@BillSimmons Oh my gosh, yes",
  "id" : 619325192410677249,
  "in_reply_to_status_id" : 619163849640390656,
  "created_at" : "2015-07-10 02:00:07 +0000",
  "in_reply_to_screen_name" : "BillSimmons",
  "in_reply_to_user_id_str" : "32765534",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huntyr Duckett",
      "screen_name" : "huntyrr_duckett",
      "indices" : [ 0, 16 ],
      "id_str" : "1528003842",
      "id" : 1528003842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618621125006790656",
  "geo" : { },
  "id_str" : "619324859844284416",
  "in_reply_to_user_id" : 1528003842,
  "text" : "@huntyrr_duckett That is the a=b and a=c so b=c argument.",
  "id" : 619324859844284416,
  "in_reply_to_status_id" : 618621125006790656,
  "created_at" : "2015-07-10 01:58:47 +0000",
  "in_reply_to_screen_name" : "huntyrr_duckett",
  "in_reply_to_user_id_str" : "1528003842",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Huntyr Duckett",
      "screen_name" : "huntyrr_duckett",
      "indices" : [ 15, 31 ],
      "id_str" : "1528003842",
      "id" : 1528003842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617830221455077376",
  "geo" : { },
  "id_str" : "619324328568619008",
  "in_reply_to_user_id" : 262470090,
  "text" : "@brutalfeyonce @huntyrr_duckett That is called obsession and unhealthy relationships, a psychological problem facing today's youth",
  "id" : 619324328568619008,
  "in_reply_to_status_id" : 617830221455077376,
  "created_at" : "2015-07-10 01:56:41 +0000",
  "in_reply_to_screen_name" : "unapologetiicb",
  "in_reply_to_user_id_str" : "262470090",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 33, 46 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619246648154177536",
  "text" : "RT @chknfriedsteak: @gamer456148 @JosefLokmani we will gladly trade you Obama for Stefan L\u00F6fv\u00E9n any day Josef. ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      }, {
        "name" : "Josef Lokmani",
        "screen_name" : "JosefLokmani",
        "indices" : [ 13, 26 ],
        "id_str" : "703541068462235648",
        "id" : 703541068462235648
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "619245708839747584",
    "geo" : { },
    "id_str" : "619246419040317440",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 @JosefLokmani we will gladly trade you Obama for Stefan L\u00F6fv\u00E9n any day Josef. ;)",
    "id" : 619246419040317440,
    "in_reply_to_status_id" : 619245708839747584,
    "created_at" : "2015-07-09 20:47:05 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 619246648154177536,
  "created_at" : "2015-07-09 20:48:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 16, 29 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619245185948475392",
  "geo" : { },
  "id_str" : "619245708839747584",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak @JosefLokmani Yeah Josef doesn't know much about American politics. Josef, Obama is a liberal. US Patriots are the opposite",
  "id" : 619245708839747584,
  "in_reply_to_status_id" : 619245185948475392,
  "created_at" : "2015-07-09 20:44:16 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619245155468468226",
  "text" : "@JosefLokmani We are talking about American politics, a topic you don't understand",
  "id" : 619245155468468226,
  "created_at" : "2015-07-09 20:42:04 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 0, 13 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    }, {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 14, 29 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619237078195433472",
  "text" : "@JosefLokmani @chknfriedsteak Josef we been over this. Gosh man.",
  "id" : 619237078195433472,
  "created_at" : "2015-07-09 20:09:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GrizzHacks",
      "screen_name" : "GrizzHacks",
      "indices" : [ 0, 11 ],
      "id_str" : "3257314503",
      "id" : 3257314503
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619108842526347264",
  "in_reply_to_user_id" : 3257314503,
  "text" : "@GrizzHacks Oh my goodness yes :)",
  "id" : 619108842526347264,
  "created_at" : "2015-07-09 11:40:25 +0000",
  "in_reply_to_screen_name" : "GrizzHacks",
  "in_reply_to_user_id_str" : "3257314503",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 0, 12 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618523261987606528",
  "geo" : { },
  "id_str" : "619102029605117952",
  "in_reply_to_user_id" : 136923775,
  "text" : "@copticworld Because the youth been corrupted and broken in a lost world, living by a society's standards instead of God's standards",
  "id" : 619102029605117952,
  "in_reply_to_status_id" : 618523261987606528,
  "created_at" : "2015-07-09 11:13:20 +0000",
  "in_reply_to_screen_name" : "copticworld",
  "in_reply_to_user_id_str" : "136923775",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "indices" : [ 3, 15 ],
      "id_str" : "136923775",
      "id" : 136923775
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/copticworld\/status\/618523261987606528\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/K4YXJaDIgR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CJVvoQoWwAAt-Rj.jpg",
      "id_str" : "618523261282992128",
      "id" : 618523261282992128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJVvoQoWwAAt-Rj.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1166
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/K4YXJaDIgR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619101867243610112",
  "text" : "RT @copticworld: http:\/\/t.co\/K4YXJaDIgR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/copticworld\/status\/618523261987606528\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/K4YXJaDIgR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CJVvoQoWwAAt-Rj.jpg",
        "id_str" : "618523261282992128",
        "id" : 618523261282992128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CJVvoQoWwAAt-Rj.jpg",
        "sizes" : [ {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1166
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/K4YXJaDIgR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618523261987606528",
    "text" : "http:\/\/t.co\/K4YXJaDIgR",
    "id" : 618523261987606528,
    "created_at" : "2015-07-07 20:53:31 +0000",
    "user" : {
      "name" : "CopticWorld",
      "screen_name" : "copticworld",
      "protected" : false,
      "id_str" : "136923775",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572825081475112960\/F4a-0OOP_normal.jpeg",
      "id" : 136923775,
      "verified" : false
    }
  },
  "id" : 619101867243610112,
  "created_at" : "2015-07-09 11:12:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lar",
      "screen_name" : "laradhayni",
      "indices" : [ 13, 24 ],
      "id_str" : "150075488",
      "id" : 150075488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "619101317617860608",
  "geo" : { },
  "id_str" : "619101728261148672",
  "in_reply_to_user_id" : 210979938,
  "text" : "@dance_monii @laradhayni In a philosophical sense we are all sinners, and that's okay as long as we know we do wrong and God is in our heart",
  "id" : 619101728261148672,
  "in_reply_to_status_id" : 619101317617860608,
  "created_at" : "2015-07-09 11:12:09 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lar",
      "screen_name" : "laradhayni",
      "indices" : [ 13, 24 ],
      "id_str" : "150075488",
      "id" : 150075488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OU",
      "indices" : [ 86, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619101317617860608",
  "in_reply_to_user_id" : 360148053,
  "text" : "@dance_monii @laradhayni You aren't a terrible person, I pray for all the students at #OU to be blessed. Sorry if you took offense.",
  "id" : 619101317617860608,
  "created_at" : "2015-07-09 11:10:31 +0000",
  "in_reply_to_screen_name" : "Monica_Meirow",
  "in_reply_to_user_id_str" : "360148053",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OU Party Stories",
      "screen_name" : "oaklandUparties",
      "indices" : [ 3, 19 ],
      "id_str" : "2778528562",
      "id" : 2778528562
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619100944568045569",
  "text" : "RT @oaklandUparties: Only thing ever going up on a Tuesday at OU is tuition",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "618600248877916160",
    "text" : "Only thing ever going up on a Tuesday at OU is tuition",
    "id" : 618600248877916160,
    "created_at" : "2015-07-08 01:59:27 +0000",
    "user" : {
      "name" : "OU Party Stories",
      "screen_name" : "oaklandUparties",
      "protected" : false,
      "id_str" : "2778528562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779801648847785984\/cQjWlmXS_normal.jpg",
      "id" : 2778528562,
      "verified" : false
    }
  },
  "id" : 619100944568045569,
  "created_at" : "2015-07-09 11:09:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618988733614821376",
  "geo" : { },
  "id_str" : "619100451271778304",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak That's so awesome :)",
  "id" : 619100451271778304,
  "in_reply_to_status_id" : 618988733614821376,
  "created_at" : "2015-07-09 11:07:04 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "619100235072188416",
  "text" : "RT @chknfriedsteak: @gamer456148 I agree- common sense to know what is right. It's a shame to know that so many people follow the left out \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618939494675443713",
    "geo" : { },
    "id_str" : "618969511392219136",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I agree- common sense to know what is right. It's a shame to know that so many people follow the left out of laziness\/stupidity",
    "id" : 618969511392219136,
    "in_reply_to_status_id" : 618939494675443713,
    "created_at" : "2015-07-09 02:26:46 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 619100235072188416,
  "created_at" : "2015-07-09 11:06:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618907547139870721",
  "geo" : { },
  "id_str" : "618939494675443713",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Thanks, but I call it common sense, not courage :)",
  "id" : 618939494675443713,
  "in_reply_to_status_id" : 618907547139870721,
  "created_at" : "2015-07-09 00:27:29 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 20, 32 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618939399443759104",
  "text" : "RT @chknfriedsteak: @gamer456148 I am one of the majority here in Texas. I commend your courage fellow Patriot!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618904614797086720",
    "geo" : { },
    "id_str" : "618907547139870721",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 I am one of the majority here in Texas. I commend your courage fellow Patriot!!",
    "id" : 618907547139870721,
    "in_reply_to_status_id" : 618904614797086720,
    "created_at" : "2015-07-08 22:20:32 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 618939399443759104,
  "created_at" : "2015-07-09 00:27:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618899503685304320",
  "geo" : { },
  "id_str" : "618904614797086720",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Awesome, are you a conservative as well? I am a tea party member and a NRA member.",
  "id" : 618904614797086720,
  "in_reply_to_status_id" : 618899503685304320,
  "created_at" : "2015-07-08 22:08:53 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "enchilada.",
      "screen_name" : "HelloRyanHolmes",
      "indices" : [ 0, 16 ],
      "id_str" : "32809159",
      "id" : 32809159
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618670423186784256",
  "geo" : { },
  "id_str" : "618889324575076352",
  "in_reply_to_user_id" : 32809159,
  "text" : "@HelloRyanHolmes Mine always tells me to please don't wake up :&gt;)",
  "id" : 618889324575076352,
  "in_reply_to_status_id" : 618670423186784256,
  "created_at" : "2015-07-08 21:08:08 +0000",
  "in_reply_to_screen_name" : "HelloRyanHolmes",
  "in_reply_to_user_id_str" : "32809159",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "saved",
      "screen_name" : "hemmingstape",
      "indices" : [ 0, 13 ],
      "id_str" : "3431517477",
      "id" : 3431517477
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "618884423262441472",
  "geo" : { },
  "id_str" : "618888435546193920",
  "in_reply_to_user_id" : 742303004,
  "text" : "@hemmingstape No God creating this universe and becoming our savior is the best thing that ever happened in this world",
  "id" : 618888435546193920,
  "in_reply_to_status_id" : 618884423262441472,
  "created_at" : "2015-07-08 21:04:36 +0000",
  "in_reply_to_screen_name" : "jackbumult",
  "in_reply_to_user_id_str" : "742303004",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "617836643483914240",
  "geo" : { },
  "id_str" : "618887935081865218",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak Haha, you must be southern",
  "id" : 618887935081865218,
  "in_reply_to_status_id" : 617836643483914240,
  "created_at" : "2015-07-08 21:02:36 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oakland University",
      "screen_name" : "oaklandu",
      "indices" : [ 88, 97 ],
      "id_str" : "17468189",
      "id" : 17468189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618887490791813121",
  "text" : "Martina and Ahmed, you guys know who you are, thanks for welcoming me with open arms to @OaklandU",
  "id" : 618887490791813121,
  "created_at" : "2015-07-08 21:00:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josef Lokmani",
      "screen_name" : "JosefLokmani",
      "indices" : [ 19, 32 ],
      "id_str" : "703541068462235648",
      "id" : 703541068462235648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618883000869060609",
  "text" : "Pray for my friend @JosefLokmani that God protects him and keeps him safe. Let God enlighten his spirit and pray he finds love in his heart.",
  "id" : 618883000869060609,
  "created_at" : "2015-07-08 20:43:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/544059719002763264\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/8Uzvxmc1yh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B4zjbixCYAAVKvr.jpg",
      "id_str" : "544059717333442560",
      "id" : 544059717333442560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4zjbixCYAAVKvr.jpg",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 551
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8Uzvxmc1yh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618494017391562752",
  "text" : "RT @BestGamezUp: http:\/\/t.co\/8Uzvxmc1yh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BestGamezUp\/status\/544059719002763264\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/8Uzvxmc1yh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B4zjbixCYAAVKvr.jpg",
        "id_str" : "544059717333442560",
        "id" : 544059717333442560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B4zjbixCYAAVKvr.jpg",
        "sizes" : [ {
          "h" : 325,
          "resize" : "fit",
          "w" : 551
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 551
        }, {
          "h" : 325,
          "resize" : "fit",
          "w" : 551
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8Uzvxmc1yh"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "544059719002763264",
    "text" : "http:\/\/t.co\/8Uzvxmc1yh",
    "id" : 544059719002763264,
    "created_at" : "2014-12-14 09:21:59 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 618494017391562752,
  "created_at" : "2015-07-07 18:57:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 0, 7 ],
      "id_str" : "24206345",
      "id" : 24206345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 45 ],
      "url" : "https:\/\/t.co\/0H3qHFh7Vj",
      "expanded_url" : "https:\/\/goo.gl\/Clnsxw",
      "display_url" : "goo.gl\/Clnsxw"
    } ]
  },
  "in_reply_to_status_id_str" : "618481820204703744",
  "geo" : { },
  "id_str" : "618493140316454912",
  "in_reply_to_user_id" : 24206345,
  "text" : "@Quirky So my idea at https:\/\/t.co\/0H3qHFh7Vj should be going to Eval next week. Okay thanks for letting me know &amp; trying to get this solved",
  "id" : 618493140316454912,
  "in_reply_to_status_id" : 618481820204703744,
  "created_at" : "2015-07-07 18:53:50 +0000",
  "in_reply_to_screen_name" : "Quirky",
  "in_reply_to_user_id_str" : "24206345",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 3, 10 ],
      "id_str" : "24206345",
      "id" : 24206345
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 12, 24 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618492923219304448",
  "text" : "RT @Quirky: @gamer456148 So sorry about that, that must be frustrating,  but we did check on this, and were told to expect it at next Eval.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618480343595659264",
    "geo" : { },
    "id_str" : "618481820204703744",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 So sorry about that, that must be frustrating,  but we did check on this, and were told to expect it at next Eval.",
    "id" : 618481820204703744,
    "in_reply_to_status_id" : 618480343595659264,
    "created_at" : "2015-07-07 18:08:51 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "protected" : false,
      "id_str" : "24206345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608766608975089664\/TQrXgrZT_normal.png",
      "id" : 24206345,
      "verified" : true
    }
  },
  "id" : 618492923219304448,
  "created_at" : "2015-07-07 18:52:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "indices" : [ 3, 10 ],
      "id_str" : "24206345",
      "id" : 24206345
    }, {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 12, 24 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "618478593673461760",
  "text" : "RT @Quirky: @gamer456148 Best of luck! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Andrew Kamal",
        "screen_name" : "gamer456148",
        "indices" : [ 0, 12 ],
        "id_str" : "210979938",
        "id" : 210979938
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "618431090953326592",
    "geo" : { },
    "id_str" : "618432461022887936",
    "in_reply_to_user_id" : 210979938,
    "text" : "@gamer456148 Best of luck! :)",
    "id" : 618432461022887936,
    "in_reply_to_status_id" : 618431090953326592,
    "created_at" : "2015-07-07 14:52:43 +0000",
    "in_reply_to_screen_name" : "gamer456148",
    "in_reply_to_user_id_str" : "210979938",
    "user" : {
      "name" : "Quirky",
      "screen_name" : "Quirky",
      "protected" : false,
      "id_str" : "24206345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608766608975089664\/TQrXgrZT_normal.png",
      "id" : 24206345,
      "verified" : true
    }
  },
  "id" : 618478593673461760,
  "created_at" : "2015-07-07 17:56:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 0, 15 ],
      "id_str" : "332579081",
      "id" : 332579081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616678136621744128",
  "geo" : { },
  "id_str" : "617799134737756160",
  "in_reply_to_user_id" : 332579081,
  "text" : "@chknfriedsteak I have deep pockets :)",
  "id" : 617799134737756160,
  "in_reply_to_status_id" : 616678136621744128,
  "created_at" : "2015-07-05 20:56:06 +0000",
  "in_reply_to_screen_name" : "chknfriedsteak",
  "in_reply_to_user_id_str" : "332579081",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Kamal",
      "screen_name" : "gamer456148",
      "indices" : [ 0, 12 ],
      "id_str" : "210979938",
      "id" : 210979938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fail",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "616673436010721284",
  "geo" : { },
  "id_str" : "616673844812742656",
  "in_reply_to_user_id" : 210979938,
  "text" : "@gamer456148 In places like Florida I heard you can buy a 5 linsense, don't know if that's still true, man the laws have changed #Fail",
  "id" : 616673844812742656,
  "in_reply_to_status_id" : 616673436010721284,
  "created_at" : "2015-07-02 18:24:36 +0000",
  "in_reply_to_screen_name" : "gamer456148",
  "in_reply_to_user_id_str" : "210979938",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616673436010721284",
  "text" : "Seriously you need to renew a hunting license in Michigan every year. The 4 or 5 year old hunting linsense which I lost is no good now :(",
  "id" : 616673436010721284,
  "created_at" : "2015-07-02 18:22:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]