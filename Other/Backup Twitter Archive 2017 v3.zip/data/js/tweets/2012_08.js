Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/3aweJJTo",
      "expanded_url" : "http:\/\/youtu.be\/2zneniIt1vI?a",
      "display_url" : "youtu.be\/2zneniIt1vI?a"
    } ]
  },
  "geo" : { },
  "id_str" : "235819261602435072",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/3aweJJTo Mental Math Secrets (Math Tricks) - Ep1 - Rapidly",
  "id" : 235819261602435072,
  "created_at" : "2012-08-15 19:24:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/sndSAYIl",
      "expanded_url" : "http:\/\/youtu.be\/2N6CgUwsiCE?a",
      "display_url" : "youtu.be\/2N6CgUwsiCE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "235797980861587458",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/sndSAYIl Listen to Increase IQ",
  "id" : 235797980861587458,
  "created_at" : "2012-08-15 17:59:54 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 21, 29 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/sndSAYIl",
      "expanded_url" : "http:\/\/youtu.be\/2N6CgUwsiCE?a",
      "display_url" : "youtu.be\/2N6CgUwsiCE?a"
    } ]
  },
  "geo" : { },
  "id_str" : "235796693302530049",
  "text" : "I added a video to a @YouTube playlist http:\/\/t.co\/sndSAYIl Listen to Increase IQ",
  "id" : 235796693302530049,
  "created_at" : "2012-08-15 17:54:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/VBE5pJqA",
      "expanded_url" : "http:\/\/lnkd.in\/GgZbCk",
      "display_url" : "lnkd.in\/GgZbCk"
    } ]
  },
  "geo" : { },
  "id_str" : "235523046134411264",
  "text" : "Binaural Beats, Increase Your Intelligence - Brainwave Entrainment http:\/\/t.co\/VBE5pJqA",
  "id" : 235523046134411264,
  "created_at" : "2012-08-14 23:47:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/6Q4l8rZY",
      "expanded_url" : "http:\/\/youtu.be\/HolLBSR5r9s?a",
      "display_url" : "youtu.be\/HolLBSR5r9s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "230824108043169792",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/6Q4l8rZY Stop Motion Animation Effect 2.0",
  "id" : 230824108043169792,
  "created_at" : "2012-08-02 00:35:30 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 13, 21 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/9aZcQDbv",
      "expanded_url" : "http:\/\/youtu.be\/95Ko4pxA1M4?a",
      "display_url" : "youtu.be\/95Ko4pxA1M4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "230757579901505536",
  "text" : "I uploaded a @YouTube video http:\/\/t.co\/9aZcQDbv DSI Stop Motion Animation Effect",
  "id" : 230757579901505536,
  "created_at" : "2012-08-01 20:11:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 10, 18 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/9aZcQDbv",
      "expanded_url" : "http:\/\/youtu.be\/95Ko4pxA1M4?a",
      "display_url" : "youtu.be\/95Ko4pxA1M4?a"
    } ]
  },
  "geo" : { },
  "id_str" : "230757463677341696",
  "text" : "I liked a @YouTube video http:\/\/t.co\/9aZcQDbv DSI Stop Motion Animation Effect",
  "id" : 230757463677341696,
  "created_at" : "2012-08-01 20:10:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/dQsU55uq",
      "expanded_url" : "http:\/\/dwln.info\/fp2xsv",
      "display_url" : "dwln.info\/fp2xsv"
    } ]
  },
  "geo" : { },
  "id_str" : "230743675787935744",
  "text" : "GET MORE FOLLOWERS MY BEST FRIENDS? I WILL FOLLOW YOU BACK IF YOU FOLLOW ME -  http:\/\/t.co\/dQsU55uq",
  "id" : 230743675787935744,
  "created_at" : "2012-08-01 19:15:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/stat.set\" rel=\"nofollow\"\u003ESTATUSEM\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teenagers!",
      "screen_name" : "Comedypedia",
      "indices" : [ 49, 61 ],
      "id_str" : "568804399",
      "id" : 568804399
    }, {
      "name" : "Hardwell Fans",
      "screen_name" : "HardwellFans9",
      "indices" : [ 62, 76 ],
      "id_str" : "615686213",
      "id" : 615686213
    }, {
      "name" : "Gabriela",
      "screen_name" : "gabyenriqueza",
      "indices" : [ 77, 91 ],
      "id_str" : "163224264",
      "id" : 163224264
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/2ZIqQNiQ",
      "expanded_url" : "http:\/\/tinyurl.com\/cpgbq9u",
      "display_url" : "tinyurl.com\/cpgbq9u"
    } ]
  },
  "geo" : { },
  "id_str" : "230721313642262528",
  "text" : "MORE FOLLOWERS MY FRIENDS \u279C http:\/\/t.co\/2ZIqQNiQ @COMEDYPEDIA @HardwellFans9 @gabyenriqueza",
  "id" : 230721313642262528,
  "created_at" : "2012-08-01 17:47:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]