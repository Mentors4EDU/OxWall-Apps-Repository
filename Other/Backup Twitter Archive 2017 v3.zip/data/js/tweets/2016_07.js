Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2600\uFE0FNICK~ITU\u2600\uFE0F",
      "screen_name" : "nicoleitumba",
      "indices" : [ 3, 16 ],
      "id_str" : "1029757238",
      "id" : 1029757238
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridaynight",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "759270540456624128",
  "text" : "RT @nicoleitumba: Nothing different just a little headache today  #fridaynight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fridaynight",
        "indices" : [ 48, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "759265515902799872",
    "text" : "Nothing different just a little headache today  #fridaynight",
    "id" : 759265515902799872,
    "created_at" : "2016-07-30 05:53:00 +0000",
    "user" : {
      "name" : "\u2600\uFE0FNICK~ITU\u2600\uFE0F",
      "screen_name" : "nicoleitumba",
      "protected" : false,
      "id_str" : "1029757238",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780646248592318464\/yGdkVc1i_normal.jpg",
      "id" : 1029757238,
      "verified" : false
    }
  },
  "id" : 759270540456624128,
  "created_at" : "2016-07-30 06:12:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    }, {
      "name" : "Baileigh Industrial",
      "screen_name" : "BaileighInc",
      "indices" : [ 39, 51 ],
      "id_str" : "84145287",
      "id" : 84145287
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/758300167229571072\/photo\/1",
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/vbq6wP7H75",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYF8zMXEAQjBGh.jpg",
      "id_str" : "758300129350848516",
      "id" : 758300129350848516,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYF8zMXEAQjBGh.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/vbq6wP7H75"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758957889868267521",
  "text" : "RT @colin_furze: Got a new toy. Cheers @BaileighInc https:\/\/t.co\/vbq6wP7H75",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Baileigh Industrial",
        "screen_name" : "BaileighInc",
        "indices" : [ 22, 34 ],
        "id_str" : "84145287",
        "id" : 84145287
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/758300167229571072\/photo\/1",
        "indices" : [ 35, 58 ],
        "url" : "https:\/\/t.co\/vbq6wP7H75",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYF8zMXEAQjBGh.jpg",
        "id_str" : "758300129350848516",
        "id" : 758300129350848516,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYF8zMXEAQjBGh.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/vbq6wP7H75"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758300167229571072",
    "text" : "Got a new toy. Cheers @BaileighInc https:\/\/t.co\/vbq6wP7H75",
    "id" : 758300167229571072,
    "created_at" : "2016-07-27 13:57:03 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 758957889868267521,
  "created_at" : "2016-07-29 09:30:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "indices" : [ 3, 15 ],
      "id_str" : "321610630",
      "id" : 321610630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/758913570784489472\/photo\/1",
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/fq8DDLhbvB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CogzytHVYAAK83o.jpg",
      "id_str" : "758913483408760832",
      "id" : 758913483408760832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogzytHVYAAK83o.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/fq8DDLhbvB"
    } ],
    "hashtags" : [ {
      "text" : "fursday",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/jU23pF6uD3",
      "expanded_url" : "https:\/\/youtu.be\/N0wfkpBImKw",
      "display_url" : "youtu.be\/N0wfkpBImKw"
    } ]
  },
  "geo" : { },
  "id_str" : "758957835002580994",
  "text" : "RT @colin_furze: A HUGE swing.....say no more.  https:\/\/t.co\/jU23pF6uD3 #fursday https:\/\/t.co\/fq8DDLhbvB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/colin_furze\/status\/758913570784489472\/photo\/1",
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/fq8DDLhbvB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CogzytHVYAAK83o.jpg",
        "id_str" : "758913483408760832",
        "id" : 758913483408760832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogzytHVYAAK83o.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/fq8DDLhbvB"
      } ],
      "hashtags" : [ {
        "text" : "fursday",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/jU23pF6uD3",
        "expanded_url" : "https:\/\/youtu.be\/N0wfkpBImKw",
        "display_url" : "youtu.be\/N0wfkpBImKw"
      } ]
    },
    "geo" : { },
    "id_str" : "758913570784489472",
    "text" : "A HUGE swing.....say no more.  https:\/\/t.co\/jU23pF6uD3 #fursday https:\/\/t.co\/fq8DDLhbvB",
    "id" : 758913570784489472,
    "created_at" : "2016-07-29 06:34:29 +0000",
    "user" : {
      "name" : "colin furze",
      "screen_name" : "colin_furze",
      "protected" : false,
      "id_str" : "321610630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1819394769\/image_normal.jpg",
      "id" : 321610630,
      "verified" : true
    }
  },
  "id" : 758957835002580994,
  "created_at" : "2016-07-29 09:30:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758956250205818880",
  "text" : "RT @Matthiasiam: Currently in Pre-Labor! Hoping Active-Labor starts later today! We're so excited! Pray for Amanda and Luna!\u2764\uFE0F\u2764\uFE0F\u2764\uFE0F @heyaman\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Faye",
        "screen_name" : "heyamandafaye",
        "indices" : [ 114, 128 ],
        "id_str" : "120666850",
        "id" : 120666850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757606072001572864",
    "text" : "Currently in Pre-Labor! Hoping Active-Labor starts later today! We're so excited! Pray for Amanda and Luna!\u2764\uFE0F\u2764\uFE0F\u2764\uFE0F @heyamandafaye",
    "id" : 757606072001572864,
    "created_at" : "2016-07-25 15:58:57 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 758956250205818880,
  "created_at" : "2016-07-29 09:24:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 0, 12 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758956222921834496\/photo\/1",
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/MtH96XpVRA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CohahrnUMAESqYp.jpg",
      "id_str" : "758956071901736961",
      "id" : 758956071901736961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CohahrnUMAESqYp.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 849
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 849
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 849
      } ],
      "display_url" : "pic.twitter.com\/MtH96XpVRA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758956222921834496",
  "in_reply_to_user_id" : 44184316,
  "text" : "@Matthiasiam That moment you ask what you are doing with your life, lol https:\/\/t.co\/MtH96XpVRA",
  "id" : 758956222921834496,
  "created_at" : "2016-07-29 09:23:58 +0000",
  "in_reply_to_screen_name" : "Matthiasiam",
  "in_reply_to_user_id_str" : "44184316",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 3, 9 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/verge\/status\/758633152390782976\/photo\/1",
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/OU0NU0Jy9t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coc01J_XEAA47qJ.jpg",
      "id_str" : "758633150054600704",
      "id" : 758633150054600704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coc01J_XEAA47qJ.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/OU0NU0Jy9t"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/FdOlgwpk7P",
      "expanded_url" : "http:\/\/www.theverge.com\/circuitbreaker\/2016\/7\/28\/12290420\/blu-r1-hd-amazon-ads-smartphone-review?utm_campaign=theverge&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/circuitbreaker\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758875468590264320",
  "text" : "RT @verge: Blu and Amazon have redefined the budget smartphone https:\/\/t.co\/FdOlgwpk7P https:\/\/t.co\/OU0NU0Jy9t",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/verge\/status\/758633152390782976\/photo\/1",
        "indices" : [ 76, 99 ],
        "url" : "https:\/\/t.co\/OU0NU0Jy9t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coc01J_XEAA47qJ.jpg",
        "id_str" : "758633150054600704",
        "id" : 758633150054600704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coc01J_XEAA47qJ.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/OU0NU0Jy9t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/FdOlgwpk7P",
        "expanded_url" : "http:\/\/www.theverge.com\/circuitbreaker\/2016\/7\/28\/12290420\/blu-r1-hd-amazon-ads-smartphone-review?utm_campaign=theverge&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "theverge.com\/circuitbreaker\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758837196946219008",
    "text" : "Blu and Amazon have redefined the budget smartphone https:\/\/t.co\/FdOlgwpk7P https:\/\/t.co\/OU0NU0Jy9t",
    "id" : 758837196946219008,
    "created_at" : "2016-07-29 01:31:00 +0000",
    "user" : {
      "name" : "The Verge",
      "screen_name" : "verge",
      "protected" : false,
      "id_str" : "275686563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793336456718782464\/cf1nuXC0_normal.jpg",
      "id" : 275686563,
      "verified" : true
    }
  },
  "id" : 758875468590264320,
  "created_at" : "2016-07-29 04:03:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Verge",
      "screen_name" : "verge",
      "indices" : [ 3, 9 ],
      "id_str" : "275686563",
      "id" : 275686563
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/verge\/status\/758648252078194688\/photo\/1",
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/RNGgRTaJYM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CodCkA_WAAAslDO.jpg",
      "id_str" : "758648248743624704",
      "id" : 758648248743624704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CodCkA_WAAAslDO.jpg",
      "sizes" : [ {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/RNGgRTaJYM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/L8Ljk3aghq",
      "expanded_url" : "http:\/\/www.theverge.com\/2016\/7\/28\/12295786\/hyperloop-transportation-deutsche-bahn-europe-railway-2017?utm_campaign=theverge&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "theverge.com\/2016\/7\/28\/1229\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758875417033912321",
  "text" : "RT @verge: The Hyperloop is bringing some of its futuristic tech to Europe\u2019s biggest railway https:\/\/t.co\/L8Ljk3aghq https:\/\/t.co\/RNGgRTaJYM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/verge\/status\/758648252078194688\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/RNGgRTaJYM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CodCkA_WAAAslDO.jpg",
        "id_str" : "758648248743624704",
        "id" : 758648248743624704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CodCkA_WAAAslDO.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/RNGgRTaJYM"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/L8Ljk3aghq",
        "expanded_url" : "http:\/\/www.theverge.com\/2016\/7\/28\/12295786\/hyperloop-transportation-deutsche-bahn-europe-railway-2017?utm_campaign=theverge&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "theverge.com\/2016\/7\/28\/1229\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758850282809757696",
    "text" : "The Hyperloop is bringing some of its futuristic tech to Europe\u2019s biggest railway https:\/\/t.co\/L8Ljk3aghq https:\/\/t.co\/RNGgRTaJYM",
    "id" : 758850282809757696,
    "created_at" : "2016-07-29 02:23:00 +0000",
    "user" : {
      "name" : "The Verge",
      "screen_name" : "verge",
      "protected" : false,
      "id_str" : "275686563",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793336456718782464\/cf1nuXC0_normal.jpg",
      "id" : 275686563,
      "verified" : true
    }
  },
  "id" : 758875417033912321,
  "created_at" : "2016-07-29 04:02:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "indices" : [ 3, 9 ],
      "id_str" : "1344951",
      "id" : 1344951
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/758874876551634944\/photo\/1",
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/WjSdAMVajs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CogQrPUVYAAvQlp.jpg",
      "id_str" : "758874872244166656",
      "id" : 758874872244166656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogQrPUVYAAvQlp.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/WjSdAMVajs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/0FuMlBN7sn",
      "expanded_url" : "http:\/\/bit.ly\/2aBcOLM",
      "display_url" : "bit.ly\/2aBcOLM"
    } ]
  },
  "geo" : { },
  "id_str" : "758875236087410688",
  "text" : "RT @WIRED: This bridge is unlike most bridges you've seen: https:\/\/t.co\/0FuMlBN7sn https:\/\/t.co\/WjSdAMVajs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WIRED\/status\/758874876551634944\/photo\/1",
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/WjSdAMVajs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CogQrPUVYAAvQlp.jpg",
        "id_str" : "758874872244166656",
        "id" : 758874872244166656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogQrPUVYAAvQlp.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/WjSdAMVajs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/0FuMlBN7sn",
        "expanded_url" : "http:\/\/bit.ly\/2aBcOLM",
        "display_url" : "bit.ly\/2aBcOLM"
      } ]
    },
    "geo" : { },
    "id_str" : "758874876551634944",
    "text" : "This bridge is unlike most bridges you've seen: https:\/\/t.co\/0FuMlBN7sn https:\/\/t.co\/WjSdAMVajs",
    "id" : 758874876551634944,
    "created_at" : "2016-07-29 04:00:44 +0000",
    "user" : {
      "name" : "WIRED",
      "screen_name" : "WIRED",
      "protected" : false,
      "id_str" : "1344951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615598832726970372\/jsK-gBSt_normal.png",
      "id" : 1344951,
      "verified" : true
    }
  },
  "id" : 758875236087410688,
  "created_at" : "2016-07-29 04:02:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758823134459891713\/photo\/1",
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/5C5gTjIfBb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cofhnc9UMAAKKeC.jpg",
      "id_str" : "758823130139734016",
      "id" : 758823130139734016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cofhnc9UMAAKKeC.jpg",
      "sizes" : [ {
        "h" : 454,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 970
      } ],
      "display_url" : "pic.twitter.com\/5C5gTjIfBb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/te7QehQ8Nu",
      "expanded_url" : "http:\/\/gizmo.do\/fL1SX8j",
      "display_url" : "gizmo.do\/fL1SX8j"
    } ]
  },
  "geo" : { },
  "id_str" : "758875152750776320",
  "text" : "RT @Gizmodo: The year's best astronomy photos will take you to another dimension https:\/\/t.co\/te7QehQ8Nu https:\/\/t.co\/5C5gTjIfBb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758823134459891713\/photo\/1",
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/5C5gTjIfBb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cofhnc9UMAAKKeC.jpg",
        "id_str" : "758823130139734016",
        "id" : 758823130139734016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cofhnc9UMAAKKeC.jpg",
        "sizes" : [ {
          "h" : 454,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 970
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 970
        } ],
        "display_url" : "pic.twitter.com\/5C5gTjIfBb"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/te7QehQ8Nu",
        "expanded_url" : "http:\/\/gizmo.do\/fL1SX8j",
        "display_url" : "gizmo.do\/fL1SX8j"
      } ]
    },
    "geo" : { },
    "id_str" : "758823134459891713",
    "text" : "The year's best astronomy photos will take you to another dimension https:\/\/t.co\/te7QehQ8Nu https:\/\/t.co\/5C5gTjIfBb",
    "id" : 758823134459891713,
    "created_at" : "2016-07-29 00:35:08 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590508740010348544\/eS1F7mN5_normal.png",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 758875152750776320,
  "created_at" : "2016-07-29 04:01:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758830417352941568\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/BnIiE6cWFf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CofoPaFUkAApI80.jpg",
      "id_str" : "758830413632540672",
      "id" : 758830413632540672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CofoPaFUkAApI80.jpg",
      "sizes" : [ {
        "h" : 595,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 595,
        "resize" : "fit",
        "w" : 1066
      }, {
        "h" : 380,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/BnIiE6cWFf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/ytMHSqEk2V",
      "expanded_url" : "http:\/\/gizmo.do\/GuCrPr9",
      "display_url" : "gizmo.do\/GuCrPr9"
    } ]
  },
  "geo" : { },
  "id_str" : "758875111503966209",
  "text" : "RT @Gizmodo: Still time to catch the Delta Aquarids meteor shower tonight. Here's how https:\/\/t.co\/ytMHSqEk2V https:\/\/t.co\/BnIiE6cWFf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758830417352941568\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/BnIiE6cWFf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CofoPaFUkAApI80.jpg",
        "id_str" : "758830413632540672",
        "id" : 758830413632540672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CofoPaFUkAApI80.jpg",
        "sizes" : [ {
          "h" : 595,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 595,
          "resize" : "fit",
          "w" : 1066
        }, {
          "h" : 380,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/BnIiE6cWFf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/ytMHSqEk2V",
        "expanded_url" : "http:\/\/gizmo.do\/GuCrPr9",
        "display_url" : "gizmo.do\/GuCrPr9"
      } ]
    },
    "geo" : { },
    "id_str" : "758830417352941568",
    "text" : "Still time to catch the Delta Aquarids meteor shower tonight. Here's how https:\/\/t.co\/ytMHSqEk2V https:\/\/t.co\/BnIiE6cWFf",
    "id" : 758830417352941568,
    "created_at" : "2016-07-29 01:04:04 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590508740010348544\/eS1F7mN5_normal.png",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 758875111503966209,
  "created_at" : "2016-07-29 04:01:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "indices" : [ 3, 11 ],
      "id_str" : "2890961",
      "id" : 2890961
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758857597310992384\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/4ufVKzjzNl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CogA9jJVYAAYpzB.jpg",
      "id_str" : "758857594618339328",
      "id" : 758857594618339328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogA9jJVYAAYpzB.jpg",
      "sizes" : [ {
        "h" : 298,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 350,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/4ufVKzjzNl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/7JrItmmAgH",
      "expanded_url" : "http:\/\/gizmo.do\/SSba93H",
      "display_url" : "gizmo.do\/SSba93H"
    } ]
  },
  "geo" : { },
  "id_str" : "758875033221472260",
  "text" : "RT @Gizmodo: Lately, science has been having a lot of fun with hydrogels https:\/\/t.co\/7JrItmmAgH https:\/\/t.co\/4ufVKzjzNl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gizmodo\/status\/758857597310992384\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/4ufVKzjzNl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CogA9jJVYAAYpzB.jpg",
        "id_str" : "758857594618339328",
        "id" : 758857594618339328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogA9jJVYAAYpzB.jpg",
        "sizes" : [ {
          "h" : 298,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/4ufVKzjzNl"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/7JrItmmAgH",
        "expanded_url" : "http:\/\/gizmo.do\/SSba93H",
        "display_url" : "gizmo.do\/SSba93H"
      } ]
    },
    "geo" : { },
    "id_str" : "758857597310992384",
    "text" : "Lately, science has been having a lot of fun with hydrogels https:\/\/t.co\/7JrItmmAgH https:\/\/t.co\/4ufVKzjzNl",
    "id" : 758857597310992384,
    "created_at" : "2016-07-29 02:52:04 +0000",
    "user" : {
      "name" : "Gizmodo",
      "screen_name" : "Gizmodo",
      "protected" : false,
      "id_str" : "2890961",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590508740010348544\/eS1F7mN5_normal.png",
      "id" : 2890961,
      "verified" : true
    }
  },
  "id" : 758875033221472260,
  "created_at" : "2016-07-29 04:01:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/kSZWqPyRHX",
      "expanded_url" : "http:\/\/tcrn.ch\/2aqhnI4",
      "display_url" : "tcrn.ch\/2aqhnI4"
    } ]
  },
  "geo" : { },
  "id_str" : "758874886748053506",
  "text" : "RT @TechCrunch: Uber cofounder launches new real estate venture for Expa called Haus https:\/\/t.co\/kSZWqPyRHX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/kSZWqPyRHX",
        "expanded_url" : "http:\/\/tcrn.ch\/2aqhnI4",
        "display_url" : "tcrn.ch\/2aqhnI4"
      } ]
    },
    "geo" : { },
    "id_str" : "758858338809421824",
    "text" : "Uber cofounder launches new real estate venture for Expa called Haus https:\/\/t.co\/kSZWqPyRHX",
    "id" : 758858338809421824,
    "created_at" : "2016-07-29 02:55:01 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615392662233808896\/EtxjSSKk_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 758874886748053506,
  "created_at" : "2016-07-29 04:00:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/uFaKWYzMck",
      "expanded_url" : "http:\/\/tcrn.ch\/2aksBwV",
      "display_url" : "tcrn.ch\/2aksBwV"
    } ]
  },
  "geo" : { },
  "id_str" : "758874849263493120",
  "text" : "RT @TechCrunch: The Ticwatch, originally built for Chinese language users, will be available in English https:\/\/t.co\/uFaKWYzMck  https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/uFaKWYzMck",
        "expanded_url" : "http:\/\/tcrn.ch\/2aksBwV",
        "display_url" : "tcrn.ch\/2aksBwV"
      }, {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/yO7NJk23Bk",
        "expanded_url" : "http:\/\/snpy.tv\/2arseBk",
        "display_url" : "snpy.tv\/2arseBk"
      } ]
    },
    "geo" : { },
    "id_str" : "758863390232027138",
    "text" : "The Ticwatch, originally built for Chinese language users, will be available in English https:\/\/t.co\/uFaKWYzMck  https:\/\/t.co\/yO7NJk23Bk",
    "id" : 758863390232027138,
    "created_at" : "2016-07-29 03:15:05 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615392662233808896\/EtxjSSKk_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 758874849263493120,
  "created_at" : "2016-07-29 04:00:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758862940359360512\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/E4p1ljjj6v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CogF0k4VYAAfeqh.jpg",
      "id_str" : "758862938023223296",
      "id" : 758862938023223296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogF0k4VYAAfeqh.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/E4p1ljjj6v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/DGqWepnenr",
      "expanded_url" : "http:\/\/engt.co\/2afnkUX",
      "display_url" : "engt.co\/2afnkUX"
    } ]
  },
  "geo" : { },
  "id_str" : "758874704165806080",
  "text" : "RT @engadget: Kickstarter created over 300,000 jobs, study says https:\/\/t.co\/DGqWepnenr https:\/\/t.co\/E4p1ljjj6v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758862940359360512\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/E4p1ljjj6v",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CogF0k4VYAAfeqh.jpg",
        "id_str" : "758862938023223296",
        "id" : 758862938023223296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogF0k4VYAAfeqh.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/E4p1ljjj6v"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/DGqWepnenr",
        "expanded_url" : "http:\/\/engt.co\/2afnkUX",
        "display_url" : "engt.co\/2afnkUX"
      } ]
    },
    "geo" : { },
    "id_str" : "758862940359360512",
    "text" : "Kickstarter created over 300,000 jobs, study says https:\/\/t.co\/DGqWepnenr https:\/\/t.co\/E4p1ljjj6v",
    "id" : 758862940359360512,
    "created_at" : "2016-07-29 03:13:18 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758874704165806080,
  "created_at" : "2016-07-29 04:00:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "it's Emily\u262F",
      "screen_name" : "OhMyDemiJonas",
      "indices" : [ 0, 14 ],
      "id_str" : "280806043",
      "id" : 280806043
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758874482517741569\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/VnLOPYOyeA",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CogQTGAUIAAjO-D.jpg",
      "id_str" : "758874457427419136",
      "id" : 758874457427419136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CogQTGAUIAAjO-D.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/VnLOPYOyeA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758867548695728128",
  "geo" : { },
  "id_str" : "758874482517741569",
  "in_reply_to_user_id" : 280806043,
  "text" : "@OhMyDemiJonas Define a mess https:\/\/t.co\/VnLOPYOyeA",
  "id" : 758874482517741569,
  "in_reply_to_status_id" : 758867548695728128,
  "created_at" : "2016-07-29 03:59:10 +0000",
  "in_reply_to_screen_name" : "OhMyDemiJonas",
  "in_reply_to_user_id_str" : "280806043",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kimberly Corban",
      "screen_name" : "Kimberly_Corban",
      "indices" : [ 3, 19 ],
      "id_str" : "477064682",
      "id" : 477064682
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Kimberly_Corban\/status\/758742066033680386\/video\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/U2EM4Of2br",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758735596344909827\/pu\/img\/6LrNPkwrhzCvB5Rq.jpg",
      "id_str" : "758735596344909827",
      "id" : 758735596344909827,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758735596344909827\/pu\/img\/6LrNPkwrhzCvB5Rq.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/U2EM4Of2br"
    } ],
    "hashtags" : [ {
      "text" : "IAmAFeminist",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758873878135386112",
  "text" : "RT @Kimberly_Corban: #IAmAFeminist because I support equality. Our right to self-defense levels the playing field. https:\/\/t.co\/U2EM4Of2br",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Kimberly_Corban\/status\/758742066033680386\/video\/1",
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/U2EM4Of2br",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758735596344909827\/pu\/img\/6LrNPkwrhzCvB5Rq.jpg",
        "id_str" : "758735596344909827",
        "id" : 758735596344909827,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758735596344909827\/pu\/img\/6LrNPkwrhzCvB5Rq.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/U2EM4Of2br"
      } ],
      "hashtags" : [ {
        "text" : "IAmAFeminist",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758742066033680386",
    "text" : "#IAmAFeminist because I support equality. Our right to self-defense levels the playing field. https:\/\/t.co\/U2EM4Of2br",
    "id" : 758742066033680386,
    "created_at" : "2016-07-28 19:12:59 +0000",
    "user" : {
      "name" : "Kimberly Corban",
      "screen_name" : "Kimberly_Corban",
      "protected" : false,
      "id_str" : "477064682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752489997404516352\/YJh_zVeT_normal.jpg",
      "id" : 477064682,
      "verified" : true
    }
  },
  "id" : 758873878135386112,
  "created_at" : "2016-07-29 03:56:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/758869746729095168\/video\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/y3NWrWuSpe",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758869660062199810\/pu\/img\/LT8ynHUkh0Ue77bV.jpg",
      "id_str" : "758869660062199810",
      "id" : 758869660062199810,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758869660062199810\/pu\/img\/LT8ynHUkh0Ue77bV.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/y3NWrWuSpe"
    } ],
    "hashtags" : [ {
      "text" : "IAmAFeminist",
      "indices" : [ 14, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/LbxYdAnbqy",
      "expanded_url" : "http:\/\/youtube.com\/watch?v=aWJT0egzAy0",
      "display_url" : "youtube.com\/watch?v=aWJT0e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758873422067675136",
  "text" : "RT @scrowder: #IAmAFeminist because... wait... no. No, I'm not. Because this &gt;&gt; https:\/\/t.co\/LbxYdAnbqy https:\/\/t.co\/y3NWrWuSpe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/epoxy.tv\" rel=\"nofollow\"\u003EEpoxyTV\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/scrowder\/status\/758869746729095168\/video\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/y3NWrWuSpe",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758869660062199810\/pu\/img\/LT8ynHUkh0Ue77bV.jpg",
        "id_str" : "758869660062199810",
        "id" : 758869660062199810,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/758869660062199810\/pu\/img\/LT8ynHUkh0Ue77bV.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/y3NWrWuSpe"
      } ],
      "hashtags" : [ {
        "text" : "IAmAFeminist",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/LbxYdAnbqy",
        "expanded_url" : "http:\/\/youtube.com\/watch?v=aWJT0egzAy0",
        "display_url" : "youtube.com\/watch?v=aWJT0e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758869746729095168",
    "text" : "#IAmAFeminist because... wait... no. No, I'm not. Because this &gt;&gt; https:\/\/t.co\/LbxYdAnbqy https:\/\/t.co\/y3NWrWuSpe",
    "id" : 758869746729095168,
    "created_at" : "2016-07-29 03:40:21 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 758873422067675136,
  "created_at" : "2016-07-29 03:54:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "*  MissCharityKeller",
      "screen_name" : "chairbeardotcom",
      "indices" : [ 3, 19 ],
      "id_str" : "518149464",
      "id" : 518149464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758873216219688964",
  "text" : "RT @chairbeardotcom: Honk honk, beep beep, get out of my way!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758869933610590210",
    "text" : "Honk honk, beep beep, get out of my way!",
    "id" : 758869933610590210,
    "created_at" : "2016-07-29 03:41:05 +0000",
    "user" : {
      "name" : "*  MissCharityKeller",
      "screen_name" : "chairbeardotcom",
      "protected" : false,
      "id_str" : "518149464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836091369944989696\/01oQ0cPL_normal.jpg",
      "id" : 518149464,
      "verified" : false
    }
  },
  "id" : 758873216219688964,
  "created_at" : "2016-07-29 03:54:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe America",
      "screen_name" : "jdraina",
      "indices" : [ 3, 11 ],
      "id_str" : "1948566475",
      "id" : 1948566475
    }, {
      "name" : "Jack",
      "screen_name" : "risetoflyy",
      "indices" : [ 13, 24 ],
      "id_str" : "54065567",
      "id" : 54065567
    }, {
      "name" : "Conservative Belle",
      "screen_name" : "BelleForTrump",
      "indices" : [ 25, 39 ],
      "id_str" : "1259574180",
      "id" : 1259574180
    }, {
      "name" : "Fox News",
      "screen_name" : "FoxNews",
      "indices" : [ 40, 48 ],
      "id_str" : "1367531",
      "id" : 1367531
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758872459068133376",
  "text" : "RT @jdraina: @risetoflyy @BelleForTrump @FoxNews Ivanka's speech much better. Ran circles around Chelsea.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jack",
        "screen_name" : "risetoflyy",
        "indices" : [ 0, 11 ],
        "id_str" : "54065567",
        "id" : 54065567
      }, {
        "name" : "Conservative Belle",
        "screen_name" : "BelleForTrump",
        "indices" : [ 12, 26 ],
        "id_str" : "1259574180",
        "id" : 1259574180
      }, {
        "name" : "Fox News",
        "screen_name" : "FoxNews",
        "indices" : [ 27, 35 ],
        "id_str" : "1367531",
        "id" : 1367531
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "758849515088519169",
    "geo" : { },
    "id_str" : "758863322838020096",
    "in_reply_to_user_id" : 54065567,
    "text" : "@risetoflyy @BelleForTrump @FoxNews Ivanka's speech much better. Ran circles around Chelsea.",
    "id" : 758863322838020096,
    "in_reply_to_status_id" : 758849515088519169,
    "created_at" : "2016-07-29 03:14:49 +0000",
    "in_reply_to_screen_name" : "risetoflyy",
    "in_reply_to_user_id_str" : "54065567",
    "user" : {
      "name" : "Joe America",
      "screen_name" : "jdraina",
      "protected" : false,
      "id_str" : "1948566475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000570219292\/ea8765df51a2703f9aa30fd78b28e901_normal.jpeg",
      "id" : 1948566475,
      "verified" : false
    }
  },
  "id" : 758872459068133376,
  "created_at" : "2016-07-29 03:51:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 19, 28 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758872362204876801",
  "text" : "RT @StaceyMichals: @USATODAY no comparison. ivanka talked about her dad the non-politician. chelsea put us to sleep trying to make her poli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA TODAY",
        "screen_name" : "USATODAY",
        "indices" : [ 0, 9 ],
        "id_str" : "15754281",
        "id" : 15754281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "758864522035671040",
    "geo" : { },
    "id_str" : "758864848931295232",
    "in_reply_to_user_id" : 15754281,
    "text" : "@USATODAY no comparison. ivanka talked about her dad the non-politician. chelsea put us to sleep trying to make her politician into a mom.",
    "id" : 758864848931295232,
    "in_reply_to_status_id" : 758864522035671040,
    "created_at" : "2016-07-29 03:20:53 +0000",
    "in_reply_to_screen_name" : "USATODAY",
    "in_reply_to_user_id_str" : "15754281",
    "user" : {
      "name" : "Bless your hearts!",
      "screen_name" : "mama_says_so_",
      "protected" : false,
      "id_str" : "33985228",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826629982365421569\/nnuBTyYh_normal.jpg",
      "id" : 33985228,
      "verified" : false
    }
  },
  "id" : 758872362204876801,
  "created_at" : "2016-07-29 03:50:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 0, 16 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758872155769573376\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/zK6LnevbR3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CogOMQwVYAEfpMw.jpg",
      "id_str" : "758872141030842369",
      "id" : 758872141030842369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CogOMQwVYAEfpMw.jpg",
      "sizes" : [ {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      }, {
        "h" : 410,
        "resize" : "fit",
        "w" : 619
      } ],
      "display_url" : "pic.twitter.com\/zK6LnevbR3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758872155769573376",
  "in_reply_to_user_id" : 25073877,
  "text" : "@realDonaldTrump A picture is worth a thousand words https:\/\/t.co\/zK6LnevbR3",
  "id" : 758872155769573376,
  "created_at" : "2016-07-29 03:49:55 +0000",
  "in_reply_to_screen_name" : "realDonaldTrump",
  "in_reply_to_user_id_str" : "25073877",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Izzysandy\u269B \u00AF\\_(\u30C4)_\/\u00AF",
      "screen_name" : "Izzy_Sandy",
      "indices" : [ 0, 11 ],
      "id_str" : "435444484",
      "id" : 435444484
    }, {
      "name" : "Trevor Donovan",
      "screen_name" : "TrevDon",
      "indices" : [ 12, 20 ],
      "id_str" : "54387487",
      "id" : 54387487
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758869798356783105",
  "geo" : { },
  "id_str" : "758871150482960385",
  "in_reply_to_user_id" : 435444484,
  "text" : "@Izzy_Sandy @TrevDon We on the same page cause chocolate is awesome!!!",
  "id" : 758871150482960385,
  "in_reply_to_status_id" : 758869798356783105,
  "created_at" : "2016-07-29 03:45:56 +0000",
  "in_reply_to_screen_name" : "Izzy_Sandy",
  "in_reply_to_user_id_str" : "435444484",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Little",
      "screen_name" : "SoCalEricLittle",
      "indices" : [ 3, 19 ],
      "id_str" : "2697584791",
      "id" : 2697584791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IveWaitedAllMyLife",
      "indices" : [ 21, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758870936925810690",
  "text" : "RT @SoCalEricLittle: #IveWaitedAllMyLife on hold. Ok that is a lie.  Maybe 60-80 hours of my life.  Feels like a lifetime though.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IveWaitedAllMyLife",
        "indices" : [ 0, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758869913914085376",
    "text" : "#IveWaitedAllMyLife on hold. Ok that is a lie.  Maybe 60-80 hours of my life.  Feels like a lifetime though.",
    "id" : 758869913914085376,
    "created_at" : "2016-07-29 03:41:01 +0000",
    "user" : {
      "name" : "Eric Little",
      "screen_name" : "SoCalEricLittle",
      "protected" : false,
      "id_str" : "2697584791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/589635671574220801\/hrsYQo8m_normal.jpg",
      "id" : 2697584791,
      "verified" : false
    }
  },
  "id" : 758870936925810690,
  "created_at" : "2016-07-29 03:45:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "alyssa hailey\uD83E\uDD18\uD83C\uDFFC",
      "screen_name" : "alyssahailey99",
      "indices" : [ 0, 15 ],
      "id_str" : "3380083288",
      "id" : 3380083288
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758869806586077185\/photo\/1",
      "indices" : [ 41, 64 ],
      "url" : "https:\/\/t.co\/JewbZjYSxI",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CogMBRnUMAAsji9.jpg",
      "id_str" : "758869753259634688",
      "id" : 758869753259634688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CogMBRnUMAAsji9.jpg",
      "sizes" : [ {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/JewbZjYSxI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758848125796691973",
  "geo" : { },
  "id_str" : "758869806586077185",
  "in_reply_to_user_id" : 3380083288,
  "text" : "@alyssahailey99 No this looks like trash https:\/\/t.co\/JewbZjYSxI",
  "id" : 758869806586077185,
  "in_reply_to_status_id" : 758848125796691973,
  "created_at" : "2016-07-29 03:40:35 +0000",
  "in_reply_to_screen_name" : "alyssahailey99",
  "in_reply_to_user_id_str" : "3380083288",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "indices" : [ 3, 17 ],
      "id_str" : "34356320",
      "id" : 34356320
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758867256629534720",
  "text" : "RT @jorgevictoria: Sometimes what you're most afraid of doing is the very thing that will set you free.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758848335339851776",
    "text" : "Sometimes what you're most afraid of doing is the very thing that will set you free.",
    "id" : 758848335339851776,
    "created_at" : "2016-07-29 02:15:16 +0000",
    "user" : {
      "name" : "Jorge Victoria",
      "screen_name" : "jorgevictoria",
      "protected" : false,
      "id_str" : "34356320",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/844229219991281665\/7Z-TyL_-_normal.jpg",
      "id" : 34356320,
      "verified" : false
    }
  },
  "id" : 758867256629534720,
  "created_at" : "2016-07-29 03:30:27 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758866853976379392\/photo\/1",
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/PoFqOVNokS",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CogJXJSUEAIBXKR.jpg",
      "id_str" : "758866830446301186",
      "id" : 758866830446301186,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CogJXJSUEAIBXKR.jpg",
      "sizes" : [ {
        "h" : 141,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PoFqOVNokS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758866853976379392",
  "text" : "Did Hillary just promise more taxes, please no!!! https:\/\/t.co\/PoFqOVNokS",
  "id" : 758866853976379392,
  "created_at" : "2016-07-29 03:28:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758514705967132672",
  "text" : "RT @elonmusk: Should mention that Gigafactory will be fully powered by clean energy when complete &amp; include battery recycling",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758351232356397056",
    "text" : "Should mention that Gigafactory will be fully powered by clean energy when complete &amp; include battery recycling",
    "id" : 758351232356397056,
    "created_at" : "2016-07-27 17:19:57 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 758514705967132672,
  "created_at" : "2016-07-28 04:09:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Branson",
      "screen_name" : "richardbranson",
      "indices" : [ 3, 18 ],
      "id_str" : "8161232",
      "id" : 8161232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lW7DK0EoMy",
      "expanded_url" : "http:\/\/virg.in\/vrx",
      "display_url" : "virg.in\/vrx"
    } ]
  },
  "geo" : { },
  "id_str" : "758514637520285696",
  "text" : "RT @richardbranson: My most treasured moment? Every single one with my family (oh, &amp; the time I beat Djokovic!) https:\/\/t.co\/lW7DK0EoMy htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/richardbranson\/status\/758377768157491200\/photo\/1",
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/U5EtpciigE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZMjv1XgAQvhEL.jpg",
        "id_str" : "758377764277944324",
        "id" : 758377764277944324,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZMjv1XgAQvhEL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 510
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/U5EtpciigE"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/lW7DK0EoMy",
        "expanded_url" : "http:\/\/virg.in\/vrx",
        "display_url" : "virg.in\/vrx"
      } ]
    },
    "geo" : { },
    "id_str" : "758377768157491200",
    "text" : "My most treasured moment? Every single one with my family (oh, &amp; the time I beat Djokovic!) https:\/\/t.co\/lW7DK0EoMy https:\/\/t.co\/U5EtpciigE",
    "id" : 758377768157491200,
    "created_at" : "2016-07-27 19:05:24 +0000",
    "user" : {
      "name" : "Richard Branson",
      "screen_name" : "richardbranson",
      "protected" : false,
      "id_str" : "8161232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817027637466005505\/IwRu9byQ_normal.jpg",
      "id" : 8161232,
      "verified" : true
    }
  },
  "id" : 758514637520285696,
  "created_at" : "2016-07-28 04:09:16 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GOP",
      "screen_name" : "GOP",
      "indices" : [ 3, 7 ],
      "id_str" : "11134252",
      "id" : 11134252
    }, {
      "name" : "Joe Biden",
      "screen_name" : "JoeBiden",
      "indices" : [ 19, 28 ],
      "id_str" : "939091",
      "id" : 939091
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/758469170224914432\/photo\/1",
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/d8zCn35sjE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoafsBwUAAAMwGu.jpg",
      "id_str" : "758469165992640512",
      "id" : 758469165992640512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoafsBwUAAAMwGu.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/d8zCn35sjE"
    } ],
    "hashtags" : [ {
      "text" : "DemsInPhilly",
      "indices" : [ 30, 43 ]
    }, {
      "text" : "EnoughClinton",
      "indices" : [ 44, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758514531878318080",
  "text" : "RT @GOP: We agree, @JoeBiden. #DemsInPhilly #EnoughClinton https:\/\/t.co\/d8zCn35sjE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joe Biden",
        "screen_name" : "JoeBiden",
        "indices" : [ 10, 19 ],
        "id_str" : "939091",
        "id" : 939091
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GOP\/status\/758469170224914432\/photo\/1",
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/d8zCn35sjE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoafsBwUAAAMwGu.jpg",
        "id_str" : "758469165992640512",
        "id" : 758469165992640512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoafsBwUAAAMwGu.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/d8zCn35sjE"
      } ],
      "hashtags" : [ {
        "text" : "DemsInPhilly",
        "indices" : [ 21, 34 ]
      }, {
        "text" : "EnoughClinton",
        "indices" : [ 35, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758469170224914432",
    "text" : "We agree, @JoeBiden. #DemsInPhilly #EnoughClinton https:\/\/t.co\/d8zCn35sjE",
    "id" : 758469170224914432,
    "created_at" : "2016-07-28 01:08:36 +0000",
    "user" : {
      "name" : "GOP",
      "screen_name" : "GOP",
      "protected" : false,
      "id_str" : "11134252",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843068737272119296\/DNuuPIbk_normal.jpg",
      "id" : 11134252,
      "verified" : true
    }
  },
  "id" : 758514531878318080,
  "created_at" : "2016-07-28 04:08:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 3, 12 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RandPaul\/status\/758374337049202688\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/JfsmShnjNI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZJbucWIAAOneb.jpg",
      "id_str" : "758374327930724352",
      "id" : 758374327930724352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZJbucWIAAOneb.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JfsmShnjNI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758514294623313921",
  "text" : "RT @RandPaul: Amazing turnout in Lexington, Kentucky for stop 4 of the day! https:\/\/t.co\/JfsmShnjNI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RandPaul\/status\/758374337049202688\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/JfsmShnjNI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZJbucWIAAOneb.jpg",
        "id_str" : "758374327930724352",
        "id" : 758374327930724352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZJbucWIAAOneb.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JfsmShnjNI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758374337049202688",
    "text" : "Amazing turnout in Lexington, Kentucky for stop 4 of the day! https:\/\/t.co\/JfsmShnjNI",
    "id" : 758374337049202688,
    "created_at" : "2016-07-27 18:51:46 +0000",
    "user" : {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "protected" : false,
      "id_str" : "216881337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681152691461042177\/_PrgDgFA_normal.jpg",
      "id" : 216881337,
      "verified" : true
    }
  },
  "id" : 758514294623313921,
  "created_at" : "2016-07-28 04:07:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allison Joy Ball",
      "screen_name" : "AllisonJoyBall",
      "indices" : [ 3, 18 ],
      "id_str" : "709481136",
      "id" : 709481136
    }, {
      "name" : "Senator Rand Paul",
      "screen_name" : "RandPaul",
      "indices" : [ 65, 74 ],
      "id_str" : "216881337",
      "id" : 216881337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandWithRand",
      "indices" : [ 29, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758514262885093376",
  "text" : "RT @AllisonJoyBall: Proud to #StandWithRand in Eastern Kentucky! @RandPaul will defend coal &amp; Eastern KY interests. Send him back to DC! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Rand Paul",
        "screen_name" : "RandPaul",
        "indices" : [ 45, 54 ],
        "id_str" : "216881337",
        "id" : 216881337
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AllisonJoyBall\/status\/758094656781611008\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/2ocZ9ucTkH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoVLDGlWAAAAfSL.jpg",
        "id_str" : "758094628960731136",
        "id" : 758094628960731136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoVLDGlWAAAAfSL.jpg",
        "sizes" : [ {
          "h" : 1966,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1966,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 653,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1152,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/2ocZ9ucTkH"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/AllisonJoyBall\/status\/758094656781611008\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/2ocZ9ucTkH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoVLDb-WgAAdANa.jpg",
        "id_str" : "758094634702766080",
        "id" : 758094634702766080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoVLDb-WgAAdANa.jpg",
        "sizes" : [ {
          "h" : 1936,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 643,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1134,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/2ocZ9ucTkH"
      } ],
      "hashtags" : [ {
        "text" : "StandWithRand",
        "indices" : [ 9, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758094656781611008",
    "text" : "Proud to #StandWithRand in Eastern Kentucky! @RandPaul will defend coal &amp; Eastern KY interests. Send him back to DC! https:\/\/t.co\/2ocZ9ucTkH",
    "id" : 758094656781611008,
    "created_at" : "2016-07-27 00:20:25 +0000",
    "user" : {
      "name" : "Allison Joy Ball",
      "screen_name" : "AllisonJoyBall",
      "protected" : false,
      "id_str" : "709481136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561363200944656384\/Hlox7JPS_normal.jpeg",
      "id" : 709481136,
      "verified" : false
    }
  },
  "id" : 758514262885093376,
  "created_at" : "2016-07-28 04:07:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    }, {
      "name" : "David Wohl",
      "screen_name" : "DavidWohl",
      "indices" : [ 22, 32 ],
      "id_str" : "23359769",
      "id" : 23359769
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 58, 74 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATO",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758514096027250688",
  "text" : "RT @realDonaldTrump: \"@DavidWohl: Barack is offended that @realDonaldTrump will demand that #NATO allies pay their fair share. #DemsInPhill\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Wohl",
        "screen_name" : "DavidWohl",
        "indices" : [ 1, 11 ],
        "id_str" : "23359769",
        "id" : 23359769
      }, {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 37, 53 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NATO",
        "indices" : [ 71, 76 ]
      }, {
        "text" : "DemsInPhilly",
        "indices" : [ 106, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758511494669664256",
    "text" : "\"@DavidWohl: Barack is offended that @realDonaldTrump will demand that #NATO allies pay their fair share. #DemsInPhilly\"",
    "id" : 758511494669664256,
    "created_at" : "2016-07-28 03:56:47 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1980294624\/DJT_Headshot_V2_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 758514096027250688,
  "created_at" : "2016-07-28 04:07:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758513753121890304",
  "text" : "RT @lorenridinger: \"Just because Fate doesn't deal you the right cards, it doesn't mean you should give up.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757455532097667072",
    "text" : "\"Just because Fate doesn't deal you the right cards, it doesn't mean you should give up.\"",
    "id" : 757455532097667072,
    "created_at" : "2016-07-25 06:00:46 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 758513753121890304,
  "created_at" : "2016-07-28 04:05:45 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DarkWolf80s",
      "screen_name" : "DarkWolf80s",
      "indices" : [ 3, 15 ],
      "id_str" : "143176546",
      "id" : 143176546
    }, {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 17, 26 ],
      "id_str" : "14372486",
      "id" : 14372486
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 44, 50 ],
      "id_str" : "19380829",
      "id" : 19380829
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758513620988813312",
  "text" : "RT @DarkWolf80s: @engadget the problem with @Yahoo it needs proper guidance to learn a thing about Google. If possible, a better YouTube al\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Engadget",
        "screen_name" : "engadget",
        "indices" : [ 0, 9 ],
        "id_str" : "14372486",
        "id" : 14372486
      }, {
        "name" : "Yahoo",
        "screen_name" : "Yahoo",
        "indices" : [ 27, 33 ],
        "id_str" : "19380829",
        "id" : 19380829
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "757543167768072192",
    "geo" : { },
    "id_str" : "757595029741432833",
    "in_reply_to_user_id" : 14372486,
    "text" : "@engadget the problem with @Yahoo it needs proper guidance to learn a thing about Google. If possible, a better YouTube alternative. \uD83C\uDF77\uD83E\uDD18\uD83C\uDFFD",
    "id" : 757595029741432833,
    "in_reply_to_status_id" : 757543167768072192,
    "created_at" : "2016-07-25 15:15:05 +0000",
    "in_reply_to_screen_name" : "engadget",
    "in_reply_to_user_id_str" : "14372486",
    "user" : {
      "name" : "DarkWolf80s",
      "screen_name" : "DarkWolf80s",
      "protected" : false,
      "id_str" : "143176546",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821336410762444801\/ewEUuzES_normal.jpg",
      "id" : 143176546,
      "verified" : false
    }
  },
  "id" : 758513620988813312,
  "created_at" : "2016-07-28 04:05:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757561883268354048\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/BtogXrdFUu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoNmhB-W8AA0LuR.jpg",
      "id_str" : "757561879980077056",
      "id" : 757561879980077056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoNmhB-W8AA0LuR.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/BtogXrdFUu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0spiLBATR1",
      "expanded_url" : "http:\/\/engt.co\/2a0noI0",
      "display_url" : "engt.co\/2a0noI0"
    } ]
  },
  "geo" : { },
  "id_str" : "758513492768854016",
  "text" : "RT @engadget: Windows 10's Anniversary Update makes a great OS better https:\/\/t.co\/0spiLBATR1 https:\/\/t.co\/BtogXrdFUu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757561883268354048\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/BtogXrdFUu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoNmhB-W8AA0LuR.jpg",
        "id_str" : "757561879980077056",
        "id" : 757561879980077056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoNmhB-W8AA0LuR.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/BtogXrdFUu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/0spiLBATR1",
        "expanded_url" : "http:\/\/engt.co\/2a0noI0",
        "display_url" : "engt.co\/2a0noI0"
      } ]
    },
    "geo" : { },
    "id_str" : "757561883268354048",
    "text" : "Windows 10's Anniversary Update makes a great OS better https:\/\/t.co\/0spiLBATR1 https:\/\/t.co\/BtogXrdFUu",
    "id" : 757561883268354048,
    "created_at" : "2016-07-25 13:03:22 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758513492768854016,
  "created_at" : "2016-07-28 04:04:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757576016558784512\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/fm0PtiP4Rf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoNzXsKWYAAdIRx.jpg",
      "id_str" : "757576013157130240",
      "id" : 757576013157130240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoNzXsKWYAAdIRx.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/fm0PtiP4Rf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/MIIsr5BsOh",
      "expanded_url" : "http:\/\/engt.co\/2adOFKk",
      "display_url" : "engt.co\/2adOFKk"
    } ]
  },
  "geo" : { },
  "id_str" : "758513384446767105",
  "text" : "RT @engadget: Scientists map human brain in more detail than ever before https:\/\/t.co\/MIIsr5BsOh https:\/\/t.co\/fm0PtiP4Rf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757576016558784512\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/fm0PtiP4Rf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoNzXsKWYAAdIRx.jpg",
        "id_str" : "757576013157130240",
        "id" : 757576013157130240,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoNzXsKWYAAdIRx.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/fm0PtiP4Rf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/MIIsr5BsOh",
        "expanded_url" : "http:\/\/engt.co\/2adOFKk",
        "display_url" : "engt.co\/2adOFKk"
      } ]
    },
    "geo" : { },
    "id_str" : "757576016558784512",
    "text" : "Scientists map human brain in more detail than ever before https:\/\/t.co\/MIIsr5BsOh https:\/\/t.co\/fm0PtiP4Rf",
    "id" : 757576016558784512,
    "created_at" : "2016-07-25 13:59:32 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758513384446767105,
  "created_at" : "2016-07-28 04:04:18 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "indices" : [ 3, 18 ],
      "id_str" : "2687742392",
      "id" : 2687742392
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 41, 49 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 82 ],
      "url" : "https:\/\/t.co\/4iFCxfGIfo",
      "expanded_url" : "http:\/\/youtu.be\/-NTK_2Ydv7s?a",
      "display_url" : "youtu.be\/-NTK_2Ydv7s?a"
    } ]
  },
  "geo" : { },
  "id_str" : "758513086420574209",
  "text" : "RT @VigilantChrist: I added a video to a @YouTube playlist https:\/\/t.co\/4iFCxfGIfo Read The Entire Bible in 1 Year with The Vigilant Christ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 21, 29 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 62 ],
        "url" : "https:\/\/t.co\/4iFCxfGIfo",
        "expanded_url" : "http:\/\/youtu.be\/-NTK_2Ydv7s?a",
        "display_url" : "youtu.be\/-NTK_2Ydv7s?a"
      } ]
    },
    "geo" : { },
    "id_str" : "758492021036347392",
    "text" : "I added a video to a @YouTube playlist https:\/\/t.co\/4iFCxfGIfo Read The Entire Bible in 1 Year with The Vigilant Christian Mario",
    "id" : 758492021036347392,
    "created_at" : "2016-07-28 02:39:24 +0000",
    "user" : {
      "name" : "Mario Brisson",
      "screen_name" : "VigilantChrist",
      "protected" : false,
      "id_str" : "2687742392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/553390783626096641\/uiTTTCSG_normal.jpeg",
      "id" : 2687742392,
      "verified" : false
    }
  },
  "id" : 758513086420574209,
  "created_at" : "2016-07-28 04:03:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758437093727170560\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/3XCBxgX0eL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaCg8qWcAU4uTn.jpg",
      "id_str" : "758437089809690629",
      "id" : 758437089809690629,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaCg8qWcAU4uTn.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/3XCBxgX0eL"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/SDK0285GMr",
      "expanded_url" : "http:\/\/engt.co\/2aaPGiT",
      "display_url" : "engt.co\/2aaPGiT"
    } ]
  },
  "geo" : { },
  "id_str" : "758513043051454464",
  "text" : "RT @engadget: MIT's ridesharing network is learning to dodge pedestrians https:\/\/t.co\/SDK0285GMr https:\/\/t.co\/3XCBxgX0eL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758437093727170560\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/3XCBxgX0eL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaCg8qWcAU4uTn.jpg",
        "id_str" : "758437089809690629",
        "id" : 758437089809690629,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaCg8qWcAU4uTn.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/3XCBxgX0eL"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/SDK0285GMr",
        "expanded_url" : "http:\/\/engt.co\/2aaPGiT",
        "display_url" : "engt.co\/2aaPGiT"
      } ]
    },
    "geo" : { },
    "id_str" : "758437093727170560",
    "text" : "MIT's ridesharing network is learning to dodge pedestrians https:\/\/t.co\/SDK0285GMr https:\/\/t.co\/3XCBxgX0eL",
    "id" : 758437093727170560,
    "created_at" : "2016-07-27 23:01:08 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758513043051454464,
  "created_at" : "2016-07-28 04:02:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "indices" : [ 3, 18 ],
      "id_str" : "332579081",
      "id" : 332579081
    }, {
      "name" : "Michael Berry",
      "screen_name" : "MichaelBerrySho",
      "indices" : [ 34, 50 ],
      "id_str" : "35818542",
      "id" : 35818542
    }, {
      "name" : "Ramon Robles Jr",
      "screen_name" : "RamonRoblesJr",
      "indices" : [ 52, 66 ],
      "id_str" : "339005714",
      "id" : 339005714
    }, {
      "name" : "Ken Webster Jr",
      "screen_name" : "ProducerKen",
      "indices" : [ 67, 79 ],
      "id_str" : "297765074",
      "id" : 297765074
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chknfriedsteak\/status\/758446380608126976\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/UQkPEuuI0e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaK9SvUAAA1pEU.jpg",
      "id_str" : "758446372865441792",
      "id" : 758446372865441792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaK9SvUAAA1pEU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/UQkPEuuI0e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758512911320911874",
  "text" : "RT @chknfriedsteak: Hear her roar @MichaelBerrySho \n@RamonRoblesJr @ProducerKen https:\/\/t.co\/UQkPEuuI0e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Berry",
        "screen_name" : "MichaelBerrySho",
        "indices" : [ 14, 30 ],
        "id_str" : "35818542",
        "id" : 35818542
      }, {
        "name" : "Ramon Robles Jr",
        "screen_name" : "RamonRoblesJr",
        "indices" : [ 32, 46 ],
        "id_str" : "339005714",
        "id" : 339005714
      }, {
        "name" : "Ken Webster Jr",
        "screen_name" : "ProducerKen",
        "indices" : [ 47, 59 ],
        "id_str" : "297765074",
        "id" : 297765074
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chknfriedsteak\/status\/758446380608126976\/photo\/1",
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/UQkPEuuI0e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaK9SvUAAA1pEU.jpg",
        "id_str" : "758446372865441792",
        "id" : 758446372865441792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaK9SvUAAA1pEU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/UQkPEuuI0e"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758446380608126976",
    "text" : "Hear her roar @MichaelBerrySho \n@RamonRoblesJr @ProducerKen https:\/\/t.co\/UQkPEuuI0e",
    "id" : 758446380608126976,
    "created_at" : "2016-07-27 23:38:03 +0000",
    "user" : {
      "name" : "james m. taylor",
      "screen_name" : "chknfriedsteak",
      "protected" : false,
      "id_str" : "332579081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832258233993682946\/4MfhW3aB_normal.jpg",
      "id" : 332579081,
      "verified" : false
    }
  },
  "id" : 758512911320911874,
  "created_at" : "2016-07-28 04:02:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758497575372742656\/photo\/1",
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/I1ocQqH4yN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coa5heOWYAUALHp.jpg",
      "id_str" : "758497571958579205",
      "id" : 758497571958579205,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coa5heOWYAUALHp.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/I1ocQqH4yN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/RaIkvhzgpZ",
      "expanded_url" : "http:\/\/engt.co\/2aLuZed",
      "display_url" : "engt.co\/2aLuZed"
    } ]
  },
  "geo" : { },
  "id_str" : "758512518507565056",
  "text" : "RT @engadget: Xiaomi's first laptop is the $750 Mi Notebook Air https:\/\/t.co\/RaIkvhzgpZ https:\/\/t.co\/I1ocQqH4yN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758497575372742656\/photo\/1",
        "indices" : [ 74, 97 ],
        "url" : "https:\/\/t.co\/I1ocQqH4yN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coa5heOWYAUALHp.jpg",
        "id_str" : "758497571958579205",
        "id" : 758497571958579205,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coa5heOWYAUALHp.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/I1ocQqH4yN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/RaIkvhzgpZ",
        "expanded_url" : "http:\/\/engt.co\/2aLuZed",
        "display_url" : "engt.co\/2aLuZed"
      } ]
    },
    "geo" : { },
    "id_str" : "758497575372742656",
    "text" : "Xiaomi's first laptop is the $750 Mi Notebook Air https:\/\/t.co\/RaIkvhzgpZ https:\/\/t.co\/I1ocQqH4yN",
    "id" : 758497575372742656,
    "created_at" : "2016-07-28 03:01:28 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758512518507565056,
  "created_at" : "2016-07-28 04:00:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DemsInPhilly",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758512404581888000",
  "text" : "RT @hannahbleau_: Tim Kaine tried a folksy approach and sprinkled it with his mad Spanish skillz. I'm still cringing #DemsInPhilly",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemsInPhilly",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758491612636860416",
    "text" : "Tim Kaine tried a folksy approach and sprinkled it with his mad Spanish skillz. I'm still cringing #DemsInPhilly",
    "id" : 758491612636860416,
    "created_at" : "2016-07-28 02:37:47 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 758512404581888000,
  "created_at" : "2016-07-28 04:00:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Projects We Love",
      "screen_name" : "kickstarterbot",
      "indices" : [ 3, 18 ],
      "id_str" : "2411526686",
      "id" : 2411526686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/9jhSwD74Fo",
      "expanded_url" : "http:\/\/kck.st\/2axoiQs",
      "display_url" : "kck.st\/2axoiQs"
    } ]
  },
  "geo" : { },
  "id_str" : "758512285031686145",
  "text" : "RT @kickstarterbot: \u201CFireside Audiobox - Light your music on fire. by Grey Street Design\u201D \u263A https:\/\/t.co\/9jhSwD74Fo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.kickstarter.com\/discover\" rel=\"nofollow\"\u003Eksr_staff\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/9jhSwD74Fo",
        "expanded_url" : "http:\/\/kck.st\/2axoiQs",
        "display_url" : "kck.st\/2axoiQs"
      } ]
    },
    "geo" : { },
    "id_str" : "758360452913041414",
    "text" : "\u201CFireside Audiobox - Light your music on fire. by Grey Street Design\u201D \u263A https:\/\/t.co\/9jhSwD74Fo",
    "id" : 758360452913041414,
    "created_at" : "2016-07-27 17:56:36 +0000",
    "user" : {
      "name" : "Projects We Love",
      "screen_name" : "kickstarterbot",
      "protected" : false,
      "id_str" : "2411526686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/565287981510979584\/RUOh_tbm_normal.png",
      "id" : 2411526686,
      "verified" : false
    }
  },
  "id" : 758512285031686145,
  "created_at" : "2016-07-28 03:59:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best of Kickstarter",
      "screen_name" : "BestofKickstart",
      "indices" : [ 3, 19 ],
      "id_str" : "761789870",
      "id" : 761789870
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bk05c33iF8",
      "expanded_url" : "http:\/\/buff.ly\/1RyLUxG",
      "display_url" : "buff.ly\/1RyLUxG"
    } ]
  },
  "geo" : { },
  "id_str" : "758512206774308864",
  "text" : "RT @BestofKickstart: 4 Steps for Crowdfunding A Movie https:\/\/t.co\/bk05c33iF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/bk05c33iF8",
        "expanded_url" : "http:\/\/buff.ly\/1RyLUxG",
        "display_url" : "buff.ly\/1RyLUxG"
      } ]
    },
    "geo" : { },
    "id_str" : "758427773413257216",
    "text" : "4 Steps for Crowdfunding A Movie https:\/\/t.co\/bk05c33iF8",
    "id" : 758427773413257216,
    "created_at" : "2016-07-27 22:24:06 +0000",
    "user" : {
      "name" : "Best of Kickstarter",
      "screen_name" : "BestofKickstart",
      "protected" : false,
      "id_str" : "761789870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000530748601\/67bb54fa3c6738c33f74d38a5f2f97f2_normal.jpeg",
      "id" : 761789870,
      "verified" : false
    }
  },
  "id" : 758512206774308864,
  "created_at" : "2016-07-28 03:59:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kickstarter\/status\/758278041466396673\/photo\/1",
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/awIYWMVyEd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXx2_IUEAAzoj3.jpg",
      "id_str" : "758278039243329536",
      "id" : 758278039243329536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXx2_IUEAAzoj3.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/awIYWMVyEd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/l3A5gnNgDy",
      "expanded_url" : "http:\/\/kck.st\/2a0O6Pk",
      "display_url" : "kck.st\/2a0O6Pk"
    } ]
  },
  "geo" : { },
  "id_str" : "758512115850158081",
  "text" : "RT @kickstarter: This 3D pen runs on recycled plastic: https:\/\/t.co\/l3A5gnNgDy https:\/\/t.co\/awIYWMVyEd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kickstarter\/status\/758278041466396673\/photo\/1",
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/awIYWMVyEd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoXx2_IUEAAzoj3.jpg",
        "id_str" : "758278039243329536",
        "id" : 758278039243329536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoXx2_IUEAAzoj3.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/awIYWMVyEd"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/l3A5gnNgDy",
        "expanded_url" : "http:\/\/kck.st\/2a0O6Pk",
        "display_url" : "kck.st\/2a0O6Pk"
      } ]
    },
    "geo" : { },
    "id_str" : "758278041466396673",
    "text" : "This 3D pen runs on recycled plastic: https:\/\/t.co\/l3A5gnNgDy https:\/\/t.co\/awIYWMVyEd",
    "id" : 758278041466396673,
    "created_at" : "2016-07-27 12:29:07 +0000",
    "user" : {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "protected" : false,
      "id_str" : "16186995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849352837414998018\/kI43QUoj_normal.jpg",
      "id" : 16186995,
      "verified" : true
    }
  },
  "id" : 758512115850158081,
  "created_at" : "2016-07-28 03:59:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Amazon",
      "screen_name" : "amazon",
      "indices" : [ 90, 97 ],
      "id_str" : "20793816",
      "id" : 20793816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kickstarted",
      "indices" : [ 62, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/rp22WsKQoP",
      "expanded_url" : "http:\/\/kck.st\/2aboaXq",
      "display_url" : "kck.st\/2aboaXq"
    } ]
  },
  "geo" : { },
  "id_str" : "758512076826353666",
  "text" : "RT @kickstarter: From concept to reality, discover a world of #Kickstarted ideas \u2014 now on @Amazon Launchpad: https:\/\/t.co\/rp22WsKQoP https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amazon",
        "screen_name" : "amazon",
        "indices" : [ 73, 80 ],
        "id_str" : "20793816",
        "id" : 20793816
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kickstarter\/status\/758307226645696512\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/cXE7GlSELJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoYMZv2UEAAfGDx.jpg",
        "id_str" : "758307223739043840",
        "id" : 758307223739043840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoYMZv2UEAAfGDx.jpg",
        "sizes" : [ {
          "h" : 655,
          "resize" : "fit",
          "w" : 1197
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1197
        }, {
          "h" : 372,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 1197
        } ],
        "display_url" : "pic.twitter.com\/cXE7GlSELJ"
      } ],
      "hashtags" : [ {
        "text" : "Kickstarted",
        "indices" : [ 45, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/rp22WsKQoP",
        "expanded_url" : "http:\/\/kck.st\/2aboaXq",
        "display_url" : "kck.st\/2aboaXq"
      } ]
    },
    "geo" : { },
    "id_str" : "758307226645696512",
    "text" : "From concept to reality, discover a world of #Kickstarted ideas \u2014 now on @Amazon Launchpad: https:\/\/t.co\/rp22WsKQoP https:\/\/t.co\/cXE7GlSELJ",
    "id" : 758307226645696512,
    "created_at" : "2016-07-27 14:25:06 +0000",
    "user" : {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "protected" : false,
      "id_str" : "16186995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849352837414998018\/kI43QUoj_normal.jpg",
      "id" : 16186995,
      "verified" : true
    }
  },
  "id" : 758512076826353666,
  "created_at" : "2016-07-28 03:59:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/AdDkRyPLOG",
      "expanded_url" : "http:\/\/kck.st\/29Ubq5g",
      "display_url" : "kck.st\/29Ubq5g"
    } ]
  },
  "geo" : { },
  "id_str" : "758511944261177346",
  "text" : "RT @kickstarter: Gluten-free, sugar-free, protein-rich\u2014this is the platonic ideal of a keto-friendly cookie: https:\/\/t.co\/AdDkRyPLOG https:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/percolate.com\" rel=\"nofollow\"\u003EPercolate\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kickstarter\/status\/758479364640038913\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/q0IKnz0PXF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coao9hQUAAQtcYn.jpg",
        "id_str" : "758479362110783492",
        "id" : 758479362110783492,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coao9hQUAAQtcYn.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/q0IKnz0PXF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/AdDkRyPLOG",
        "expanded_url" : "http:\/\/kck.st\/29Ubq5g",
        "display_url" : "kck.st\/29Ubq5g"
      } ]
    },
    "geo" : { },
    "id_str" : "758479364640038913",
    "text" : "Gluten-free, sugar-free, protein-rich\u2014this is the platonic ideal of a keto-friendly cookie: https:\/\/t.co\/AdDkRyPLOG https:\/\/t.co\/q0IKnz0PXF",
    "id" : 758479364640038913,
    "created_at" : "2016-07-28 01:49:07 +0000",
    "user" : {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "protected" : false,
      "id_str" : "16186995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/849352837414998018\/kI43QUoj_normal.jpg",
      "id" : 16186995,
      "verified" : true
    }
  },
  "id" : 758511944261177346,
  "created_at" : "2016-07-28 03:58:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsithinkabout",
      "indices" : [ 37, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758511344555393025",
  "text" : "Taco Bell's long gone Volcano Nachos #thingsithinkabout",
  "id" : 758511344555393025,
  "created_at" : "2016-07-28 03:56:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Perfectly Timed Pics",
      "screen_name" : "Uber_Pix",
      "indices" : [ 3, 12 ],
      "id_str" : "525821517",
      "id" : 525821517
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Uber_Pix\/status\/758447134261841920\/photo\/1",
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/MSk2jA5Rk9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaLpUIWAAACdVH.jpg",
      "id_str" : "758447129153110016",
      "id" : 758447129153110016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaLpUIWAAACdVH.jpg",
      "sizes" : [ {
        "h" : 489,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MSk2jA5Rk9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758510992611344384",
  "text" : "RT @Uber_Pix: Walk like a boss. https:\/\/t.co\/MSk2jA5Rk9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Uber_Pix\/status\/758447134261841920\/photo\/1",
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/MSk2jA5Rk9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoaLpUIWAAACdVH.jpg",
        "id_str" : "758447129153110016",
        "id" : 758447129153110016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoaLpUIWAAACdVH.jpg",
        "sizes" : [ {
          "h" : 489,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 489,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MSk2jA5Rk9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758447134261841920",
    "text" : "Walk like a boss. https:\/\/t.co\/MSk2jA5Rk9",
    "id" : 758447134261841920,
    "created_at" : "2016-07-27 23:41:02 +0000",
    "user" : {
      "name" : "Perfectly Timed Pics",
      "screen_name" : "Uber_Pix",
      "protected" : false,
      "id_str" : "525821517",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653300851533062145\/IbiQdknI_normal.png",
      "id" : 525821517,
      "verified" : false
    }
  },
  "id" : 758510992611344384,
  "created_at" : "2016-07-28 03:54:47 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Learn Something",
      "screen_name" : "EarnKnowledge",
      "indices" : [ 3, 17 ],
      "id_str" : "843112550",
      "id" : 843112550
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DiscoverAndKnow\/status\/730127513628909568\/photo\/1",
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/wnSJOelLSO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CiHvGrvWwAAPitt.jpg",
      "id_str" : "730127512710332416",
      "id" : 730127512710332416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiHvGrvWwAAPitt.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 796,
        "resize" : "fit",
        "w" : 1199
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wnSJOelLSO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758510856007102464",
  "text" : "RT @EarnKnowledge: This is what tulip fields in Holland look like. https:\/\/t.co\/wnSJOelLSO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DiscoverAndKnow\/status\/730127513628909568\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/wnSJOelLSO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CiHvGrvWwAAPitt.jpg",
        "id_str" : "730127512710332416",
        "id" : 730127512710332416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CiHvGrvWwAAPitt.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 796,
          "resize" : "fit",
          "w" : 1199
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wnSJOelLSO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758354078581784576",
    "text" : "This is what tulip fields in Holland look like. https:\/\/t.co\/wnSJOelLSO",
    "id" : 758354078581784576,
    "created_at" : "2016-07-27 17:31:16 +0000",
    "user" : {
      "name" : "Learn Something",
      "screen_name" : "EarnKnowledge",
      "protected" : false,
      "id_str" : "843112550",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770497822844006400\/3TwwqOGL_normal.jpg",
      "id" : 843112550,
      "verified" : false
    }
  },
  "id" : 758510856007102464,
  "created_at" : "2016-07-28 03:54:15 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/dTwIlj7ELk",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/27\/mercedes-unveils-worlds-first-completely-electric-semi-truck\/",
      "display_url" : "engadget.com\/2016\/07\/27\/mer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758510789946781696",
  "text" : "RT @EmperorDarroux: Mercedes unveils world's first completely electric semi truck https:\/\/t.co\/dTwIlj7ELk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/dTwIlj7ELk",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/27\/mercedes-unveils-worlds-first-completely-electric-semi-truck\/",
        "display_url" : "engadget.com\/2016\/07\/27\/mer\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758507136628330496",
    "text" : "Mercedes unveils world's first completely electric semi truck https:\/\/t.co\/dTwIlj7ELk",
    "id" : 758507136628330496,
    "created_at" : "2016-07-28 03:39:28 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 758510789946781696,
  "created_at" : "2016-07-28 03:53:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gentleman's Handbook",
      "screen_name" : "ImThatGentleman",
      "indices" : [ 3, 19 ],
      "id_str" : "910828603",
      "id" : 910828603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758510744392519680",
  "text" : "RT @ImThatGentleman: I don't want any half time friends, nor people who ignore me or use me. Either be in or be out. No games. Quality frie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758498155230957568",
    "text" : "I don't want any half time friends, nor people who ignore me or use me. Either be in or be out. No games. Quality friends are what I want.",
    "id" : 758498155230957568,
    "created_at" : "2016-07-28 03:03:47 +0000",
    "user" : {
      "name" : "Gentleman's Handbook",
      "screen_name" : "ImThatGentleman",
      "protected" : false,
      "id_str" : "910828603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554534561137172480\/A5D0C235_normal.jpeg",
      "id" : 910828603,
      "verified" : false
    }
  },
  "id" : 758510744392519680,
  "created_at" : "2016-07-28 03:53:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758509112938356736\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/bb1bojOs4B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CobEBBGW8AAdzmy.jpg",
      "id_str" : "758509109012525056",
      "id" : 758509109012525056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CobEBBGW8AAdzmy.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bb1bojOs4B"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/K42dNVzFHS",
      "expanded_url" : "http:\/\/engt.co\/2abjEUd",
      "display_url" : "engt.co\/2abjEUd"
    } ]
  },
  "geo" : { },
  "id_str" : "758510360848588800",
  "text" : "RT @engadget: Researchers believe Jupiter's Red Spot is heated by thunder https:\/\/t.co\/K42dNVzFHS https:\/\/t.co\/bb1bojOs4B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/758509112938356736\/photo\/1",
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/bb1bojOs4B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CobEBBGW8AAdzmy.jpg",
        "id_str" : "758509109012525056",
        "id" : 758509109012525056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CobEBBGW8AAdzmy.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/bb1bojOs4B"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 83 ],
        "url" : "https:\/\/t.co\/K42dNVzFHS",
        "expanded_url" : "http:\/\/engt.co\/2abjEUd",
        "display_url" : "engt.co\/2abjEUd"
      } ]
    },
    "geo" : { },
    "id_str" : "758509112938356736",
    "text" : "Researchers believe Jupiter's Red Spot is heated by thunder https:\/\/t.co\/K42dNVzFHS https:\/\/t.co\/bb1bojOs4B",
    "id" : 758509112938356736,
    "created_at" : "2016-07-28 03:47:19 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 758510360848588800,
  "created_at" : "2016-07-28 03:52:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758509814418804736",
  "text" : "RT @tedcruz: Latest example of this Admin's willful blindness: equating threat of radical Islamic terrorists to air conditioners https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/sWdkEC4CRS",
        "expanded_url" : "http:\/\/www.foxnews.com\/politics\/2016\/07\/23\/kerry-air-conditioners-as-big-threat-as-isis.html",
        "display_url" : "foxnews.com\/politics\/2016\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757559702267895808",
    "text" : "Latest example of this Admin's willful blindness: equating threat of radical Islamic terrorists to air conditioners https:\/\/t.co\/sWdkEC4CRS",
    "id" : 757559702267895808,
    "created_at" : "2016-07-25 12:54:42 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 758509814418804736,
  "created_at" : "2016-07-28 03:50:06 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758509729861685249",
  "text" : "RT @BarbaraCorcoran: Never be ashamed of who you are! Everyone likes and responds best to people who are comfortable with themselves. ALWAY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757540597527932929",
    "text" : "Never be ashamed of who you are! Everyone likes and responds best to people who are comfortable with themselves. ALWAYS!",
    "id" : 757540597527932929,
    "created_at" : "2016-07-25 11:38:47 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 758509729861685249,
  "created_at" : "2016-07-28 03:49:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758509062036131840",
  "text" : "@lady_valencia_ That sounds like an awful idea",
  "id" : 758509062036131840,
  "created_at" : "2016-07-28 03:47:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "paula santos",
      "screen_name" : "paulasantos_US",
      "indices" : [ 3, 18 ],
      "id_str" : "206910567",
      "id" : 206910567
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/paulasantos_US\/status\/758504402638340097\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/PbQeY1EUi4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Coa_pEFUkAAD-CW.jpg",
      "id_str" : "758504299450109952",
      "id" : 758504299450109952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coa_pEFUkAAD-CW.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/PbQeY1EUi4"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 45, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758508566412087296",
  "text" : "RT @paulasantos_US: The beach and Donuts are #ThingsICanNeverResist https:\/\/t.co\/PbQeY1EUi4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/paulasantos_US\/status\/758504402638340097\/photo\/1",
        "indices" : [ 48, 71 ],
        "url" : "https:\/\/t.co\/PbQeY1EUi4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Coa_pEFUkAAD-CW.jpg",
        "id_str" : "758504299450109952",
        "id" : 758504299450109952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Coa_pEFUkAAD-CW.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/PbQeY1EUi4"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 25, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758504402638340097",
    "text" : "The beach and Donuts are #ThingsICanNeverResist https:\/\/t.co\/PbQeY1EUi4",
    "id" : 758504402638340097,
    "created_at" : "2016-07-28 03:28:36 +0000",
    "user" : {
      "name" : "paula santos",
      "screen_name" : "paulasantos_US",
      "protected" : false,
      "id_str" : "206910567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472752386142781440\/j8ORG4hI_normal.jpeg",
      "id" : 206910567,
      "verified" : false
    }
  },
  "id" : 758508566412087296,
  "created_at" : "2016-07-28 03:45:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 18, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758508126446366720",
  "text" : "RT @muchfabsowow: #ThingsICanNeverResist Flaming Hot Cheetos \uD83D\uDE0D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758505773320241153",
    "text" : "#ThingsICanNeverResist Flaming Hot Cheetos \uD83D\uDE0D",
    "id" : 758505773320241153,
    "created_at" : "2016-07-28 03:34:03 +0000",
    "user" : {
      "name" : "T.",
      "screen_name" : "unamusedmuggle",
      "protected" : false,
      "id_str" : "724306659816947713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/845659402795409408\/bund_2Yk_normal.jpg",
      "id" : 724306659816947713,
      "verified" : false
    }
  },
  "id" : 758508126446366720,
  "created_at" : "2016-07-28 03:43:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Molly Larzo",
      "screen_name" : "molly_shaelise",
      "indices" : [ 0, 15 ],
      "id_str" : "494405804",
      "id" : 494405804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758506108361273344",
  "geo" : { },
  "id_str" : "758508007168679936",
  "in_reply_to_user_id" : 494405804,
  "text" : "@molly_shaelise Wow I can never resist myself too!!!",
  "id" : 758508007168679936,
  "in_reply_to_status_id" : 758506108361273344,
  "created_at" : "2016-07-28 03:42:55 +0000",
  "in_reply_to_screen_name" : "molly_shaelise",
  "in_reply_to_user_id_str" : "494405804",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Passionfruit",
      "screen_name" : "7ElevenTevin",
      "indices" : [ 3, 16 ],
      "id_str" : "2546078835",
      "id" : 2546078835
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/7ElevenTevin\/status\/758506206168289281\/photo\/1",
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/RW7beEv9iK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CobBXiYXEAQmQzk.jpg",
      "id_str" : "758506197368639492",
      "id" : 758506197368639492,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CobBXiYXEAQmQzk.jpg",
      "sizes" : [ {
        "h" : 199,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 300
      }, {
        "h" : 199,
        "resize" : "fit",
        "w" : 300
      } ],
      "display_url" : "pic.twitter.com\/RW7beEv9iK"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 63, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758507075588624384",
  "text" : "RT @7ElevenTevin: Great American Cookie's red velvet brownies  #ThingsICanNeverResist https:\/\/t.co\/RW7beEv9iK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/7ElevenTevin\/status\/758506206168289281\/photo\/1",
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/RW7beEv9iK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CobBXiYXEAQmQzk.jpg",
        "id_str" : "758506197368639492",
        "id" : 758506197368639492,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CobBXiYXEAQmQzk.jpg",
        "sizes" : [ {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        }, {
          "h" : 199,
          "resize" : "fit",
          "w" : 300
        } ],
        "display_url" : "pic.twitter.com\/RW7beEv9iK"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 45, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758506206168289281",
    "text" : "Great American Cookie's red velvet brownies  #ThingsICanNeverResist https:\/\/t.co\/RW7beEv9iK",
    "id" : 758506206168289281,
    "created_at" : "2016-07-28 03:35:46 +0000",
    "user" : {
      "name" : "Passionfruit",
      "screen_name" : "7ElevenTevin",
      "protected" : false,
      "id_str" : "2546078835",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/843291716908208128\/XKKW1LxW_normal.jpg",
      "id" : 2546078835,
      "verified" : false
    }
  },
  "id" : 758507075588624384,
  "created_at" : "2016-07-28 03:39:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roshan Ali",
      "screen_name" : "RoshanAli011",
      "indices" : [ 3, 16 ],
      "id_str" : "752148298765664257",
      "id" : 752148298765664257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 18, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758507005409566720",
  "text" : "RT @RoshanAli011: #ThingsICanNeverResist Pizza ;)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758506674013470720",
    "text" : "#ThingsICanNeverResist Pizza ;)",
    "id" : 758506674013470720,
    "created_at" : "2016-07-28 03:37:38 +0000",
    "user" : {
      "name" : "Roshan Ali",
      "screen_name" : "RoshanAli011",
      "protected" : false,
      "id_str" : "752148298765664257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762158675024904192\/a_oYNXv3_normal.jpg",
      "id" : 752148298765664257,
      "verified" : false
    }
  },
  "id" : 758507005409566720,
  "created_at" : "2016-07-28 03:38:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Madison Martin",
      "screen_name" : "MadisonLMartin9",
      "indices" : [ 3, 19 ],
      "id_str" : "2788411337",
      "id" : 2788411337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 60, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758506979367096321",
  "text" : "RT @MadisonLMartin9: A good sense of humor and cheese fries #ThingsICanNeverResist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 39, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758506827738939392",
    "text" : "A good sense of humor and cheese fries #ThingsICanNeverResist",
    "id" : 758506827738939392,
    "created_at" : "2016-07-28 03:38:14 +0000",
    "user" : {
      "name" : "Madison Martin",
      "screen_name" : "MadisonLMartin9",
      "protected" : false,
      "id_str" : "2788411337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/830575167533412356\/GyGPagYF_normal.jpg",
      "id" : 2788411337,
      "verified" : false
    }
  },
  "id" : 758506979367096321,
  "created_at" : "2016-07-28 03:38:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J.K.Callaway",
      "screen_name" : "realJKCallaway",
      "indices" : [ 3, 18 ],
      "id_str" : "248111082",
      "id" : 248111082
    }, {
      "name" : "#Skirmish",
      "screen_name" : "HashtagSkirmish",
      "indices" : [ 75, 91 ],
      "id_str" : "3010552459",
      "id" : 3010552459
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 52, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758506865848299520",
  "text" : "RT @realJKCallaway: Another Spoon Full of Ice Cream #ThingsICanNeverResist @HashtagSkirmish",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#Skirmish",
        "screen_name" : "HashtagSkirmish",
        "indices" : [ 55, 71 ],
        "id_str" : "3010552459",
        "id" : 3010552459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 32, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758376811528990720",
    "text" : "Another Spoon Full of Ice Cream #ThingsICanNeverResist @HashtagSkirmish",
    "id" : 758376811528990720,
    "created_at" : "2016-07-27 19:01:36 +0000",
    "user" : {
      "name" : "J.K.Callaway",
      "screen_name" : "realJKCallaway",
      "protected" : false,
      "id_str" : "248111082",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822971923877400576\/09R-xC57_normal.jpg",
      "id" : 248111082,
      "verified" : false
    }
  },
  "id" : 758506865848299520,
  "created_at" : "2016-07-28 03:38:23 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dee_emphasize",
      "screen_name" : "dee_emphasize",
      "indices" : [ 3, 17 ],
      "id_str" : "2935664425",
      "id" : 2935664425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 42, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758506762030886912",
  "text" : "RT @dee_emphasize: Costco cheese samples  #ThingsICanNeverResist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 23, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758377135119568898",
    "text" : "Costco cheese samples  #ThingsICanNeverResist",
    "id" : 758377135119568898,
    "created_at" : "2016-07-27 19:02:53 +0000",
    "user" : {
      "name" : "Dee_emphasize",
      "screen_name" : "dee_emphasize",
      "protected" : false,
      "id_str" : "2935664425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/809579012133527552\/-1EK9wTO_normal.jpg",
      "id" : 2935664425,
      "verified" : false
    }
  },
  "id" : 758506762030886912,
  "created_at" : "2016-07-28 03:37:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u2660\uFE0FQueen of Spades\u2660\uFE0F",
      "screen_name" : "SinCityChiGirl",
      "indices" : [ 0, 15 ],
      "id_str" : "1027734648",
      "id" : 1027734648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758377162852429824",
  "geo" : { },
  "id_str" : "758506721300008960",
  "in_reply_to_user_id" : 1027734648,
  "text" : "@SinCityChiGirl Honey roasted, right?",
  "id" : 758506721300008960,
  "in_reply_to_status_id" : 758377162852429824,
  "created_at" : "2016-07-28 03:37:49 +0000",
  "in_reply_to_screen_name" : "SinCityChiGirl",
  "in_reply_to_user_id_str" : "1027734648",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moe'sSouthwestGrill",
      "screen_name" : "Moes_HQ",
      "indices" : [ 3, 11 ],
      "id_str" : "84075278",
      "id" : 84075278
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Moes_HQ\/status\/758387420110983169\/photo\/1",
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/YmWMxmFgZi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZVVFOWgAAf34c.jpg",
      "id_str" : "758387407926493184",
      "id" : 758387407926493184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZVVFOWgAAf34c.jpg",
      "sizes" : [ {
        "h" : 3024,
        "resize" : "fit",
        "w" : 4032
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/YmWMxmFgZi"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 13, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505771738935296",
  "text" : "RT @Moes_HQ: #ThingsICanNeverResist Liquid goooooold https:\/\/t.co\/YmWMxmFgZi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Moes_HQ\/status\/758387420110983169\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/YmWMxmFgZi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZVVFOWgAAf34c.jpg",
        "id_str" : "758387407926493184",
        "id" : 758387407926493184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZVVFOWgAAf34c.jpg",
        "sizes" : [ {
          "h" : 3024,
          "resize" : "fit",
          "w" : 4032
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YmWMxmFgZi"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758387420110983169",
    "text" : "#ThingsICanNeverResist Liquid goooooold https:\/\/t.co\/YmWMxmFgZi",
    "id" : 758387420110983169,
    "created_at" : "2016-07-27 19:43:45 +0000",
    "user" : {
      "name" : "Moe'sSouthwestGrill",
      "screen_name" : "Moes_HQ",
      "protected" : false,
      "id_str" : "84075278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780780771846086656\/LqbIU_1W_normal.jpg",
      "id" : 84075278,
      "verified" : true
    }
  },
  "id" : 758505771738935296,
  "created_at" : "2016-07-28 03:34:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cinnabon",
      "screen_name" : "Cinnabon",
      "indices" : [ 3, 12 ],
      "id_str" : "84708371",
      "id" : 84708371
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cinnabon\/status\/758397246106841088\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/TQVzSoluGw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZXTnLVIAAiLd5.jpg",
      "id_str" : "758389581704142848",
      "id" : 758389581704142848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZXTnLVIAAiLd5.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/TQVzSoluGw"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 37, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505677476159488",
  "text" : "RT @Cinnabon: Resistance is futile. \n#ThingsICanNeverResist https:\/\/t.co\/TQVzSoluGw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cinnabon\/status\/758397246106841088\/photo\/1",
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/TQVzSoluGw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZXTnLVIAAiLd5.jpg",
        "id_str" : "758389581704142848",
        "id" : 758389581704142848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZXTnLVIAAiLd5.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/TQVzSoluGw"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 23, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758397246106841088",
    "text" : "Resistance is futile. \n#ThingsICanNeverResist https:\/\/t.co\/TQVzSoluGw",
    "id" : 758397246106841088,
    "created_at" : "2016-07-27 20:22:48 +0000",
    "user" : {
      "name" : "Cinnabon",
      "screen_name" : "Cinnabon",
      "protected" : false,
      "id_str" : "84708371",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/689911300206366722\/lj4jGl2H_normal.jpg",
      "id" : 84708371,
      "verified" : true
    }
  },
  "id" : 758505677476159488,
  "created_at" : "2016-07-28 03:33:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krispykreme",
      "screen_name" : "krispykreme",
      "indices" : [ 3, 15 ],
      "id_str" : "17944853",
      "id" : 17944853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/krispykreme\/status\/758402111759527937\/photo\/1",
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/bXFEdcla7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZifhqUEAEHbmR.jpg",
      "id_str" : "758401881009819649",
      "id" : 758401881009819649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZifhqUEAEHbmR.jpg",
      "sizes" : [ {
        "h" : 596,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 596
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 596
      } ],
      "display_url" : "pic.twitter.com\/bXFEdcla7h"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 17, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505659792883715",
  "text" : "RT @krispykreme: #ThingsICanNeverResist Doughnuts + Chocolate \uD83D\uDE0D https:\/\/t.co\/bXFEdcla7h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/krispykreme\/status\/758402111759527937\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/bXFEdcla7h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZifhqUEAEHbmR.jpg",
        "id_str" : "758401881009819649",
        "id" : 758401881009819649,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZifhqUEAEHbmR.jpg",
        "sizes" : [ {
          "h" : 596,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 596
        }, {
          "h" : 596,
          "resize" : "fit",
          "w" : 596
        } ],
        "display_url" : "pic.twitter.com\/bXFEdcla7h"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758402111759527937",
    "text" : "#ThingsICanNeverResist Doughnuts + Chocolate \uD83D\uDE0D https:\/\/t.co\/bXFEdcla7h",
    "id" : 758402111759527937,
    "created_at" : "2016-07-27 20:42:08 +0000",
    "user" : {
      "name" : "krispykreme",
      "screen_name" : "krispykreme",
      "protected" : false,
      "id_str" : "17944853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/437576194322493440\/W-1qbR9p_normal.jpeg",
      "id" : 17944853,
      "verified" : true
    }
  },
  "id" : 758505659792883715,
  "created_at" : "2016-07-28 03:33:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZK Media",
      "screen_name" : "ZKMedia",
      "indices" : [ 3, 11 ],
      "id_str" : "4922347144",
      "id" : 4922347144
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZKMedia\/status\/758414965854314499\/photo\/1",
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/DE4gjEtTSf",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZuUqXWIAAEItn.jpg",
      "id_str" : "758414888507154432",
      "id" : 758414888507154432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZuUqXWIAAEItn.jpg",
      "sizes" : [ {
        "h" : 312,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 221,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DE4gjEtTSf"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 13, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505608375001089",
  "text" : "RT @ZKMedia: #ThingsICanNeverResist Chocolate Cookies! https:\/\/t.co\/DE4gjEtTSf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZKMedia\/status\/758414965854314499\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/DE4gjEtTSf",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZuUqXWIAAEItn.jpg",
        "id_str" : "758414888507154432",
        "id" : 758414888507154432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZuUqXWIAAEItn.jpg",
        "sizes" : [ {
          "h" : 312,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 221,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DE4gjEtTSf"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758414965854314499",
    "text" : "#ThingsICanNeverResist Chocolate Cookies! https:\/\/t.co\/DE4gjEtTSf",
    "id" : 758414965854314499,
    "created_at" : "2016-07-27 21:33:13 +0000",
    "user" : {
      "name" : "ScaleLab UK",
      "screen_name" : "ScaleLabUK",
      "protected" : false,
      "id_str" : "4409354236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826139701753081860\/Mwqn5kCe_normal.jpg",
      "id" : 4409354236,
      "verified" : true
    }
  },
  "id" : 758505608375001089,
  "created_at" : "2016-07-28 03:33:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nelious Films",
      "screen_name" : "neliousfilms",
      "indices" : [ 3, 16 ],
      "id_str" : "123684106",
      "id" : 123684106
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/neliousfilms\/status\/758425055894175744\/photo\/1",
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/Fzu6GXfHpu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZ3kRDUAAAQmC4.jpg",
      "id_str" : "758425052194799616",
      "id" : 758425052194799616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZ3kRDUAAAQmC4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 275
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 275
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 275
      }, {
        "h" : 183,
        "resize" : "fit",
        "w" : 275
      } ],
      "display_url" : "pic.twitter.com\/Fzu6GXfHpu"
    } ],
    "hashtags" : [ {
      "text" : "ThingsICanNeverResist",
      "indices" : [ 18, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505439549984768",
  "text" : "RT @neliousfilms: #ThingsICanNeverResist one of these cookies https:\/\/t.co\/Fzu6GXfHpu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/neliousfilms\/status\/758425055894175744\/photo\/1",
        "indices" : [ 44, 67 ],
        "url" : "https:\/\/t.co\/Fzu6GXfHpu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoZ3kRDUAAAQmC4.jpg",
        "id_str" : "758425052194799616",
        "id" : 758425052194799616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoZ3kRDUAAAQmC4.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 275
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 275
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 275
        }, {
          "h" : 183,
          "resize" : "fit",
          "w" : 275
        } ],
        "display_url" : "pic.twitter.com\/Fzu6GXfHpu"
      } ],
      "hashtags" : [ {
        "text" : "ThingsICanNeverResist",
        "indices" : [ 0, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758425055894175744",
    "text" : "#ThingsICanNeverResist one of these cookies https:\/\/t.co\/Fzu6GXfHpu",
    "id" : 758425055894175744,
    "created_at" : "2016-07-27 22:13:18 +0000",
    "user" : {
      "name" : "Nelious Films",
      "screen_name" : "neliousfilms",
      "protected" : false,
      "id_str" : "123684106",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/833905885814652928\/wVftVpt7_normal.jpg",
      "id" : 123684106,
      "verified" : false
    }
  },
  "id" : 758505439549984768,
  "created_at" : "2016-07-28 03:32:43 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 3, 19 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758505192190976000",
  "text" : "RT @realDonaldTrump: Our not very bright Vice President, Joe Biden, just stated that I wanted to \"carpet bomb\" the enemy. Sorry Joe, that w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758285141982711808",
    "text" : "Our not very bright Vice President, Joe Biden, just stated that I wanted to \"carpet bomb\" the enemy. Sorry Joe, that was Ted Cruz!",
    "id" : 758285141982711808,
    "created_at" : "2016-07-27 12:57:20 +0000",
    "user" : {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "protected" : false,
      "id_str" : "25073877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1980294624\/DJT_Headshot_V2_normal.jpg",
      "id" : 25073877,
      "verified" : true
    }
  },
  "id" : 758505192190976000,
  "created_at" : "2016-07-28 03:31:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "College Republicans",
      "screen_name" : "CRNC",
      "indices" : [ 3, 8 ],
      "id_str" : "7039122",
      "id" : 7039122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758504878155018241",
  "text" : "RT @CRNC: That was the worst speech I've ever heard. Believe me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "758492988553113600",
    "text" : "That was the worst speech I've ever heard. Believe me.",
    "id" : 758492988553113600,
    "created_at" : "2016-07-28 02:43:15 +0000",
    "user" : {
      "name" : "College Republicans",
      "screen_name" : "CRNC",
      "protected" : false,
      "id_str" : "7039122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/836304466647388164\/zz6aFM1V_normal.jpg",
      "id" : 7039122,
      "verified" : true
    }
  },
  "id" : 758504878155018241,
  "created_at" : "2016-07-28 03:30:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dirk Nowitzki",
      "screen_name" : "swish41",
      "indices" : [ 3, 11 ],
      "id_str" : "205415788",
      "id" : 205415788
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758504540014387200",
  "text" : "RT @swish41: Still in shock. Saddened to hear about the tragic events in Dallas. My Thoughts are with everyone, who are affected. #StoptheV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StoptheViolence",
        "indices" : [ 117, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751465893448658944",
    "text" : "Still in shock. Saddened to hear about the tragic events in Dallas. My Thoughts are with everyone, who are affected. #StoptheViolence",
    "id" : 751465893448658944,
    "created_at" : "2016-07-08 17:20:05 +0000",
    "user" : {
      "name" : "Dirk Nowitzki",
      "screen_name" : "swish41",
      "protected" : false,
      "id_str" : "205415788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3669044632\/8177070479aeb345d84745272ed1b614_normal.jpeg",
      "id" : 205415788,
      "verified" : true
    }
  },
  "id" : 758504540014387200,
  "created_at" : "2016-07-28 03:29:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin Graham",
      "screen_name" : "Franklin_Graham",
      "indices" : [ 3, 19 ],
      "id_str" : "44945327",
      "id" : 44945327
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758504511392456704",
  "text" : "RT @Franklin_Graham: Our next president is not our great hope; Jesus Christ alone is the only hope for a sinful nation and people enraged w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751513701216231426",
    "text" : "Our next president is not our great hope; Jesus Christ alone is the only hope for a sinful nation and people enraged with evil.",
    "id" : 751513701216231426,
    "created_at" : "2016-07-08 20:30:03 +0000",
    "user" : {
      "name" : "Franklin Graham",
      "screen_name" : "Franklin_Graham",
      "protected" : false,
      "id_str" : "44945327",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/801022847371984896\/6ygXVUj1_normal.jpg",
      "id" : 44945327,
      "verified" : true
    }
  },
  "id" : 758504511392456704,
  "created_at" : "2016-07-28 03:29:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/w7QFdK4SYY",
      "expanded_url" : "https:\/\/twitter.com\/gregabbott_tx\/status\/752326023543336960",
      "display_url" : "twitter.com\/gregabbott_tx\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758504355699961856",
  "text" : "RT @tedcruz: Heidi's and my prayers are with you, Governor. Heal quickly. Texas needs you and loves you.  https:\/\/t.co\/w7QFdK4SYY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/w7QFdK4SYY",
        "expanded_url" : "https:\/\/twitter.com\/gregabbott_tx\/status\/752326023543336960",
        "display_url" : "twitter.com\/gregabbott_tx\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752520832123936768",
    "text" : "Heidi's and my prayers are with you, Governor. Heal quickly. Texas needs you and loves you.  https:\/\/t.co\/w7QFdK4SYY",
    "id" : 752520832123936768,
    "created_at" : "2016-07-11 15:12:02 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 758504355699961856,
  "created_at" : "2016-07-28 03:28:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cardillo",
      "screen_name" : "johncardillo",
      "indices" : [ 3, 16 ],
      "id_str" : "27995424",
      "id" : 27995424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758504211185143808",
  "text" : "RT @johncardillo: If you're unemployed and vote Dem, you're voting to add 12 million illegals to the competition pool for the job you want.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemDebate",
        "indices" : [ 122, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654303734143545344",
    "text" : "If you're unemployed and vote Dem, you're voting to add 12 million illegals to the competition pool for the job you want. #DemDebate",
    "id" : 654303734143545344,
    "created_at" : "2015-10-14 14:32:21 +0000",
    "user" : {
      "name" : "John Cardillo",
      "screen_name" : "johncardillo",
      "protected" : false,
      "id_str" : "27995424",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/842895624064458752\/in_MQ0ys_normal.jpg",
      "id" : 27995424,
      "verified" : true
    }
  },
  "id" : 758504211185143808,
  "created_at" : "2016-07-28 03:27:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/iONHdNGddq",
      "expanded_url" : "https:\/\/twitter.com\/DrSammyD\/status\/758443462920278016",
      "display_url" : "twitter.com\/DrSammyD\/statu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758502489486262272",
  "text" : "RT @scrowder: We try to help the good guys. :) https:\/\/t.co\/iONHdNGddq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/iONHdNGddq",
        "expanded_url" : "https:\/\/twitter.com\/DrSammyD\/status\/758443462920278016",
        "display_url" : "twitter.com\/DrSammyD\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758443981592113152",
    "text" : "We try to help the good guys. :) https:\/\/t.co\/iONHdNGddq",
    "id" : 758443981592113152,
    "created_at" : "2016-07-27 23:28:31 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 758502489486262272,
  "created_at" : "2016-07-28 03:21:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "indices" : [ 3, 12 ],
      "id_str" : "19091173",
      "id" : 19091173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/pZTRtuScy6",
      "expanded_url" : "https:\/\/twitter.com\/skagg_3\/status\/758470061841526785",
      "display_url" : "twitter.com\/skagg_3\/status\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758502109369147392",
  "text" : "RT @scrowder: It's the closest you'll get to recourse from their misquotes used to slander you. Glad I could help.  https:\/\/t.co\/pZTRtuScy6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/pZTRtuScy6",
        "expanded_url" : "https:\/\/twitter.com\/skagg_3\/status\/758470061841526785",
        "display_url" : "twitter.com\/skagg_3\/status\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758473670645854208",
    "text" : "It's the closest you'll get to recourse from their misquotes used to slander you. Glad I could help.  https:\/\/t.co\/pZTRtuScy6",
    "id" : 758473670645854208,
    "created_at" : "2016-07-28 01:26:29 +0000",
    "user" : {
      "name" : "Steven Crowder",
      "screen_name" : "scrowder",
      "protected" : false,
      "id_str" : "19091173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505849110436397058\/uHPPZnux_normal.jpeg",
      "id" : 19091173,
      "verified" : true
    }
  },
  "id" : 758502109369147392,
  "created_at" : "2016-07-28 03:19:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kassy Dillon",
      "screen_name" : "KassyDillon",
      "indices" : [ 20, 32 ],
      "id_str" : "178999981",
      "id" : 178999981
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758502015861260288",
  "text" : "So glad the amazing @KassyDillon is back on Twitter",
  "id" : 758502015861260288,
  "created_at" : "2016-07-28 03:19:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/BVw3WqjwMf",
      "expanded_url" : "http:\/\/on.mash.to\/2axngEi",
      "display_url" : "on.mash.to\/2axngEi"
    } ]
  },
  "geo" : { },
  "id_str" : "758425725787516928",
  "text" : "RT @mashable: Amazon launches Kickstarter section https:\/\/t.co\/BVw3WqjwMf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 59 ],
        "url" : "https:\/\/t.co\/BVw3WqjwMf",
        "expanded_url" : "http:\/\/on.mash.to\/2axngEi",
        "display_url" : "on.mash.to\/2axngEi"
      } ]
    },
    "geo" : { },
    "id_str" : "758359315178717184",
    "text" : "Amazon launches Kickstarter section https:\/\/t.co\/BVw3WqjwMf",
    "id" : 758359315178717184,
    "created_at" : "2016-07-27 17:52:05 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816703429095538688\/kAo5jTCy_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 758425725787516928,
  "created_at" : "2016-07-27 22:15:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/mashable\/status\/758414447681634304\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/LbNWUh695a",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZt6wVWYAAPja9.jpg",
      "id_str" : "758414443432796160",
      "id" : 758414443432796160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZt6wVWYAAPja9.jpg",
      "sizes" : [ {
        "h" : 264,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/LbNWUh695a"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 74 ],
      "url" : "https:\/\/t.co\/FEcLskFBU7",
      "expanded_url" : "http:\/\/on.mash.to\/2awAHEI",
      "display_url" : "on.mash.to\/2awAHEI"
    } ]
  },
  "geo" : { },
  "id_str" : "758425510451916800",
  "text" : "RT @mashable: Apple has now sold 1 billion iPhones https:\/\/t.co\/FEcLskFBU7 https:\/\/t.co\/LbNWUh695a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mashable\/status\/758414447681634304\/photo\/1",
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/LbNWUh695a",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZt6wVWYAAPja9.jpg",
        "id_str" : "758414443432796160",
        "id" : 758414443432796160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZt6wVWYAAPja9.jpg",
        "sizes" : [ {
          "h" : 264,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 264,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/LbNWUh695a"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 60 ],
        "url" : "https:\/\/t.co\/FEcLskFBU7",
        "expanded_url" : "http:\/\/on.mash.to\/2awAHEI",
        "display_url" : "on.mash.to\/2awAHEI"
      } ]
    },
    "geo" : { },
    "id_str" : "758414447681634304",
    "text" : "Apple has now sold 1 billion iPhones https:\/\/t.co\/FEcLskFBU7 https:\/\/t.co\/LbNWUh695a",
    "id" : 758414447681634304,
    "created_at" : "2016-07-27 21:31:09 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/816703429095538688\/kAo5jTCy_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 758425510451916800,
  "created_at" : "2016-07-27 22:15:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/7LMNw6oGAL",
      "expanded_url" : "http:\/\/es.pn\/2ayzqtD",
      "display_url" : "es.pn\/2ayzqtD"
    } ]
  },
  "geo" : { },
  "id_str" : "758424568893624321",
  "text" : "RT @FXStefan: Long: Bears out to quiet 'league-wide disrespect': Long: Bears out to quiet 'league-wide disrespect' https:\/\/t.co\/7LMNw6oGAL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sport",
        "indices" : [ 125, 131 ]
      }, {
        "text" : "nfl",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/7LMNw6oGAL",
        "expanded_url" : "http:\/\/es.pn\/2ayzqtD",
        "display_url" : "es.pn\/2ayzqtD"
      } ]
    },
    "geo" : { },
    "id_str" : "758423713897336832",
    "text" : "Long: Bears out to quiet 'league-wide disrespect': Long: Bears out to quiet 'league-wide disrespect' https:\/\/t.co\/7LMNw6oGAL #sport #nfl",
    "id" : 758423713897336832,
    "created_at" : "2016-07-27 22:07:58 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 758424568893624321,
  "created_at" : "2016-07-27 22:11:22 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758424209416605697",
  "text" : "RT @Matthiasiam: This headache must mean my brain is growing, otherwise, there would be no purpose to this torture. I refuse to believe any\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753356625906315265",
    "text" : "This headache must mean my brain is growing, otherwise, there would be no purpose to this torture. I refuse to believe anything else.",
    "id" : 753356625906315265,
    "created_at" : "2016-07-13 22:33:10 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 758424209416605697,
  "created_at" : "2016-07-27 22:09:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758424104865189889",
  "text" : "RT @Matthiasiam: Everytime someone I respect follows me on twitter, I start to post more responsibly, then a week later it turns back into\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "754799679024476160",
    "text" : "Everytime someone I respect follows me on twitter, I start to post more responsibly, then a week later it turns back into trash.",
    "id" : 754799679024476160,
    "created_at" : "2016-07-17 22:07:21 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 758424104865189889,
  "created_at" : "2016-07-27 22:09:32 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/2OhdUoAefr",
      "expanded_url" : "https:\/\/youtu.be\/-sqRpToUhpA",
      "display_url" : "youtu.be\/-sqRpToUhpA"
    } ]
  },
  "geo" : { },
  "id_str" : "758424031708061696",
  "text" : "RT @Matthiasiam: I try 6 strange items from the dollar store! I hate that most of them were food.  https:\/\/t.co\/2OhdUoAefr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/2OhdUoAefr",
        "expanded_url" : "https:\/\/youtu.be\/-sqRpToUhpA",
        "display_url" : "youtu.be\/-sqRpToUhpA"
      } ]
    },
    "geo" : { },
    "id_str" : "756628730215268354",
    "text" : "I try 6 strange items from the dollar store! I hate that most of them were food.  https:\/\/t.co\/2OhdUoAefr",
    "id" : 756628730215268354,
    "created_at" : "2016-07-22 23:15:21 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 758424031708061696,
  "created_at" : "2016-07-27 22:09:14 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 0, 12 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/758423898425745408\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/ypC2Rb5sxc",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZ2eWxVYAAOXAR.jpg",
      "id_str" : "758423851139162112",
      "id" : 758423851139162112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoZ2eWxVYAAOXAR.jpg",
      "sizes" : [ {
        "h" : 194,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 498
      } ],
      "display_url" : "pic.twitter.com\/ypC2Rb5sxc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758423898425745408",
  "in_reply_to_user_id" : 44184316,
  "text" : "@Matthiasiam Congrats on the baby, just make sure it never becomes a free mason and plans world domination https:\/\/t.co\/ypC2Rb5sxc",
  "id" : 758423898425745408,
  "created_at" : "2016-07-27 22:08:42 +0000",
  "in_reply_to_screen_name" : "Matthiasiam",
  "in_reply_to_user_id_str" : "44184316",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/5QzOOHLNUw",
      "expanded_url" : "https:\/\/twitter.com\/kennyv1919\/status\/758419875899604993",
      "display_url" : "twitter.com\/kennyv1919\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "758423557827235840",
  "text" : "RT @Matthiasiam: Baby Luna is still fetus Luna. She\u2019s such a tease. So close.  https:\/\/t.co\/5QzOOHLNUw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 85 ],
        "url" : "https:\/\/t.co\/5QzOOHLNUw",
        "expanded_url" : "https:\/\/twitter.com\/kennyv1919\/status\/758419875899604993",
        "display_url" : "twitter.com\/kennyv1919\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "758420506458546176",
    "text" : "Baby Luna is still fetus Luna. She\u2019s such a tease. So close.  https:\/\/t.co\/5QzOOHLNUw",
    "id" : 758420506458546176,
    "created_at" : "2016-07-27 21:55:14 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 758423557827235840,
  "created_at" : "2016-07-27 22:07:21 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "758423367246422016",
  "text" : "RT @BarbaraCorcoran: When it comes to hiring, the best people are honest + have lots of enthusiasm.\nI don't care about a resume- the right\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757921015221587969",
    "text" : "When it comes to hiring, the best people are honest + have lots of enthusiasm.\nI don't care about a resume- the right attitude always wins.",
    "id" : 757921015221587969,
    "created_at" : "2016-07-26 12:50:26 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 758423367246422016,
  "created_at" : "2016-07-27 22:06:36 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 0, 11 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "758376018054971393",
  "geo" : { },
  "id_str" : "758423150145122305",
  "in_reply_to_user_id" : 561775964,
  "text" : "@rockindigo I bet you that car ain't a 2000 Ford Explorer or a 4 by 4, lol",
  "id" : 758423150145122305,
  "in_reply_to_status_id" : 758376018054971393,
  "created_at" : "2016-07-27 22:05:44 +0000",
  "in_reply_to_screen_name" : "rockindigo",
  "in_reply_to_user_id_str" : "561775964",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757809025132007425",
  "text" : "RT @hannahbleau_: \"Cynicism is a refuge for cowards,\" Booker? Questioning intentions and horrid policies makes makes one cowardly? Really?\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DemsInPhilly",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757756768730673152",
    "text" : "\"Cynicism is a refuge for cowards,\" Booker? Questioning intentions and horrid policies makes makes one cowardly? Really? #DemsInPhilly",
    "id" : 757756768730673152,
    "created_at" : "2016-07-26 01:57:46 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 757809025132007425,
  "created_at" : "2016-07-26 05:25:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Donald J. Trump",
      "screen_name" : "realDonaldTrump",
      "indices" : [ 18, 34 ],
      "id_str" : "25073877",
      "id" : 25073877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757808870504878085",
  "text" : "RT @seanhannity: .@realDonaldTrump: \"If they were ever Trump emails instead of the DNC emails, it would have been front pg. in every paper\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Donald J. Trump",
        "screen_name" : "realDonaldTrump",
        "indices" : [ 1, 17 ],
        "id_str" : "25073877",
        "id" : 25073877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757783755234816001",
    "text" : ".@realDonaldTrump: \"If they were ever Trump emails instead of the DNC emails, it would have been front pg. in every paper in this country.\"",
    "id" : 757783755234816001,
    "created_at" : "2016-07-26 03:45:00 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 757808870504878085,
  "created_at" : "2016-07-26 05:24:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    }, {
      "name" : "Amanda Faye",
      "screen_name" : "heyamandafaye",
      "indices" : [ 34, 48 ],
      "id_str" : "120666850",
      "id" : 120666850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757808773352165376",
  "text" : "RT @Matthiasiam: Everyone go send @heyamandafaye the funniest cat videos you can find! Seems when she's laughing, it helps progress her lab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Amanda Faye",
        "screen_name" : "heyamandafaye",
        "indices" : [ 17, 31 ],
        "id_str" : "120666850",
        "id" : 120666850
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757760252724916224",
    "text" : "Everyone go send @heyamandafaye the funniest cat videos you can find! Seems when she's laughing, it helps progress her labor! Haha",
    "id" : 757760252724916224,
    "created_at" : "2016-07-26 02:11:37 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 757808773352165376,
  "created_at" : "2016-07-26 05:24:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "indices" : [ 3, 16 ],
      "id_str" : "138121596",
      "id" : 138121596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757283389489737728",
  "text" : "RT @martincallan: England v Pakistan: Alex Hales out but England in control on 98-1: Pakistan take the wicket of England opener... https:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/HljrvX3o8K",
        "expanded_url" : "http:\/\/bbc.in\/29Y4aTc",
        "display_url" : "bbc.in\/29Y4aTc"
      } ]
    },
    "geo" : { },
    "id_str" : "757283127408496640",
    "text" : "England v Pakistan: Alex Hales out but England in control on 98-1: Pakistan take the wicket of England opener... https:\/\/t.co\/HljrvX3o8K",
    "id" : 757283127408496640,
    "created_at" : "2016-07-24 18:35:41 +0000",
    "user" : {
      "name" : "Martin Callan",
      "screen_name" : "martincallan",
      "protected" : false,
      "id_str" : "138121596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759331950725332992\/QghaDvV6_normal.jpg",
      "id" : 138121596,
      "verified" : false
    }
  },
  "id" : 757283389489737728,
  "created_at" : "2016-07-24 18:36:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "indices" : [ 3, 19 ],
      "id_str" : "1356030014",
      "id" : 1356030014
    }, {
      "name" : "jack",
      "screen_name" : "jack",
      "indices" : [ 24, 29 ],
      "id_str" : "12",
      "id" : 12
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeMilo",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757283349140570112",
  "text" : "RT @LibertarianBlue: Hi @Jack! Got some great stories for you today fam. \uD83D\uDE18 Say, have you visited your LA offices recently? #FreeMilo #FreeN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jack",
        "screen_name" : "jack",
        "indices" : [ 3, 8 ],
        "id_str" : "12",
        "id" : 12
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeMilo",
        "indices" : [ 102, 111 ]
      }, {
        "text" : "FreeNero",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757274516691222528",
    "text" : "Hi @Jack! Got some great stories for you today fam. \uD83D\uDE18 Say, have you visited your LA offices recently? #FreeMilo #FreeNero",
    "id" : 757274516691222528,
    "created_at" : "2016-07-24 18:01:28 +0000",
    "user" : {
      "name" : "Allum Bokhari",
      "screen_name" : "LibertarianBlue",
      "protected" : false,
      "id_str" : "1356030014",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/821028721670967298\/j0XhnwCa_normal.jpg",
      "id" : 1356030014,
      "verified" : true
    }
  },
  "id" : 757283349140570112,
  "created_at" : "2016-07-24 18:36:34 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Retro",
      "screen_name" : "retrovgamer",
      "indices" : [ 3, 15 ],
      "id_str" : "3430966859",
      "id" : 3430966859
    }, {
      "name" : "Chris Fyvie",
      "screen_name" : "ckfyvie",
      "indices" : [ 17, 25 ],
      "id_str" : "354822908",
      "id" : 354822908
    }, {
      "name" : "PlutoCoffins",
      "screen_name" : "PlutoCoffins",
      "indices" : [ 26, 39 ],
      "id_str" : "726440150478147584",
      "id" : 726440150478147584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757283284741136384",
  "text" : "RT @retrovgamer: @ckfyvie @PlutoCoffins @GrathTheIrksome Because one day it may be your speech that they come to ban. #FreeMilo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chris Fyvie",
        "screen_name" : "ckfyvie",
        "indices" : [ 0, 8 ],
        "id_str" : "354822908",
        "id" : 354822908
      }, {
        "name" : "PlutoCoffins",
        "screen_name" : "PlutoCoffins",
        "indices" : [ 9, 22 ],
        "id_str" : "726440150478147584",
        "id" : 726440150478147584
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeMilo",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "757281316073250816",
    "geo" : { },
    "id_str" : "757282418248196096",
    "in_reply_to_user_id" : 354822908,
    "text" : "@ckfyvie @PlutoCoffins @GrathTheIrksome Because one day it may be your speech that they come to ban. #FreeMilo",
    "id" : 757282418248196096,
    "in_reply_to_status_id" : 757281316073250816,
    "created_at" : "2016-07-24 18:32:52 +0000",
    "in_reply_to_screen_name" : "ckfyvie",
    "in_reply_to_user_id_str" : "354822908",
    "user" : {
      "name" : "Retro",
      "screen_name" : "retrovgamer",
      "protected" : false,
      "id_str" : "3430966859",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634054441759412224\/N2rySSBR_normal.png",
      "id" : 3430966859,
      "verified" : false
    }
  },
  "id" : 757283284741136384,
  "created_at" : "2016-07-24 18:36:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757276956840820736\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/LvVp9d4Qlr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJjYKEWIAAco-Y.jpg",
      "id_str" : "757276954022256640",
      "id" : 757276954022256640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJjYKEWIAAco-Y.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/LvVp9d4Qlr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/PMYkbMSUqm",
      "expanded_url" : "http:\/\/engt.co\/2ami2rK",
      "display_url" : "engt.co\/2ami2rK"
    } ]
  },
  "geo" : { },
  "id_str" : "757283131779055617",
  "text" : "RT @engadget: NYC's next subway cars have WiFi and USB ports built-in https:\/\/t.co\/PMYkbMSUqm https:\/\/t.co\/LvVp9d4Qlr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/757276956840820736\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/LvVp9d4Qlr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CoJjYKEWIAAco-Y.jpg",
        "id_str" : "757276954022256640",
        "id" : 757276954022256640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CoJjYKEWIAAco-Y.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/LvVp9d4Qlr"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/PMYkbMSUqm",
        "expanded_url" : "http:\/\/engt.co\/2ami2rK",
        "display_url" : "engt.co\/2ami2rK"
      } ]
    },
    "geo" : { },
    "id_str" : "757276956840820736",
    "text" : "NYC's next subway cars have WiFi and USB ports built-in https:\/\/t.co\/PMYkbMSUqm https:\/\/t.co\/LvVp9d4Qlr",
    "id" : 757276956840820736,
    "created_at" : "2016-07-24 18:11:10 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 757283131779055617,
  "created_at" : "2016-07-24 18:35:42 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat: Lo.monroee",
      "screen_name" : "kvngshxtnigga__",
      "indices" : [ 12, 28 ],
      "id_str" : "425245948",
      "id" : 425245948
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/757282968557723650\/photo\/1",
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/t1FqPGKkBZ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CoJozcEXEAAGDtl.jpg",
      "id_str" : "757282920268763136",
      "id" : 757282920268763136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CoJozcEXEAAGDtl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t1FqPGKkBZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "755823198864826368",
  "geo" : { },
  "id_str" : "757282968557723650",
  "in_reply_to_user_id" : 2885079215,
  "text" : "@badgalxkay @kvngshxtnigga__ https:\/\/t.co\/t1FqPGKkBZ",
  "id" : 757282968557723650,
  "in_reply_to_status_id" : 755823198864826368,
  "created_at" : "2016-07-24 18:35:03 +0000",
  "in_reply_to_screen_name" : "GLAMJAWN",
  "in_reply_to_user_id_str" : "2885079215",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/nPsvDn0MF1",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/24\/star-trek-discovery-teaser\/",
      "display_url" : "engadget.com\/2016\/07\/24\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "757282436598431744",
  "text" : "RT @EmperorDarroux: 'Star Trek: Discovery' gets its first teaser at Comic-Con https:\/\/t.co\/nPsvDn0MF1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/nPsvDn0MF1",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/24\/star-trek-discovery-teaser\/",
        "display_url" : "engadget.com\/2016\/07\/24\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "757276409572188164",
    "text" : "'Star Trek: Discovery' gets its first teaser at Comic-Con https:\/\/t.co\/nPsvDn0MF1",
    "id" : 757276409572188164,
    "created_at" : "2016-07-24 18:09:00 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 757282436598431744,
  "created_at" : "2016-07-24 18:32:57 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nique\u2728",
      "screen_name" : "CallMe_Prettiee",
      "indices" : [ 3, 19 ],
      "id_str" : "332988160",
      "id" : 332988160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757282160160235520",
  "text" : "RT @CallMe_Prettiee: Bored\uD83D\uDE10",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "757280002173829120",
    "text" : "Bored\uD83D\uDE10",
    "id" : 757280002173829120,
    "created_at" : "2016-07-24 18:23:16 +0000",
    "user" : {
      "name" : "Nique\u2728",
      "screen_name" : "CallMe_Prettiee",
      "protected" : false,
      "id_str" : "332988160",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783892471516233729\/cvEtWFK5_normal.jpg",
      "id" : 332988160,
      "verified" : false
    }
  },
  "id" : 757282160160235520,
  "created_at" : "2016-07-24 18:31:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "757281924901638144",
  "text" : "I had Bucemi's Italian sub today and got excited",
  "id" : 757281924901638144,
  "created_at" : "2016-07-24 18:30:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754692930519138304\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/PgEk8l08ch",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnk1OARXYAAkIJx.jpg",
      "id_str" : "754692927268544512",
      "id" : 754692927268544512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnk1OARXYAAkIJx.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/PgEk8l08ch"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/ttdaHvM3g2",
      "expanded_url" : "http:\/\/engt.co\/29KIFKg",
      "display_url" : "engt.co\/29KIFKg"
    } ]
  },
  "geo" : { },
  "id_str" : "755154388885340160",
  "text" : "RT @engadget: Honda unveils first hybrid motor without heavy rare earth metals https:\/\/t.co\/ttdaHvM3g2 https:\/\/t.co\/PgEk8l08ch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754692930519138304\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/PgEk8l08ch",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cnk1OARXYAAkIJx.jpg",
        "id_str" : "754692927268544512",
        "id" : 754692927268544512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cnk1OARXYAAkIJx.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/PgEk8l08ch"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/ttdaHvM3g2",
        "expanded_url" : "http:\/\/engt.co\/29KIFKg",
        "display_url" : "engt.co\/29KIFKg"
      } ]
    },
    "geo" : { },
    "id_str" : "754692930519138304",
    "text" : "Honda unveils first hybrid motor without heavy rare earth metals https:\/\/t.co\/ttdaHvM3g2 https:\/\/t.co\/PgEk8l08ch",
    "id" : 754692930519138304,
    "created_at" : "2016-07-17 15:03:10 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 755154388885340160,
  "created_at" : "2016-07-18 21:36:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754421172943613953\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/59jEAu2f1P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cng-Dl6WIAAALfL.jpg",
      "id_str" : "754421169021919232",
      "id" : 754421169021919232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cng-Dl6WIAAALfL.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/59jEAu2f1P"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/5jSEtLBWSy",
      "expanded_url" : "http:\/\/engt.co\/29KL1mh",
      "display_url" : "engt.co\/29KL1mh"
    } ]
  },
  "geo" : { },
  "id_str" : "755154189559402497",
  "text" : "RT @engadget: Exploring the limits of good taste with Xbox Design Lab https:\/\/t.co\/5jSEtLBWSy https:\/\/t.co\/59jEAu2f1P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754421172943613953\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/59jEAu2f1P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cng-Dl6WIAAALfL.jpg",
        "id_str" : "754421169021919232",
        "id" : 754421169021919232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cng-Dl6WIAAALfL.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/59jEAu2f1P"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/5jSEtLBWSy",
        "expanded_url" : "http:\/\/engt.co\/29KL1mh",
        "display_url" : "engt.co\/29KL1mh"
      } ]
    },
    "geo" : { },
    "id_str" : "754421172943613953",
    "text" : "Exploring the limits of good taste with Xbox Design Lab https:\/\/t.co\/5jSEtLBWSy https:\/\/t.co\/59jEAu2f1P",
    "id" : 754421172943613953,
    "created_at" : "2016-07-16 21:03:18 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 755154189559402497,
  "created_at" : "2016-07-18 21:36:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754512876266807298\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/F8lxEFk2NS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CniRdZ2WEAQ7IoR.jpg",
      "id_str" : "754512871925616644",
      "id" : 754512871925616644,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CniRdZ2WEAQ7IoR.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/F8lxEFk2NS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/gdgs2qfaRh",
      "expanded_url" : "http:\/\/engt.co\/2a7e5tG",
      "display_url" : "engt.co\/2a7e5tG"
    } ]
  },
  "geo" : { },
  "id_str" : "755153774583349249",
  "text" : "RT @engadget: Ben Heck tears down the legendary Nintendo PlayStation https:\/\/t.co\/gdgs2qfaRh https:\/\/t.co\/F8lxEFk2NS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/754512876266807298\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/F8lxEFk2NS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CniRdZ2WEAQ7IoR.jpg",
        "id_str" : "754512871925616644",
        "id" : 754512871925616644,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CniRdZ2WEAQ7IoR.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/F8lxEFk2NS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/gdgs2qfaRh",
        "expanded_url" : "http:\/\/engt.co\/2a7e5tG",
        "display_url" : "engt.co\/2a7e5tG"
      } ]
    },
    "geo" : { },
    "id_str" : "754512876266807298",
    "text" : "Ben Heck tears down the legendary Nintendo PlayStation https:\/\/t.co\/gdgs2qfaRh https:\/\/t.co\/F8lxEFk2NS",
    "id" : 754512876266807298,
    "created_at" : "2016-07-17 03:07:42 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 755153774583349249,
  "created_at" : "2016-07-18 21:34:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mallory Everton",
      "screen_name" : "malruthon",
      "indices" : [ 20, 30 ],
      "id_str" : "315592222",
      "id" : 315592222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "755153631972917250",
  "text" : "I would have to say @malruthon is my favorite female comedian. Her quirky and over the top personality is like comedic sunshine on the show",
  "id" : 755153631972917250,
  "created_at" : "2016-07-18 21:33:50 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/headtalker.com\" rel=\"nofollow\"\u003EHeadTalker\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/fB3P5Q72Ld",
      "expanded_url" : "http:\/\/andsocialrew.net",
      "display_url" : "andsocialrew.net"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Vd9WrJCnJE",
      "expanded_url" : "https:\/\/hdtk.co\/pcClz",
      "display_url" : "hdtk.co\/pcClz"
    } ]
  },
  "geo" : { },
  "id_str" : "754707260673298432",
  "text" : "Join the all in one social network, download on Google Play or visit https:\/\/t.co\/fB3P5Q72Ld https:\/\/t.co\/Vd9WrJCnJE",
  "id" : 754707260673298432,
  "created_at" : "2016-07-17 16:00:07 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753178313766690817",
  "text" : "RT @hannahbleau_: Bernie Sanders rails against the \"1 percenters\" while standing next to and endorsing one. Irony.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752887312950792197",
    "text" : "Bernie Sanders rails against the \"1 percenters\" while standing next to and endorsing one. Irony.",
    "id" : 752887312950792197,
    "created_at" : "2016-07-12 15:28:18 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 753178313766690817,
  "created_at" : "2016-07-13 10:44:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752900921697370112\/photo\/1",
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/1PvU5fA2Ft",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLXZZ4WcAAurVt.jpg",
      "id_str" : "752900919168233472",
      "id" : 752900919168233472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLXZZ4WcAAurVt.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/1PvU5fA2Ft"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/RDGhu6VFaY",
      "expanded_url" : "http:\/\/engt.co\/29Uhn3p",
      "display_url" : "engt.co\/29Uhn3p"
    } ]
  },
  "geo" : { },
  "id_str" : "753178279893405696",
  "text" : "RT @engadget: Honda unveils first hybrid motor without heavy rare earth metals https:\/\/t.co\/RDGhu6VFaY https:\/\/t.co\/1PvU5fA2Ft",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752900921697370112\/photo\/1",
        "indices" : [ 89, 112 ],
        "url" : "https:\/\/t.co\/1PvU5fA2Ft",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLXZZ4WcAAurVt.jpg",
        "id_str" : "752900919168233472",
        "id" : 752900919168233472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLXZZ4WcAAurVt.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/1PvU5fA2Ft"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/RDGhu6VFaY",
        "expanded_url" : "http:\/\/engt.co\/29Uhn3p",
        "display_url" : "engt.co\/29Uhn3p"
      } ]
    },
    "geo" : { },
    "id_str" : "752900921697370112",
    "text" : "Honda unveils first hybrid motor without heavy rare earth metals https:\/\/t.co\/RDGhu6VFaY https:\/\/t.co\/1PvU5fA2Ft",
    "id" : 752900921697370112,
    "created_at" : "2016-07-12 16:22:22 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 753178279893405696,
  "created_at" : "2016-07-13 10:44:29 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752643161843990528\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/8jBA0f2bzT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnHs90PWEAYRLg1.jpg",
      "id_str" : "752643159486763014",
      "id" : 752643159486763014,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnHs90PWEAYRLg1.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8jBA0f2bzT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/MtSbgvvXZD",
      "expanded_url" : "http:\/\/engt.co\/29wKy7c",
      "display_url" : "engt.co\/29wKy7c"
    } ]
  },
  "geo" : { },
  "id_str" : "753178096614899712",
  "text" : "RT @engadget: 'Pok\u00E9mon Go' on iOS is digging deep into linked Google accounts https:\/\/t.co\/MtSbgvvXZD https:\/\/t.co\/8jBA0f2bzT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752643161843990528\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/8jBA0f2bzT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnHs90PWEAYRLg1.jpg",
        "id_str" : "752643159486763014",
        "id" : 752643159486763014,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnHs90PWEAYRLg1.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/8jBA0f2bzT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/MtSbgvvXZD",
        "expanded_url" : "http:\/\/engt.co\/29wKy7c",
        "display_url" : "engt.co\/29wKy7c"
      } ]
    },
    "geo" : { },
    "id_str" : "752643161843990528",
    "text" : "'Pok\u00E9mon Go' on iOS is digging deep into linked Google accounts https:\/\/t.co\/MtSbgvvXZD https:\/\/t.co\/8jBA0f2bzT",
    "id" : 752643161843990528,
    "created_at" : "2016-07-11 23:18:07 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 753178096614899712,
  "created_at" : "2016-07-13 10:43:46 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "indices" : [ 3, 15 ],
      "id_str" : "41634520",
      "id" : 41634520
    }, {
      "name" : "Newt Gingrich",
      "screen_name" : "newtgingrich",
      "indices" : [ 18, 31 ],
      "id_str" : "20713061",
      "id" : 20713061
    }, {
      "name" : "President Trump",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "822215679726100480",
      "id" : 822215679726100480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753178006777163777",
  "text" : "RT @seanhannity: .@newtgingrich: \"@POTUS' relentless failure in 7.5 years in the area of race relations is in some ways the saddest part of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newt Gingrich",
        "screen_name" : "newtgingrich",
        "indices" : [ 1, 14 ],
        "id_str" : "20713061",
        "id" : 20713061
      }, {
        "name" : "President Trump",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "822215679726100480",
        "id" : 822215679726100480
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752687637815816193",
    "text" : ".@newtgingrich: \"@POTUS' relentless failure in 7.5 years in the area of race relations is in some ways the saddest part of his admin.\"",
    "id" : 752687637815816193,
    "created_at" : "2016-07-12 02:14:51 +0000",
    "user" : {
      "name" : "Sean Hannity",
      "screen_name" : "seanhannity",
      "protected" : false,
      "id_str" : "41634520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000709183776\/6273b31aa1836ac86426478aaa82a597_normal.jpeg",
      "id" : 41634520,
      "verified" : true
    }
  },
  "id" : 753178006777163777,
  "created_at" : "2016-07-13 10:43:24 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "indices" : [ 3, 14 ],
      "id_str" : "242435607",
      "id" : 242435607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177901240057856",
  "text" : "RT @Anba_Ermia: And they overcame him by the blood of the Lamb and by the word of their testimony, and they did not love their lives to the\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752741935807430656",
    "text" : "And they overcame him by the blood of the Lamb and by the word of their testimony, and they did not love their lives to the death.",
    "id" : 752741935807430656,
    "created_at" : "2016-07-12 05:50:37 +0000",
    "user" : {
      "name" : "Anba Ermia",
      "screen_name" : "Anba_Ermia",
      "protected" : false,
      "id_str" : "242435607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3580148862\/4cf7cba83bbd8d24e3a9a21f82ebc51e_normal.jpeg",
      "id" : 242435607,
      "verified" : false
    }
  },
  "id" : 753177901240057856,
  "created_at" : "2016-07-13 10:42:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177675125096448",
  "text" : "RT @hannahbleau_: I'm watching two different hearings. Democrats: Guns are evil! Repubs: Why is Hillary above the law? AG Lynch: Idk LOLZ.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LynchHearing",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752882410635694080",
    "text" : "I'm watching two different hearings. Democrats: Guns are evil! Repubs: Why is Hillary above the law? AG Lynch: Idk LOLZ. #LynchHearing",
    "id" : 752882410635694080,
    "created_at" : "2016-07-12 15:08:49 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 753177675125096448,
  "created_at" : "2016-07-13 10:42:05 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752905134099853313\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/J5vkWgOg0u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLbOiIWAAAz-Al.jpg",
      "id_str" : "752905130450747392",
      "id" : 752905130450747392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLbOiIWAAAz-Al.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/J5vkWgOg0u"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/0qAgBptyf8",
      "expanded_url" : "http:\/\/engt.co\/29AQLW3",
      "display_url" : "engt.co\/29AQLW3"
    } ]
  },
  "geo" : { },
  "id_str" : "753177636025827329",
  "text" : "RT @engadget: Stargazers recently observed a supermassive black hole destroying a star https:\/\/t.co\/0qAgBptyf8 https:\/\/t.co\/J5vkWgOg0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752905134099853313\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/J5vkWgOg0u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnLbOiIWAAAz-Al.jpg",
        "id_str" : "752905130450747392",
        "id" : 752905130450747392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnLbOiIWAAAz-Al.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/J5vkWgOg0u"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/0qAgBptyf8",
        "expanded_url" : "http:\/\/engt.co\/29AQLW3",
        "display_url" : "engt.co\/29AQLW3"
      } ]
    },
    "geo" : { },
    "id_str" : "752905134099853313",
    "text" : "Stargazers recently observed a supermassive black hole destroying a star https:\/\/t.co\/0qAgBptyf8 https:\/\/t.co\/J5vkWgOg0u",
    "id" : 752905134099853313,
    "created_at" : "2016-07-12 16:39:06 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 753177636025827329,
  "created_at" : "2016-07-13 10:41:56 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752994996496850945\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/mclRkhVgOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMs9PjXYAAc57g.jpg",
      "id_str" : "752994993359511552",
      "id" : 752994993359511552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMs9PjXYAAc57g.jpg",
      "sizes" : [ {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/mclRkhVgOK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/h3krUn9p7k",
      "expanded_url" : "http:\/\/engt.co\/29zXGJ3",
      "display_url" : "engt.co\/29zXGJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "753177455838498816",
  "text" : "RT @engadget: Sega Saturn copy protection gets cracked two decades later https:\/\/t.co\/h3krUn9p7k https:\/\/t.co\/mclRkhVgOK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752994996496850945\/photo\/1",
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/mclRkhVgOK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnMs9PjXYAAc57g.jpg",
        "id_str" : "752994993359511552",
        "id" : 752994993359511552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnMs9PjXYAAc57g.jpg",
        "sizes" : [ {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/mclRkhVgOK"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/h3krUn9p7k",
        "expanded_url" : "http:\/\/engt.co\/29zXGJ3",
        "display_url" : "engt.co\/29zXGJ3"
      } ]
    },
    "geo" : { },
    "id_str" : "752994996496850945",
    "text" : "Sega Saturn copy protection gets cracked two decades later https:\/\/t.co\/h3krUn9p7k https:\/\/t.co\/mclRkhVgOK",
    "id" : 752994996496850945,
    "created_at" : "2016-07-12 22:36:11 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 753177455838498816,
  "created_at" : "2016-07-13 10:41:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177363807109120",
  "text" : "RT @lorenridinger: \"Sometimes we need to be hurt in order to grow. We must lose in order to gain. Sometimes some lessons are learned best t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753046363626151936",
    "text" : "\"Sometimes we need to be hurt in order to grow. We must lose in order to gain. Sometimes some lessons are learned best through pain.\"",
    "id" : 753046363626151936,
    "created_at" : "2016-07-13 02:00:18 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 753177363807109120,
  "created_at" : "2016-07-13 10:40:51 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177335742988288",
  "text" : "RT @Matthiasiam: Crazy how often I people try to scam me by calling me and phishing for my info. Never give any info to anyone unless you c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753050959605968899",
    "text" : "Crazy how often I people try to scam me by calling me and phishing for my info. Never give any info to anyone unless you can verify their ID",
    "id" : 753050959605968899,
    "created_at" : "2016-07-13 02:18:34 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 753177335742988288,
  "created_at" : "2016-07-13 10:40:44 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SharkTank",
      "indices" : [ 30, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177147460681728",
  "text" : "RT @BarbaraCorcoran: Watching #SharkTank reruns + thinking: if you are getting attacked by us sharks in the tank, show me how well you can\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SharkTank",
        "indices" : [ 9, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753024948092952576",
    "text" : "Watching #SharkTank reruns + thinking: if you are getting attacked by us sharks in the tank, show me how well you can bounce back!",
    "id" : 753024948092952576,
    "created_at" : "2016-07-13 00:35:12 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 753177147460681728,
  "created_at" : "2016-07-13 10:39:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/753029217449709568\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/1A888ets0z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNME72UEAAWcOR.jpg",
      "id_str" : "753029210369691648",
      "id" : 753029210369691648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNME72UEAAWcOR.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/1A888ets0z"
    } ],
    "hashtags" : [ {
      "text" : "DallasStrong",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753177101440778240",
  "text" : "RT @tedcruz: Five seats were reserved for the five fallen officers at today's memorial service. #DallasStrong https:\/\/t.co\/1A888ets0z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tedcruz\/status\/753029217449709568\/photo\/1",
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/1A888ets0z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnNME72UEAAWcOR.jpg",
        "id_str" : "753029210369691648",
        "id" : 753029210369691648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnNME72UEAAWcOR.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/1A888ets0z"
      } ],
      "hashtags" : [ {
        "text" : "DallasStrong",
        "indices" : [ 83, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753029217449709568",
    "text" : "Five seats were reserved for the five fallen officers at today's memorial service. #DallasStrong https:\/\/t.co\/1A888ets0z",
    "id" : 753029217449709568,
    "created_at" : "2016-07-13 00:52:10 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 753177101440778240,
  "created_at" : "2016-07-13 10:39:48 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/oS5YyxHyR8",
      "expanded_url" : "http:\/\/mashable.com\/2016\/07\/13\/theresa-may-snoopers-charter-privacy-bill\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
      "display_url" : "mashable.com\/2016\/07\/13\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "753176805293645824",
  "text" : "RT @EmperorDarroux: Britain has its next prime minister to thank for mass surveillance bill https:\/\/t.co\/oS5YyxHyR8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/oS5YyxHyR8",
        "expanded_url" : "http:\/\/mashable.com\/2016\/07\/13\/theresa-may-snoopers-charter-privacy-bill\/?utm_campaign=Mash-Prod-RSS-Feedburner-All-Partial&utm_cid=Mash-Prod-RSS-Feedburner-All-Partial",
        "display_url" : "mashable.com\/2016\/07\/13\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "753165305833066496",
    "text" : "Britain has its next prime minister to thank for mass surveillance bill https:\/\/t.co\/oS5YyxHyR8",
    "id" : 753165305833066496,
    "created_at" : "2016-07-13 09:52:56 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 753176805293645824,
  "created_at" : "2016-07-13 10:38:38 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "indices" : [ 3, 14 ],
      "id_str" : "1132090693",
      "id" : 1132090693
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/753162117398794240\/photo\/1",
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/KshB6czaTa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnPE9A7WgAEbpzC.jpg",
      "id_str" : "753162115201007617",
      "id" : 753162115201007617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnPE9A7WgAEbpzC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 571
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KshB6czaTa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753176612179443712",
  "text" : "RT @Globe_Pics: The coolest duck ever!! https:\/\/t.co\/KshB6czaTa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Globe_Pics\/status\/753162117398794240\/photo\/1",
        "indices" : [ 24, 47 ],
        "url" : "https:\/\/t.co\/KshB6czaTa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnPE9A7WgAEbpzC.jpg",
        "id_str" : "753162115201007617",
        "id" : 753162115201007617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnPE9A7WgAEbpzC.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 571
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KshB6czaTa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753162117398794240",
    "text" : "The coolest duck ever!! https:\/\/t.co\/KshB6czaTa",
    "id" : 753162117398794240,
    "created_at" : "2016-07-13 09:40:16 +0000",
    "user" : {
      "name" : "Globe Pics",
      "screen_name" : "Globe_Pics",
      "protected" : false,
      "id_str" : "1132090693",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538457900281126912\/tMIRoIp7_normal.jpeg",
      "id" : 1132090693,
      "verified" : false
    }
  },
  "id" : 753176612179443712,
  "created_at" : "2016-07-13 10:37:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/753154707879780352\/photo\/1",
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/yev4tEOxfr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnO-NvRXYAEdl2v.jpg",
      "id_str" : "753154705937883137",
      "id" : 753154705937883137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnO-NvRXYAEdl2v.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/yev4tEOxfr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753176551030722561",
  "text" : "RT @rockindigo: The difference between AMD and NVIDIA https:\/\/t.co\/yev4tEOxfr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/753154707879780352\/photo\/1",
        "indices" : [ 38, 61 ],
        "url" : "https:\/\/t.co\/yev4tEOxfr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnO-NvRXYAEdl2v.jpg",
        "id_str" : "753154705937883137",
        "id" : 753154705937883137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnO-NvRXYAEdl2v.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/yev4tEOxfr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753154707879780352",
    "text" : "The difference between AMD and NVIDIA https:\/\/t.co\/yev4tEOxfr",
    "id" : 753154707879780352,
    "created_at" : "2016-07-13 09:10:49 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 753176551030722561,
  "created_at" : "2016-07-13 10:37:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Athletes For God",
      "screen_name" : "AthIetesForGod",
      "indices" : [ 3, 18 ],
      "id_str" : "1345577827",
      "id" : 1345577827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753176213481553920",
  "text" : "RT @AthIetesForGod: No matter what accomplishments you make, somebody helped you. -Althea Gibson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753157364749139972",
    "text" : "No matter what accomplishments you make, somebody helped you. -Althea Gibson",
    "id" : 753157364749139972,
    "created_at" : "2016-07-13 09:21:23 +0000",
    "user" : {
      "name" : "Athletes For God",
      "screen_name" : "AthIetesForGod",
      "protected" : false,
      "id_str" : "1345577827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3510817690\/f6db93b5313678fdefca72d291c3fa14_normal.png",
      "id" : 1345577827,
      "verified" : false
    }
  },
  "id" : 753176213481553920,
  "created_at" : "2016-07-13 10:36:17 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Style Details",
      "screen_name" : "StyleDetails",
      "indices" : [ 3, 16 ],
      "id_str" : "582753822",
      "id" : 582753822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/gJLokOqB0N",
      "expanded_url" : "http:\/\/vine.co\/v\/MqmDdKWrdTX",
      "display_url" : "vine.co\/v\/MqmDdKWrdTX"
    } ]
  },
  "geo" : { },
  "id_str" : "753175648789733376",
  "text" : "RT @StyleDetails: She's so loud! https:\/\/t.co\/gJLokOqB0N",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 38 ],
        "url" : "https:\/\/t.co\/gJLokOqB0N",
        "expanded_url" : "http:\/\/vine.co\/v\/MqmDdKWrdTX",
        "display_url" : "vine.co\/v\/MqmDdKWrdTX"
      } ]
    },
    "geo" : { },
    "id_str" : "753174833836519424",
    "text" : "She's so loud! https:\/\/t.co\/gJLokOqB0N",
    "id" : 753174833836519424,
    "created_at" : "2016-07-13 10:30:48 +0000",
    "user" : {
      "name" : "Style Details",
      "screen_name" : "StyleDetails",
      "protected" : false,
      "id_str" : "582753822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659028387147616256\/QLCOuOTT_normal.jpg",
      "id" : 582753822,
      "verified" : false
    }
  },
  "id" : 753175648789733376,
  "created_at" : "2016-07-13 10:34:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "indices" : [ 3, 14 ],
      "id_str" : "74998076",
      "id" : 74998076
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RedefineSuccess",
      "indices" : [ 59, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753175183221981184",
  "text" : "RT @Eniolasays: We all want a good life but we all need to #RedefineSuccess",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RedefineSuccess",
        "indices" : [ 43, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "753170598696812545",
    "text" : "We all want a good life but we all need to #RedefineSuccess",
    "id" : 753170598696812545,
    "created_at" : "2016-07-13 10:13:58 +0000",
    "user" : {
      "name" : "Foodie",
      "screen_name" : "Eniolasays",
      "protected" : false,
      "id_str" : "74998076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753409111593783296\/cXsDNrTq_normal.jpg",
      "id" : 74998076,
      "verified" : false
    }
  },
  "id" : 753175183221981184,
  "created_at" : "2016-07-13 10:32:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "indices" : [ 3, 12 ],
      "id_str" : "10971502",
      "id" : 10971502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/2HNAFztZzR",
      "expanded_url" : "http:\/\/bit.ly\/29InBBU",
      "display_url" : "bit.ly\/29InBBU"
    } ]
  },
  "geo" : { },
  "id_str" : "753175168969760768",
  "text" : "RT @FXStefan: EUR\/USD \u2013 Euro Remains Subdued as Markets Look for Cues: EUR\/USD has posted small gains on We... https:\/\/t.co\/2HNAFztZzR #for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "forex",
        "indices" : [ 121, 127 ]
      }, {
        "text" : "trading",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 120 ],
        "url" : "https:\/\/t.co\/2HNAFztZzR",
        "expanded_url" : "http:\/\/bit.ly\/29InBBU",
        "display_url" : "bit.ly\/29InBBU"
      } ]
    },
    "geo" : { },
    "id_str" : "753170581818789888",
    "text" : "EUR\/USD \u2013 Euro Remains Subdued as Markets Look for Cues: EUR\/USD has posted small gains on We... https:\/\/t.co\/2HNAFztZzR #forex #trading",
    "id" : 753170581818789888,
    "created_at" : "2016-07-13 10:13:54 +0000",
    "user" : {
      "name" : "Stefan Stredak",
      "screen_name" : "FXStefan",
      "protected" : false,
      "id_str" : "10971502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430427252023517184\/UWcMSlCc_normal.jpeg",
      "id" : 10971502,
      "verified" : false
    }
  },
  "id" : 753175168969760768,
  "created_at" : "2016-07-13 10:32:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "753175128008261632",
  "text" : "My views on Putin's character changed 360 degrees after the new laws he made that threaten freedom of speech. I don't even know now!",
  "id" : 753175128008261632,
  "created_at" : "2016-07-13 10:31:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "indices" : [ 3, 18 ],
      "id_str" : "16372759",
      "id" : 16372759
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/WcEHijGYEh",
      "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/11\/dwarf-planet-beyond-neptune-pluto\/",
      "display_url" : "engadget.com\/2016\/07\/11\/dwa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "752618517854318592",
  "text" : "RT @EmperorDarroux: Hawaiian telescope spots a new dwarf planet beyond Neptune https:\/\/t.co\/WcEHijGYEh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/WcEHijGYEh",
        "expanded_url" : "https:\/\/www.engadget.com\/2016\/07\/11\/dwarf-planet-beyond-neptune-pluto\/",
        "display_url" : "engadget.com\/2016\/07\/11\/dwa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "752618163343241216",
    "text" : "Hawaiian telescope spots a new dwarf planet beyond Neptune https:\/\/t.co\/WcEHijGYEh",
    "id" : 752618163343241216,
    "created_at" : "2016-07-11 21:38:47 +0000",
    "user" : {
      "name" : "HRH Emperor Darroux",
      "screen_name" : "EmperorDarroux",
      "protected" : false,
      "id_str" : "16372759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2383204283\/bmob54r5du0icpu503wg_normal.jpeg",
      "id" : 16372759,
      "verified" : false
    }
  },
  "id" : 752618517854318592,
  "created_at" : "2016-07-11 21:40:12 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "indices" : [ 3, 19 ],
      "id_str" : "36728196",
      "id" : 36728196
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617870601908224",
  "text" : "RT @BarbaraCorcoran: Put your business on a budget and put away a percentage of your revenue towards savings for strategic investments late\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752504065339383809",
    "text" : "Put your business on a budget and put away a percentage of your revenue towards savings for strategic investments later. You\u2019ll thank me!",
    "id" : 752504065339383809,
    "created_at" : "2016-07-11 14:05:24 +0000",
    "user" : {
      "name" : "Barbara Corcoran",
      "screen_name" : "BarbaraCorcoran",
      "protected" : false,
      "id_str" : "36728196",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547109138434498561\/vAqmK5Ac_normal.jpeg",
      "id" : 36728196,
      "verified" : true
    }
  },
  "id" : 752617870601908224,
  "created_at" : "2016-07-11 21:37:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "indices" : [ 3, 15 ],
      "id_str" : "44184316",
      "id" : 44184316
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617727383265280",
  "text" : "RT @Matthiasiam: Hopefully Nintendo now recognizes the value of their IP over their hardware.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752536368924897280",
    "text" : "Hopefully Nintendo now recognizes the value of their IP over their hardware.",
    "id" : 752536368924897280,
    "created_at" : "2016-07-11 16:13:46 +0000",
    "user" : {
      "name" : "Matth|as",
      "screen_name" : "Matthiasiam",
      "protected" : false,
      "id_str" : "44184316",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788553825489604608\/uVr9IBNF_normal.jpg",
      "id" : 44184316,
      "verified" : true
    }
  },
  "id" : 752617727383265280,
  "created_at" : "2016-07-11 21:37:03 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752337870573232128\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/CgKdbkpett",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnDXTisWgAAjyiv.jpg",
      "id_str" : "752337868501188608",
      "id" : 752337868501188608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnDXTisWgAAjyiv.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/CgKdbkpett"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/nevGJ837xy",
      "expanded_url" : "http:\/\/engt.co\/29O2EqN",
      "display_url" : "engt.co\/29O2EqN"
    } ]
  },
  "geo" : { },
  "id_str" : "752617591957549056",
  "text" : "RT @engadget: Mercedes to show its Tesla-fighting electric sedan in September https:\/\/t.co\/nevGJ837xy https:\/\/t.co\/CgKdbkpett",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752337870573232128\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/CgKdbkpett",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnDXTisWgAAjyiv.jpg",
        "id_str" : "752337868501188608",
        "id" : 752337868501188608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnDXTisWgAAjyiv.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/CgKdbkpett"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/nevGJ837xy",
        "expanded_url" : "http:\/\/engt.co\/29O2EqN",
        "display_url" : "engt.co\/29O2EqN"
      } ]
    },
    "geo" : { },
    "id_str" : "752337870573232128",
    "text" : "Mercedes to show its Tesla-fighting electric sedan in September https:\/\/t.co\/nevGJ837xy https:\/\/t.co\/CgKdbkpett",
    "id" : 752337870573232128,
    "created_at" : "2016-07-11 03:05:00 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 752617591957549056,
  "created_at" : "2016-07-11 21:36:31 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752237167322292224\/photo\/1",
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/L6C42L68SZ",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CnB7txSWYAAM3Ix.jpg",
      "id_str" : "752237164025503744",
      "id" : 752237164025503744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CnB7txSWYAAM3Ix.jpg",
      "sizes" : [ {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 360,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/L6C42L68SZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/8D18ZNgQdA",
      "expanded_url" : "http:\/\/engt.co\/29GcFUe",
      "display_url" : "engt.co\/29GcFUe"
    } ]
  },
  "geo" : { },
  "id_str" : "752617509522636800",
  "text" : "RT @engadget: Researchers discover new exoplanet orbiting triple suns https:\/\/t.co\/8D18ZNgQdA https:\/\/t.co\/L6C42L68SZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752237167322292224\/photo\/1",
        "indices" : [ 80, 103 ],
        "url" : "https:\/\/t.co\/L6C42L68SZ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CnB7txSWYAAM3Ix.jpg",
        "id_str" : "752237164025503744",
        "id" : 752237164025503744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CnB7txSWYAAM3Ix.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/L6C42L68SZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/8D18ZNgQdA",
        "expanded_url" : "http:\/\/engt.co\/29GcFUe",
        "display_url" : "engt.co\/29GcFUe"
      } ]
    },
    "geo" : { },
    "id_str" : "752237167322292224",
    "text" : "Researchers discover new exoplanet orbiting triple suns https:\/\/t.co\/8D18ZNgQdA https:\/\/t.co\/L6C42L68SZ",
    "id" : 752237167322292224,
    "created_at" : "2016-07-10 20:24:51 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 752617509522636800,
  "created_at" : "2016-07-11 21:36:11 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617314797879296",
  "text" : "RT @lorenridinger: \u201CYou must not give up in the middle of the journey. May you have grace to travel onward.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752155651229515777",
    "text" : "\u201CYou must not give up in the middle of the journey. May you have grace to travel onward.\u201D",
    "id" : 752155651229515777,
    "created_at" : "2016-07-10 15:00:56 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 752617314797879296,
  "created_at" : "2016-07-11 21:35:25 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752141336371924992\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/bsOT8ITCdN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAkjuKXgAAhVp8.jpg",
      "id_str" : "752141333876408320",
      "id" : 752141333876408320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAkjuKXgAAhVp8.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/bsOT8ITCdN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/OorsaJp5es",
      "expanded_url" : "http:\/\/engt.co\/29MnR4z",
      "display_url" : "engt.co\/29MnR4z"
    } ]
  },
  "geo" : { },
  "id_str" : "752617249660346369",
  "text" : "RT @engadget: Inhabitat's Week in Green: A modular airplane, and more! https:\/\/t.co\/OorsaJp5es https:\/\/t.co\/bsOT8ITCdN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/752141336371924992\/photo\/1",
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/bsOT8ITCdN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CnAkjuKXgAAhVp8.jpg",
        "id_str" : "752141333876408320",
        "id" : 752141333876408320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CnAkjuKXgAAhVp8.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/bsOT8ITCdN"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/OorsaJp5es",
        "expanded_url" : "http:\/\/engt.co\/29MnR4z",
        "display_url" : "engt.co\/29MnR4z"
      } ]
    },
    "geo" : { },
    "id_str" : "752141336371924992",
    "text" : "Inhabitat's Week in Green: A modular airplane, and more! https:\/\/t.co\/OorsaJp5es https:\/\/t.co\/bsOT8ITCdN",
    "id" : 752141336371924992,
    "created_at" : "2016-07-10 14:04:03 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 752617249660346369,
  "created_at" : "2016-07-11 21:35:09 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617208086396929",
  "text" : "RT @lorenridinger: \u201CIn everyday life, a blessed act of saying \u2018hello, a smile, word of encouragement\u2026\u2019 can uplift someone spirit.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "752110300560814080",
    "text" : "\u201CIn everyday life, a blessed act of saying \u2018hello, a smile, word of encouragement\u2026\u2019 can uplift someone spirit.\u201D",
    "id" : 752110300560814080,
    "created_at" : "2016-07-10 12:00:43 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 752617208086396929,
  "created_at" : "2016-07-11 21:35:00 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake",
      "screen_name" : "WilkyJake",
      "indices" : [ 3, 13 ],
      "id_str" : "1212916340",
      "id" : 1212916340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617097683927040",
  "text" : "RT @WilkyJake: If it's real, you'll play the old Pok\u00E9mon on Game Boy Advance &amp; actually trade\/battle me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751995974906621953",
    "text" : "If it's real, you'll play the old Pok\u00E9mon on Game Boy Advance &amp; actually trade\/battle me.",
    "id" : 751995974906621953,
    "created_at" : "2016-07-10 04:26:26 +0000",
    "user" : {
      "name" : "Jake",
      "screen_name" : "WilkyJake",
      "protected" : false,
      "id_str" : "1212916340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/826681591606833152\/CsjcFRI1_normal.jpg",
      "id" : 1212916340,
      "verified" : false
    }
  },
  "id" : 752617097683927040,
  "created_at" : "2016-07-11 21:34:33 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ltsCharizard\/status\/533024566017531904\/photo\/1",
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/kyA6SDanae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B2WvAM7CcAAdoeV.jpg",
      "id_str" : "533024548916981760",
      "id" : 533024548916981760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2WvAM7CcAAdoeV.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kyA6SDanae"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752617038477135876",
  "text" : "RT @BestGamezUp: Pokeball Cake with Cupcakes https:\/\/t.co\/kyA6SDanae",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ltsCharizard\/status\/533024566017531904\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/kyA6SDanae",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B2WvAM7CcAAdoeV.jpg",
        "id_str" : "533024548916981760",
        "id" : 533024548916981760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B2WvAM7CcAAdoeV.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kyA6SDanae"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751949130575020032",
    "text" : "Pokeball Cake with Cupcakes https:\/\/t.co\/kyA6SDanae",
    "id" : 751949130575020032,
    "created_at" : "2016-07-10 01:20:17 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 752617038477135876,
  "created_at" : "2016-07-11 21:34:19 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/751933180412850176\/photo\/1",
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/nIi4Xv8qJn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm9nPfaWYAA9uox.jpg",
      "id_str" : "751933178621878272",
      "id" : 751933178621878272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm9nPfaWYAA9uox.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/nIi4Xv8qJn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "752616998320934912",
  "text" : "RT @rockindigo: Fighting air pollution through cars: Level Germany! https:\/\/t.co\/nIi4Xv8qJn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/751933180412850176\/photo\/1",
        "indices" : [ 52, 75 ],
        "url" : "https:\/\/t.co\/nIi4Xv8qJn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm9nPfaWYAA9uox.jpg",
        "id_str" : "751933178621878272",
        "id" : 751933178621878272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm9nPfaWYAA9uox.jpg",
        "sizes" : [ {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/nIi4Xv8qJn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751933180412850176",
    "text" : "Fighting air pollution through cars: Level Germany! https:\/\/t.co\/nIi4Xv8qJn",
    "id" : 751933180412850176,
    "created_at" : "2016-07-10 00:16:55 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 752616998320934912,
  "created_at" : "2016-07-11 21:34:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kickstarter",
      "indices" : [ 77, 89 ]
    }, {
      "text" : "ThunderDrive",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/5wn946B2P5",
      "expanded_url" : "http:\/\/thndr.me\/4XpQw2",
      "display_url" : "thndr.me\/4XpQw2"
    } ]
  },
  "geo" : { },
  "id_str" : "752488027646267392",
  "text" : "Don't miss these deals. Get the world's smallest Thumb Drive for $3 shipped! #Kickstarter #ThunderDrive https:\/\/t.co\/5wn946B2P5",
  "id" : 752488027646267392,
  "created_at" : "2016-07-11 13:01:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Radeon",
      "screen_name" : "amdradeon",
      "indices" : [ 3, 13 ],
      "id_str" : "781516520220463106",
      "id" : 781516520220463106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterRed",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 66 ],
      "url" : "https:\/\/t.co\/cmWKqVfAvi",
      "expanded_url" : "http:\/\/Twitch.TV\/AMD",
      "display_url" : "Twitch.TV\/AMD"
    } ]
  },
  "geo" : { },
  "id_str" : "751528514650865664",
  "text" : "RT @AMDRadeon: We are now live! Join us on https:\/\/t.co\/cmWKqVfAvi for a PC build, gameplay, and giveaways. #BetterRed https:\/\/t.co\/YqxBVkA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.spredfast.com\" rel=\"nofollow\"\u003ESpredfast app\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AMDRadeon\/status\/751491091556433921\/photo\/1",
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/YqxBVkAXHN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3VKe5WIAAjEYd.jpg",
        "id_str" : "751491088909737984",
        "id" : 751491088909737984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3VKe5WIAAjEYd.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/YqxBVkAXHN"
      } ],
      "hashtags" : [ {
        "text" : "BetterRed",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/cmWKqVfAvi",
        "expanded_url" : "http:\/\/Twitch.TV\/AMD",
        "display_url" : "Twitch.TV\/AMD"
      } ]
    },
    "geo" : { },
    "id_str" : "751491091556433921",
    "text" : "We are now live! Join us on https:\/\/t.co\/cmWKqVfAvi for a PC build, gameplay, and giveaways. #BetterRed https:\/\/t.co\/YqxBVkAXHN",
    "id" : 751491091556433921,
    "created_at" : "2016-07-08 19:00:12 +0000",
    "user" : {
      "name" : "Radeon RX",
      "screen_name" : "Radeon",
      "protected" : false,
      "id_str" : "23127272",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/839493950859849728\/4I6CtWd9_normal.jpg",
      "id" : 23127272,
      "verified" : true
    }
  },
  "id" : 751528514650865664,
  "created_at" : "2016-07-08 21:28:55 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacksfilms",
      "screen_name" : "jacksfilms",
      "indices" : [ 0, 11 ],
      "id_str" : "9989862",
      "id" : 9989862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "751476036454346752",
  "geo" : { },
  "id_str" : "751528332202741760",
  "in_reply_to_user_id" : 9989862,
  "text" : "@jacksfilms Just no!!!",
  "id" : 751528332202741760,
  "in_reply_to_status_id" : 751476036454346752,
  "created_at" : "2016-07-08 21:28:11 +0000",
  "in_reply_to_screen_name" : "jacksfilms",
  "in_reply_to_user_id_str" : "9989862",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "indices" : [ 3, 16 ],
      "id_str" : "2355686438",
      "id" : 2355686438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/uLX6vINtnE",
      "expanded_url" : "https:\/\/twitter.com\/sallykohn\/status\/751462817795084288",
      "display_url" : "twitter.com\/sallykohn\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "751528029168492544",
  "text" : "RT @hannahbleau_: Oh look! Sally's victim-blaming. Moral scatterbrained fool.  https:\/\/t.co\/uLX6vINtnE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 84 ],
        "url" : "https:\/\/t.co\/uLX6vINtnE",
        "expanded_url" : "https:\/\/twitter.com\/sallykohn\/status\/751462817795084288",
        "display_url" : "twitter.com\/sallykohn\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "751476088807759872",
    "text" : "Oh look! Sally's victim-blaming. Moral scatterbrained fool.  https:\/\/t.co\/uLX6vINtnE",
    "id" : 751476088807759872,
    "created_at" : "2016-07-08 18:00:35 +0000",
    "user" : {
      "name" : "Hannah Bleau",
      "screen_name" : "hannahbleau_",
      "protected" : false,
      "id_str" : "2355686438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/835998441457082368\/ZRKTTtGe_normal.jpg",
      "id" : 2355686438,
      "verified" : false
    }
  },
  "id" : 751528029168492544,
  "created_at" : "2016-07-08 21:26:59 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Texas GOP",
      "screen_name" : "TexasGOP",
      "indices" : [ 3, 12 ],
      "id_str" : "37760670",
      "id" : 37760670
    }, {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 24, 32 ],
      "id_str" : "23022687",
      "id" : 23022687
    }, {
      "name" : "Glenn Beck",
      "screen_name" : "glennbeck",
      "indices" : [ 42, 52 ],
      "id_str" : "17454769",
      "id" : 17454769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dallas",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "PrayForDallas",
      "indices" : [ 104, 118 ]
    }, {
      "text" : "DallasPD",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/t4E5cVmQ9U",
      "expanded_url" : "https:\/\/youtu.be\/YOHQWy7aJl4",
      "display_url" : "youtu.be\/YOHQWy7aJl4"
    } ]
  },
  "geo" : { },
  "id_str" : "751528000915660801",
  "text" : "RT @TexasGOP: Listen to @tedcruz speak to @glennbeck this morning here: https:\/\/t.co\/t4E5cVmQ9U #Dallas #PrayForDallas #DallasPD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ted Cruz",
        "screen_name" : "tedcruz",
        "indices" : [ 10, 18 ],
        "id_str" : "23022687",
        "id" : 23022687
      }, {
        "name" : "Glenn Beck",
        "screen_name" : "glennbeck",
        "indices" : [ 28, 38 ],
        "id_str" : "17454769",
        "id" : 17454769
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dallas",
        "indices" : [ 82, 89 ]
      }, {
        "text" : "PrayForDallas",
        "indices" : [ 90, 104 ]
      }, {
        "text" : "DallasPD",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/t4E5cVmQ9U",
        "expanded_url" : "https:\/\/youtu.be\/YOHQWy7aJl4",
        "display_url" : "youtu.be\/YOHQWy7aJl4"
      } ]
    },
    "geo" : { },
    "id_str" : "751443031065190400",
    "text" : "Listen to @tedcruz speak to @glennbeck this morning here: https:\/\/t.co\/t4E5cVmQ9U #Dallas #PrayForDallas #DallasPD",
    "id" : 751443031065190400,
    "created_at" : "2016-07-08 15:49:14 +0000",
    "user" : {
      "name" : "Texas GOP",
      "screen_name" : "TexasGOP",
      "protected" : false,
      "id_str" : "37760670",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/832710879053479936\/_HoEBbjU_normal.jpg",
      "id" : 37760670,
      "verified" : true
    }
  },
  "id" : 751528000915660801,
  "created_at" : "2016-07-08 21:26:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "indices" : [ 3, 18 ],
      "id_str" : "20642356",
      "id" : 20642356
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 93, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751527523209674752",
  "text" : "RT @davidlongoria7: Do what you can, with what you have, where you are. - Theodore Roosevelt #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetjukebox.com\" rel=\"nofollow\"\u003ETweet Jukebox\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751495784462426112",
    "text" : "Do what you can, with what you have, where you are. - Theodore Roosevelt #quote",
    "id" : 751495784462426112,
    "created_at" : "2016-07-08 19:18:51 +0000",
    "user" : {
      "name" : "David Longoria",
      "screen_name" : "davidlongoria7",
      "protected" : false,
      "id_str" : "20642356",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754888883465138176\/lvppUQYX_normal.jpg",
      "id" : 20642356,
      "verified" : true
    }
  },
  "id" : 751527523209674752,
  "created_at" : "2016-07-08 21:24:58 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy O'Dell",
      "screen_name" : "nancyodell",
      "indices" : [ 3, 14 ],
      "id_str" : "20611194",
      "id" : 20611194
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nancyodell\/status\/751496609309995008\/photo\/1",
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/hyxRrdKf65",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3YYc7UcAEuRd2.jpg",
      "id_str" : "751494627434196993",
      "id" : 751494627434196993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3YYc7UcAEuRd2.jpg",
      "sizes" : [ {
        "h" : 636,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/hyxRrdKf65"
    } ],
    "hashtags" : [ {
      "text" : "peace",
      "indices" : [ 16, 22 ]
    }, {
      "text" : "people",
      "indices" : [ 23, 30 ]
    }, {
      "text" : "family",
      "indices" : [ 31, 38 ]
    }, {
      "text" : "friends",
      "indices" : [ 39, 47 ]
    }, {
      "text" : "humanity",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751527499889270785",
  "text" : "RT @nancyodell: #peace #people #family #friends #humanity https:\/\/t.co\/hyxRrdKf65",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nancyodell\/status\/751496609309995008\/photo\/1",
        "indices" : [ 42, 65 ],
        "url" : "https:\/\/t.co\/hyxRrdKf65",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3YYc7UcAEuRd2.jpg",
        "id_str" : "751494627434196993",
        "id" : 751494627434196993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3YYc7UcAEuRd2.jpg",
        "sizes" : [ {
          "h" : 636,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/hyxRrdKf65"
      } ],
      "hashtags" : [ {
        "text" : "peace",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "people",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "family",
        "indices" : [ 15, 22 ]
      }, {
        "text" : "friends",
        "indices" : [ 23, 31 ]
      }, {
        "text" : "humanity",
        "indices" : [ 32, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751496609309995008",
    "text" : "#peace #people #family #friends #humanity https:\/\/t.co\/hyxRrdKf65",
    "id" : 751496609309995008,
    "created_at" : "2016-07-08 19:22:08 +0000",
    "user" : {
      "name" : "Nancy O'Dell",
      "screen_name" : "nancyodell",
      "protected" : false,
      "id_str" : "20611194",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672824341420085248\/x7VSAdT0_normal.jpg",
      "id" : 20611194,
      "verified" : true
    }
  },
  "id" : 751527499889270785,
  "created_at" : "2016-07-08 21:24:53 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/751503674711613441\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/NePfHQVtxz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3gm9eW8AEBDA5.jpg",
      "id_str" : "751503672782286849",
      "id" : 751503672782286849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3gm9eW8AEBDA5.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/NePfHQVtxz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751527243290120192",
  "text" : "RT @rockindigo: A Dallas police officer breaking into tears at Baylor Hospital after the shooting tonight https:\/\/t.co\/NePfHQVtxz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/751503674711613441\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/NePfHQVtxz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm3gm9eW8AEBDA5.jpg",
        "id_str" : "751503672782286849",
        "id" : 751503672782286849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm3gm9eW8AEBDA5.jpg",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/NePfHQVtxz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751503674711613441",
    "text" : "A Dallas police officer breaking into tears at Baylor Hospital after the shooting tonight https:\/\/t.co\/NePfHQVtxz",
    "id" : 751503674711613441,
    "created_at" : "2016-07-08 19:50:12 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 751527243290120192,
  "created_at" : "2016-07-08 21:23:52 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751527196930564097",
  "text" : "RT @lorenridinger: \"Excellence is not a skill. It is an attitude.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751491193733808128",
    "text" : "\"Excellence is not a skill. It is an attitude.\"",
    "id" : 751491193733808128,
    "created_at" : "2016-07-08 19:00:37 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 751527196930564097,
  "created_at" : "2016-07-08 21:23:41 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/751527180551786496\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/xUvE6Xv56q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Cm31-_1UsAASGOt.jpg",
      "id_str" : "751527175476523008",
      "id" : 751527175476523008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Cm31-_1UsAASGOt.jpg",
      "sizes" : [ {
        "h" : 308,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 550
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 550
      } ],
      "display_url" : "pic.twitter.com\/xUvE6Xv56q"
    } ],
    "hashtags" : [ {
      "text" : "BadMovies",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751527180551786496",
  "text" : "Barney: Rated R for Restraining Order, starring Rosey O' Donnell #BadMovies https:\/\/t.co\/xUvE6Xv56q",
  "id" : 751527180551786496,
  "created_at" : "2016-07-08 21:23:37 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "indices" : [ 3, 11 ],
      "id_str" : "23022687",
      "id" : 23022687
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751476022827253761",
  "text" : "RT @tedcruz: Men &amp; women of law enforcement selflessly run into harm's way to save the lives of others. May God protect them and bring peac\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "751256896921739268",
    "text" : "Men &amp; women of law enforcement selflessly run into harm's way to save the lives of others. May God protect them and bring peace upon Dallas.",
    "id" : 751256896921739268,
    "created_at" : "2016-07-08 03:29:36 +0000",
    "user" : {
      "name" : "Ted Cruz",
      "screen_name" : "tedcruz",
      "protected" : false,
      "id_str" : "23022687",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727845526805188614\/Becds2yE_normal.jpg",
      "id" : 23022687,
      "verified" : true
    }
  },
  "id" : 751476022827253761,
  "created_at" : "2016-07-08 18:00:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "751475971526627328",
  "text" : "Lost $22 gambling and already a bad day :(",
  "id" : 751475971526627328,
  "created_at" : "2016-07-08 18:00:08 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "indices" : [ 3, 17 ],
      "id_str" : "34892616",
      "id" : 34892616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748902938886766592",
  "text" : "RT @lorenridinger: \u201CLearn everything you can, anytime you can, from anyone you can \u2013 there will always come a time when you will be gratefu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748623122815922177",
    "text" : "\u201CLearn everything you can, anytime you can, from anyone you can \u2013 there will always come a time when you will be grateful you did.\u201D",
    "id" : 748623122815922177,
    "created_at" : "2016-06-30 21:03:55 +0000",
    "user" : {
      "name" : "Loren Ridinger",
      "screen_name" : "lorenridinger",
      "protected" : false,
      "id_str" : "34892616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451871059101241344\/pYj0_BHI_normal.png",
      "id" : 34892616,
      "verified" : true
    }
  },
  "id" : 748902938886766592,
  "created_at" : "2016-07-01 15:35:49 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Automotive\/status\/474657721799946240\/photo\/1",
      "indices" : [ 57, 80 ],
      "url" : "https:\/\/t.co\/0HCWIphkPc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZSrtdIgAE6lcj.jpg",
      "id_str" : "474657721623805953",
      "id" : 474657721623805953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZSrtdIgAE6lcj.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/0HCWIphkPc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748902743612526592",
  "text" : "RT @BestGamezUp: Rare Ferrari F-340. Only 3 were made... https:\/\/t.co\/0HCWIphkPc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Automotive\/status\/474657721799946240\/photo\/1",
        "indices" : [ 40, 63 ],
        "url" : "https:\/\/t.co\/0HCWIphkPc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZSrtdIgAE6lcj.jpg",
        "id_str" : "474657721623805953",
        "id" : 474657721623805953,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZSrtdIgAE6lcj.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/0HCWIphkPc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748588359782662144",
    "text" : "Rare Ferrari F-340. Only 3 were made... https:\/\/t.co\/0HCWIphkPc",
    "id" : 748588359782662144,
    "created_at" : "2016-06-30 18:45:47 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 748902743612526592,
  "created_at" : "2016-07-01 15:35:02 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "indices" : [ 3, 12 ],
      "id_str" : "14372486",
      "id" : 14372486
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/748527617217822720\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/EUhW1gvOz7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNN5hJXEAAs20J.jpg",
      "id_str" : "748527613619146752",
      "id" : 748527613619146752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNN5hJXEAAs20J.jpg",
      "sizes" : [ {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 630,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 680
      } ],
      "display_url" : "pic.twitter.com\/EUhW1gvOz7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/mHhI0XHpaV",
      "expanded_url" : "http:\/\/engt.co\/29ctbxM",
      "display_url" : "engt.co\/29ctbxM"
    } ]
  },
  "geo" : { },
  "id_str" : "748902567724326912",
  "text" : "RT @engadget: Blast Motion's swing sensor data is coming to baseball broadcasts https:\/\/t.co\/mHhI0XHpaV https:\/\/t.co\/EUhW1gvOz7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/engadget\/status\/748527617217822720\/photo\/1",
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/EUhW1gvOz7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNN5hJXEAAs20J.jpg",
        "id_str" : "748527613619146752",
        "id" : 748527613619146752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNN5hJXEAAs20J.jpg",
        "sizes" : [ {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 630,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 680
        } ],
        "display_url" : "pic.twitter.com\/EUhW1gvOz7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 89 ],
        "url" : "https:\/\/t.co\/mHhI0XHpaV",
        "expanded_url" : "http:\/\/engt.co\/29ctbxM",
        "display_url" : "engt.co\/29ctbxM"
      } ]
    },
    "geo" : { },
    "id_str" : "748527617217822720",
    "text" : "Blast Motion's swing sensor data is coming to baseball broadcasts https:\/\/t.co\/mHhI0XHpaV https:\/\/t.co\/EUhW1gvOz7",
    "id" : 748527617217822720,
    "created_at" : "2016-06-30 14:44:25 +0000",
    "user" : {
      "name" : "Engadget",
      "screen_name" : "engadget",
      "protected" : false,
      "id_str" : "14372486",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655059892022022144\/Pq3Q_1oU_normal.png",
      "id" : 14372486,
      "verified" : true
    }
  },
  "id" : 748902567724326912,
  "created_at" : "2016-07-01 15:34:20 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alcantara",
      "screen_name" : "AlcantaraSpa",
      "indices" : [ 3, 16 ],
      "id_str" : "518470631",
      "id" : 518470631
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/AlcantaraSpa\/status\/748516447899496448\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/b9PiSQ45T5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNDvZtXIAYadGB.jpg",
      "id_str" : "748516444707692550",
      "id" : 748516444707692550,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNDvZtXIAYadGB.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/b9PiSQ45T5"
    } ],
    "hashtags" : [ {
      "text" : "MadeInItaly",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748902536413908992",
  "text" : "RT @AlcantaraSpa: Dreaming of the sea? Take a look at Armadillo from our Acqua #MadeInItaly collection! https:\/\/t.co\/b9PiSQ45T5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlcantaraSpa\/status\/748516447899496448\/photo\/1",
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/b9PiSQ45T5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmNDvZtXIAYadGB.jpg",
        "id_str" : "748516444707692550",
        "id" : 748516444707692550,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmNDvZtXIAYadGB.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/b9PiSQ45T5"
      } ],
      "hashtags" : [ {
        "text" : "MadeInItaly",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748516447899496448",
    "text" : "Dreaming of the sea? Take a look at Armadillo from our Acqua #MadeInItaly collection! https:\/\/t.co\/b9PiSQ45T5",
    "id" : 748516447899496448,
    "created_at" : "2016-06-30 14:00:02 +0000",
    "user" : {
      "name" : "Alcantara",
      "screen_name" : "AlcantaraSpa",
      "protected" : false,
      "id_str" : "518470631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606002441562267648\/MrnoAkRH_normal.jpg",
      "id" : 518470631,
      "verified" : false
    }
  },
  "id" : 748902536413908992,
  "created_at" : "2016-07-01 15:34:13 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "indices" : [ 3, 14 ],
      "id_str" : "561775964",
      "id" : 561775964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/748478350356799489\/photo\/1",
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/3lM1rinBkW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmMhFzDWMAA9IhA.jpg",
      "id_str" : "748478346560942080",
      "id" : 748478346560942080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmMhFzDWMAA9IhA.jpg",
      "sizes" : [ {
        "h" : 644,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 522
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 522
      } ],
      "display_url" : "pic.twitter.com\/3lM1rinBkW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748902486816292864",
  "text" : "RT @rockindigo: As an Englishman, I'm confused af right now... https:\/\/t.co\/3lM1rinBkW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ifttt.com\" rel=\"nofollow\"\u003EIFTTT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rockindigo\/status\/748478350356799489\/photo\/1",
        "indices" : [ 47, 70 ],
        "url" : "https:\/\/t.co\/3lM1rinBkW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CmMhFzDWMAA9IhA.jpg",
        "id_str" : "748478346560942080",
        "id" : 748478346560942080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmMhFzDWMAA9IhA.jpg",
        "sizes" : [ {
          "h" : 644,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 522
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 522
        } ],
        "display_url" : "pic.twitter.com\/3lM1rinBkW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748478350356799489",
    "text" : "As an Englishman, I'm confused af right now... https:\/\/t.co\/3lM1rinBkW",
    "id" : 748478350356799489,
    "created_at" : "2016-06-30 11:28:39 +0000",
    "user" : {
      "name" : "INDIGO",
      "screen_name" : "rockindigo",
      "protected" : false,
      "id_str" : "561775964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/607578264480190464\/mYGCLelE_normal.jpg",
      "id" : 561775964,
      "verified" : false
    }
  },
  "id" : 748902486816292864,
  "created_at" : "2016-07-01 15:34:01 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "indices" : [ 3, 15 ],
      "id_str" : "268556198",
      "id" : 268556198
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/451112808391135232\/photo\/1",
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/bHnfkLzN7h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKstYGIEAALdV0.png",
      "id_str" : "451112808252706816",
      "id" : 451112808252706816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKstYGIEAALdV0.png",
      "sizes" : [ {
        "h" : 544,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 544,
        "resize" : "fit",
        "w" : 820
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bHnfkLzN7h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748901894043623425",
  "text" : "RT @BestGamezUp: A Pokemon type chart that is much easier to read https:\/\/t.co\/bHnfkLzN7h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VlDEOGAMES\/status\/451112808391135232\/photo\/1",
        "indices" : [ 49, 72 ],
        "url" : "https:\/\/t.co\/bHnfkLzN7h",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkKstYGIEAALdV0.png",
        "id_str" : "451112808252706816",
        "id" : 451112808252706816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkKstYGIEAALdV0.png",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 544,
          "resize" : "fit",
          "w" : 820
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bHnfkLzN7h"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "748862543884673024",
    "text" : "A Pokemon type chart that is much easier to read https:\/\/t.co\/bHnfkLzN7h",
    "id" : 748862543884673024,
    "created_at" : "2016-07-01 12:55:18 +0000",
    "user" : {
      "name" : "Best Video Games",
      "screen_name" : "BestGamezUp",
      "protected" : false,
      "id_str" : "268556198",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531879213284880384\/ZlsTCjyx_normal.jpeg",
      "id" : 268556198,
      "verified" : false
    }
  },
  "id" : 748901894043623425,
  "created_at" : "2016-07-01 15:31:40 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/gamer456148\/status\/748901518338850816\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/WU1DqNnDk1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CmSh9NEW8AAqb0Y.jpg",
      "id_str" : "748901510902378496",
      "id" : 748901510902378496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CmSh9NEW8AAqb0Y.jpg",
      "sizes" : [ {
        "h" : 573,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 978,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 978,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/WU1DqNnDk1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748901518338850816",
  "text" : "Went to the pantry, had Canadian bacon and blueberry waffles, 4.21\/5 stars https:\/\/t.co\/WU1DqNnDk1",
  "id" : 748901518338850816,
  "created_at" : "2016-07-01 15:30:10 +0000",
  "user" : {
    "name" : "Andrew Kamal",
    "screen_name" : "gamer456148",
    "protected" : false,
    "id_str" : "210979938",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/812834200147677184\/3o0m9tDz_normal.jpg",
    "id" : 210979938,
    "verified" : false
  }
} ]