>>>READ ME FIRST!!!<<<<

BEFORE YOU PUBLISH ON CHROME STORE

FIRST INSTALL IT ON YOUR BROWSER AND CHECK IF ANY CHANGES ARE NEEDED.


1: Open Google Chrome

2: Log on to: chrome://extensions/

3: Click 'tick' on Developer mode (see this: http://prntscr.com/58nunw )

4: Extract the extension.zip file

5: After that Click on Load Unpacked extension 

6: After that navigate to extension folder (after extraction) and upload it.

7: Your extension will be installed on your browser, please try and let me know if any changes needed
before you publish it on chrome store.


------

Thanks,
gurpreetsaluja